(function(){var e=Object.defineProperty,t=(e,t,n)=>()=>{if(n)throw n[0];try{return e&&(t=e(e=0)),t}catch(e){throw n=[e],e}},n=(t,n)=>{let r={};for(var i in t)e(r,i,{get:t[i],enumerable:!0});return n||e(r,Symbol.toStringTag,{value:`Module`}),r};function r(e){return e==null||typeof e==`function`?{main:e}:e}var i,a=t((()=>{i=function(e){return e[e.unknown=-1]=`unknown`,e[e.bg=0]=`bg`,e[e.group=1]=`group`,e[e.sidebar=2]=`sidebar`,e[e.setup=3]=`setup`,e[e.search=4]=`search`,e[e.url=5]=`url`,e[e.proxy=6]=`proxy`,e[e.preview=7]=`preview`,e[e.sync=8]=`sync`,e[e.panelConfig=9]=`panelConfig`,e[e.editing=10]=`editing`,e}({})})),o,s=t((()=>{o=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome})),c,l=t((()=>{s(),c=o})),u=t((()=>{l()})),d=t((()=>{})),f=t((()=>{})),p=t((()=>{})),m=t((()=>{l(),u(),d(),f(),p()}));function h(e,t){let n=e.indexOf(t);return n>-1&&e.splice(n,1),n}var ee=t((()=>{l()}));function g(e){return e===i.sidebar?`sidebar`:e===i.bg?`bg`:e===i.setup?`setup`:e===i.group?`group`:e===i.proxy?`proxy`:e===i.url?`url`:e===i.search?`search`:e===i.editing?`editing`:e===i.preview?`preview`:e===i.sync?`sync`:e===i.panelConfig?`panel-config`:`unknown`}var _=t((()=>{l(),a(),i.unknown,c.runtime.getBrowserInfo,c.runtime.getManifest().version}));function v(e){S=g(e)}function y(e,...t){console.log(`[${S}${C}${w}] ${e}`,...t)}function b(e,...t){console.warn(`[${S}${C}${w}] ${e}`,...t)}function x(e,t,...n){e=`[${S}${C}${w}] ${e}\n`,n.length&&n.unshift(`
`),t===void 0?console.error(e,...n):console.error(e,t,...n)}var S,C,w,T=t((()=>{_(),S=`unknown`,C=``,w=``}));function E(e){B=e}function D(e){z=e}function O(e,t){if(e===i.bg&&U.bgConnection)return U.bgConnection;if(e===i.sidebar)return U.sidebarConnections.get(t);if(e===i.setup)return U.setupPageConnections.get(t);if(e===i.search)return U.searchPopupConnections.get(t);if(e===i.editing)return U.editingPopupConnections.get(t);if(e===i.group)return U.groupPageConnections.get(t);if(e===i.sync)return U.syncConnections.get(t);if(e===i.panelConfig)return U.panelConfigConnections.get(t);if(e===i.preview)return U.previewConnection}function k(e,t){e===i.bg?U.bgConnection=void 0:e===i.sidebar?U.sidebarConnections.delete(t):e===i.setup?U.setupPageConnections.delete(t):e===i.search?U.searchPopupConnections.delete(t):e===i.editing?U.editingPopupConnections.delete(t):e===i.sync?U.syncConnections.delete(t):e===i.panelConfig?U.panelConfigConnections.delete(t):e===i.group?U.groupPageConnections.delete(t):e===i.preview&&(U.previewConnection=void 0)}function te(e,t){let n={type:e,id:t,state:0,pendingRequests:[],pendingSendings:[],reconnectCount:0};return e===i.bg?U.bgConnection=n:e===i.sidebar?U.sidebarConnections.set(t,n):e===i.setup?U.setupPageConnections.set(t,n):e===i.search?U.searchPopupConnections.set(t,n):e===i.editing?U.editingPopupConnections.set(t,n):e===i.group?U.groupPageConnections.set(t,n):e===i.sync?U.syncConnections.set(t,n):e===i.panelConfig?U.panelConfigConnections.set(t,n):e===i.preview&&(U.previewConnection=n),n}function A(e,t=-1,n=-1){let r=B,a=V,o=H,s=e===i.bg,l=e===i.sidebar,u=e===i.setup,d=e===i.search,f=e===i.editing,p=e===i.sync,m=e===i.panelConfig,h=e===i.group,ee=e===i.preview,_=`IPC.connectTo(${g(e)}):`,v;if(s||ee)v=-1;else if((l||d||f||p||m)&&t!==-1)v=t;else if((u||h)&&n!==-1)v=n;else{x(`${_} No destination id`);return}let S={srcType:r,dstType:e};a!==-1&&(S.srcWinId=a),o!==-1&&(S.srcTabId=o),t!==-1&&(l||d||f||p||m)&&(S.dstWinId=t),n!==-1&&(u||h)&&(S.dstTabId=n);let C=JSON.stringify(S),w,T=!1,E=O(e,v);if(E){if(w=E,w.state===1){b(`${_} Already connecting...`);return}}else T=!0,w=te(e,v);w.state!==2&&(w.state=1);let D=s?-1:-2;w.localPort&&w.localPort.disconnect(),w.localPort=c.runtime.connect({name:C}),w.postListener=e=>{oe(e,w.localPort)},w.localPort.onMessage.addListener(w.postListener),w.disconnectListener=n=>{if(y(`${_} Disconnected!`,n.name,n.error?.message),n.onMessage.removeListener(w.postListener),n.onDisconnect.removeListener(w.disconnectListener),w.localPort=void 0,!w.remotePort){let t=J.get(e);t&&t.forEach(e=>e(w.id))}if(s&&w.reconnectCount++<R){clearTimeout(w.reconnectingTimeout);let n=L*w.reconnectCount;y(`${_} Reconnecting...`,n),w.state=0,w.reconnectingTimeout=setTimeout(()=>A(e,t),n);let r=W.get(D);r&&(clearTimeout(r.timeout),W.delete(D))}else F(n),y(`${_} Removing connection`),w.remotePort||(w.state=0,k(e,v))},w.localPort.onDisconnect.addListener(w.disconnectListener),clearTimeout(w.reconnectingTimeout),w.reconnectingTimeout=setTimeout(()=>{w.reconnectCount=0},le);let j=ce+L*w.reconnectCount,M=setTimeout(()=>{y(`${_} No confirmation for ${j}ms`),W.delete(D),w.state=0,s&&w.reconnectCount++<R?(y(`${_} Retrying connection...`,w.reconnectCount),A(e,t)):(b(`${_} Unable to reconnect...`,w.reconnectCount),k(e,v),w.pendingRequests.length&&(w.pendingRequests.forEach(e=>e.err(`No connection confirmation`)),w.pendingRequests=[]))},j);return W.set(D,{timeout:M,portName:``,ok:()=>{if(w.state=2,T){let t=K.get(e);t&&t.forEach(e=>e(w.id)),re(e,w.id)}if(w.pendingRequests.length){let e=w.pendingRequests;w.pendingRequests=[],e.forEach(e=>e.request())}}}),w.localPort}function j(e,...t){return ne({dstType:i.bg,action:e,args:t},2)}async function M(e){if(e.state===1)return new Promise((t,n)=>{e.pendingRequests.push({request:t,err:n})})}function N(e){let t=e?.localPort;return t?.error&&(t=void 0),!t&&e?.remotePort&&!e.remotePort.error&&(t=e?.remotePort),t}function P(e){let t=e?.localPort?.error?.message??e?.localPort?.error?.message;return t?`
  Port error: `+t:``}async function ne(e,t){if(e.dstType===void 0)return Promise.reject(`IPC.request: No dstType`);let n=e.dstType,r=`IPC.request ${g(n)}: ${e.action}:`,a=-1;n===i.sidebar&&e.dstWinId!==void 0?a=e.dstWinId:n===i.setup&&e.dstTabId!==void 0?a=e.dstTabId:n===i.search&&e.dstWinId!==void 0||n===i.editing&&e.dstWinId!==void 0||n===i.sync&&e.dstWinId!==void 0||n===i.panelConfig&&e.dstWinId!==void 0?a=e.dstWinId:n===i.group&&e.dstTabId!==void 0&&(a=e.dstTabId);let o=O(n,a),s=N(o);return new Promise(async(i,c)=>{if(!o||!s||o.state===0){if(y(`${r} No port, or closed state`),t===0)return c(r+` No connection or port`+P(o));if(t===2){if(b(`${r} No port, or closed state, trying to connect...`),A(n,e.dstWinId,e.dstTabId),o=O(n,a),!o)return c(`${r} Auto-connection: No connection`);y(`${r} Pending request`);try{if(await M(o),o=O(n,a),s=N(o),!o||!s||o.state!==2)return c(r+` Connection is not ready`+P(o))}catch(e){return c(e)}}else return c(`${r} Cannot get target port${P(o)}`)}else if(o.state!==2){y(`${r} Connection is not ready: Pending request`);try{if(await M(o),o=O(n,a),s=N(o),!o||!s||o.state!==2)return c(r+` Connection is not ready`)}catch(e){return c(e)}}let l=G++;e.id=l;try{s.postMessage(e)}catch(i){if(t===2){if(b(`${r} Got error on postMessage, trying to reconnect...`,i),o.state=0,A(n,e.dstWinId,e.dstTabId),o=O(n,a),!o)return c(`${r} Auto-connection: No connection`);try{if(await M(o),o=O(n,a),s=N(o),!o||!s||o.state!==2)return c(r+` Connection is not ready`)}catch(e){return c(e)}try{s.postMessage(e)}catch(e){return c(`${r} Cannot post message: ${String(e)}`)}}else return c(`${r} Cannot post message: ${String(i)}`)}let u=setTimeout(()=>{b(`${r} No confirmation:`,g(n),e.action),W.delete(l),t===2?(y(`${r} Calling request() again...`),ne(e,0).then(i).catch(c)):(s&&(s.error={message:`${r} No request confirmation/answer`}),c(`${r} No confirmation`))},I);W.set(l,{timeout:u,ok:i,err:c,portName:s.name})})}function re(e,t){let n=q.find(n=>n.type===e&&n.id===t);n&&(clearTimeout(n.timer),h(q,n),n.ok())}function ie(e,t){let n=J.get(e)??[];n.push(t),J.set(e,n)}function ae(e){if(e.action!==void 0&&z){let t=z[e.action];if(t)return e.arg?t(e.arg):e.args?t(...e.args):t()}}async function oe(e,t){if(e<0){let t=W.get(e);t&&(clearTimeout(t.timeout),t.ok&&t.ok(),W.delete(-1));return}if(typeof e==`number`){let t=W.get(e);t&&clearTimeout(t.timeout);return}if(!e.action&&e.id){let t=W.get(e.id);t&&(clearTimeout(t.timeout),e.error&&t.err?t.err(e.error):t.ok&&t.ok(e.result),W.delete(e.id));return}let n,r;try{n=ae(e)}catch(t){r=String(t),x(`IPC.onPostMsg: Error on running "${String(e.action)}" action:`,t)}if(e.id&&t){if(n instanceof Promise){let r=e.id;try{t.postMessage(r)}catch(t){x(`IPC.onPostMsg: Error on sending "${String(e.action)}" action confirm:`,t);return}let i,a,o=r+t.name;try{Y.set(o,t.name),i=await n}catch(e){a=String(e)}if(Y.has(o))Y.delete(o);else return;try{t.postMessage({id:r,result:i,error:a})}catch(t){x(`IPC.onPostMsg: Error on sending "${String(e.action)}" action result:`,t);return}}else try{t.postMessage({id:e.id,result:n,error:r})}catch(t){x(`IPC.onPostMsg: Error on sending "${String(e.action)}" action result:`,t)}}}function F(e){y(`IPC.resolveUnfinishedCommunications()`);for(let[t,n]of W)n.portName===e.name&&(clearTimeout(n.timeout),n.err&&n.err(`IPC: Target disconnected: `+e.name),W.delete(t));for(let[t,n]of Y)n===e.name&&Y.delete(t)}function se(e,t){if(t===void 0&&(t=-1),e!==i.bg&&e!==i.preview&&t===-1)return x(`IPC.disconnectFrom: No winOrTabId`);let n=O(e,t);if(!n)return;n.localPort&&=(F(n.localPort),n.localPort.disconnect(),n.localPort.onMessage.removeListener(n.postListener),n.localPort.onDisconnect.removeListener(n.disconnectListener),void 0),n.remotePort&&=(F(n.remotePort),n.remotePort.disconnect(),n.remotePort.onMessage.removeListener(n.postListener),n.remotePort.onDisconnect.removeListener(n.disconnectListener),void 0),clearTimeout(n.reconnectingTimeout);let r=!1;if(!n.remotePort&&!n.localPort&&(r=!0,k(e,t)),r){let t=J.get(e);t&&t.forEach(e=>e(n.id))}}var I,ce,L,R,le,z,B,V,H,U,W,G,K,q,J,Y,ue=t((()=>{l(),a(),ee(),m(),T(),_(),I=6e4,ce=5e3,L=1e3,R=6,le=13e3,B=i.unknown,V=-1,H=-1,U={bgConnection:void 0,searchPopupConnections:new Map,editingPopupConnections:new Map,sidebarConnections:new Map,setupPageConnections:new Map,groupPageConnections:new Map,syncConnections:new Map,panelConfigConnections:new Map,previewConnection:void 0},W=new Map,G=1,K=new Map,q=[],J=new Map,Y=new Map})),de=n({});function fe(){return new Promise((e,t)=>{if(window.sideberyInitData)return e();window.onSideberyInitDataReady=e,setTimeout(()=>t(`GroupPage: No initial data (sideberyInitData)`),2e3)})}async function pe(e,t,n,r){if(Z.titleEl&&(Z.titleEl.innerText=t),Z.urlEl&&(Z.urlEl.innerText=n),Z.tabId=e,Z.unloaded=r,Z.unloaded)me(``);else{let t=await j(`tabsApiProxy`,`captureTab`,e,Q).catch(()=>``);Z.tabId===e&&me(t)}}function me(e){Z.previewEl1&&Z.previewEl2&&($?($=0,Z.previewEl1.style.setProperty(`opacity`,`1`),Z.previewEl1.style.setProperty(`background-image`,e?`url("${e}")`:`none`),setTimeout(()=>{Z.previewEl2&&Z.previewEl2.style.setProperty(`opacity`,`0`)},10)):($++,Z.previewEl2.style.setProperty(`opacity`,`1`),Z.previewEl2.style.setProperty(`background-image`,e?`url("${e}")`:`none`),setTimeout(()=>{Z.previewEl1&&Z.previewEl1.style.setProperty(`opacity`,`0`)},10)),_e())}function he(e){if(!Z.popupEl)return;let t=e+Z.offsetY+Te;t>Z.maxY?t=Z.maxY:t<Z.minY&&(t=Z.minY),Z.popupEl.style.transform=`translateY(${t}px)`}function ge(){Z.rootEl&&!Z.hidden&&(Z.rootEl.style.opacity=`1`,_e())}function _e(){Z.popupEl&&(Z.unloaded?Z.previewBoxEl?.style.setProperty(`display`,`none`):Z.previewBoxEl?.style.setProperty(`display`,`block`))}function ve(){Z.rootEl&&(Z.rootEl.style.opacity=`0`,Z.hidden=!0,se(i.bg),se(i.sidebar,Z.winId))}function ye(){Z.rootEl&&(Z.rootEl.style.transform=`scale(${Z.compScale})`)}function be(e){let t=Z.pageWidth,n=Z.pageHeight,r=Math.round(n/t*e);return r>e&&(r=e),r}function xe(e,t,n){let r=Z.pageWidth,i=Z.pageHeight,a=r/e,o=i/t,s=n/Math.min(a,o)*1.5;return s>n&&(s=n),s*Z.compScale}function Se(){return Z.popupEl?Z.popupEl.offsetHeight:Z.previewHeight}function Ce(){Z.maxY=Z.pageHeight/Z.compScale-X-Z.popupHeight}async function we(){v(i.preview),Z.rootEl=document.getElementById(`sdbr_preview_root`),Z.rootEl&&Z.rootEl.remove(),Z.rootEl=document.createElement(`div`),Z.rootEl.setAttribute(`id`,`sdbr_preview_root`),document.body.appendChild(Z.rootEl),await fe();let e=window.sideberyInitData;window.sideberyInitData=void 0,window.onSideberyInitDataReady=void 0,Z.winId=e.winId,Z.referenceDevicePixelRatio=e.dpr,Z.referenceDevicePixelRatio!==window.devicePixelRatio&&(Z.compScale=Z.referenceDevicePixelRatio/window.devicePixelRatio);let t=Math.trunc(window.innerHeight/Z.compScale),n=t-(e.sh||t);Z.previewWidth=e.popupWidth,Z.previewHeight=be(e.popupWidth),Z.offsetY=e.offsetY+n,Z.offsetX=e.offsetX,Z.unloaded=e.unloaded,Q.scale=xe(Z.previewWidth,Z.previewHeight,Z.referenceDevicePixelRatio),E(i.preview),A(i.bg),A(i.sidebar,e.winId),D({updatePreview:pe,setY:he,close:ve}),ie(i.sidebar,ve);let r=Z.rootEl.attachShadow({mode:`closed`});Z.rootEl.style.cssText=`
    --bg: ${e.bg};
    --fg: ${e.fg};
    --hbg: ${e.hbg};
    --hfg: ${e.hfg};
    position: fixed;
    z-index: 999999;
    top: 0;
    ${e.atTheLeft?`left: 0;`:`right: 0;`}
    height: 100vh;
    width: 0;
    padding: 0;
    margin: 0;
    border: none;
    pointer-events: none;
    opacity: 0;
    transition: opacity .1s;
    transform-origin: 50% 0%;
    text-align: start;
    direction: ltr;
    font-style: normal;
    font-variant: normal;
    text-transform: none;
    visibility: visible;
    white-space: normal;
`,Z.popupEl=document.createElement(`div`),Z.popupEl.classList.add(`popup`),r.appendChild(Z.popupEl),Z.popupEl.style.cssText=`
    position: absolute;
    width: ${Z.previewWidth}px;
    ${e.atTheLeft?`left`:`right`}: ${X+Z.offsetX}px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    border-radius: 8px;
    box-shadow: 0 1px 12px 0 #0005;
    background-color: var(--bg);
    overflow: hidden;
    color: var(--fg);
    font-family: system-ui;
    transition: background 1s;
`;let a=document.createElement(`div`);a.classList.add(`header`),Z.popupEl.appendChild(a),a.style.cssText=`
    position: relative;
    flex-shrink: 0;
    width: 100%;
    background-color: var(--hbg);
    font-size: 16px;
    color: var(--hfg);
    overflow: hidden;
`;let o=e.tMax;o>0&&(Z.titleEl=document.createElement(`div`),Z.titleEl.classList.add(`title`),a.appendChild(Z.titleEl),Z.titleEl.style.cssText=`
    position: relative;
    margin: 6px 8px 4px;
    padding: 0;
    font-size: .875em;
    font-weight: 700;
    line-height: 1.2em;
    overflow: hidden;`,o===1?Z.titleEl.style.cssText+=`
      text-overflow: ellipsis;
      white-space: nowrap;`:Z.titleEl.style.cssText+=`
      display: -webkit-box;
      -webkit-box-orient: vertical;
      -webkit-line-clamp: ${o};`);let s=e.uMax;s>0&&(Z.urlEl=document.createElement(`div`),Z.urlEl.classList.add(`url`),a.appendChild(Z.urlEl),Z.urlEl.style.cssText=`
      position: relative;
      margin: ${o>0?`0`:`8px`} 8px 8px;
      padding: 0;
      font-size: .8125em;
      font-weight: 400;
      line-height: 1.2em;
      overflow: hidden;
      opacity: ${o?`.75`:`1`};`,s===1?Z.urlEl.style.cssText+=`
      text-overflow: ellipsis;
      white-space: nowrap;`:Z.urlEl.style.cssText+=`
      display: -webkit-box;
      -webkit-box-orient: vertical;
      -webkit-line-clamp: ${s};`),Z.previewBoxEl=document.createElement(`div`),Z.popupEl.appendChild(Z.previewBoxEl),Z.previewBoxEl.style.cssText=`
    position: relative;
    width: 100%;
    height: ${Z.previewHeight+e.rCrop}px;
`,Z.previewEl1=document.createElement(`div`),Z.previewBoxEl.appendChild(Z.previewEl1),Z.previewEl1.style.cssText=`
    position: absolute;
    width: calc(100% + ${e.rCrop}px);
    height: 100%;
    top: 0;
    left: 0;
    background-image: var(--preview);
    background-repeat: no-repeat;
    background-position: 50% 0%;
    background-size: cover;
    opacity: 0;
    transition: opacity .12s;
`,Z.previewEl2=document.createElement(`div`),Z.previewBoxEl.appendChild(Z.previewEl2),Z.previewEl2.style.cssText=`
    position: absolute;
    width: calc(100% + ${e.rCrop}px);
    height: 100%;
    top: 0;
    left: 0;
    background-image: var(--preview);
    background-repeat: no-repeat;
    background-position: 50% 0%;
    background-size: cover;
    opacity: 0;
    transition: opacity .12s;
`,ye(),pe(e.tabId,e.title,e.url,e.unloaded),Z.popupHeight=Se(),Ce(),he(e.y),setTimeout(()=>ge(),50)}var Te,X,Z,Q,$,Ee=t((()=>{a(),m(),ue(),T(),Te=-24,X=2,Z={tabId:-1,winId:-1,unloaded:!1,rootEl:null,popupEl:null,titleEl:null,urlEl:null,previewBoxEl:null,previewEl1:null,previewEl2:null,referenceDevicePixelRatio:1,previewWidth:280,previewHeight:250,popupHeight:250,offsetY:0,offsetX:0,pageWidth:window.innerWidth,pageHeight:window.innerHeight,compScale:1,minY:X,maxY:window.innerHeight-250,hidden:!1},Q={format:`jpeg`,quality:90,scale:window.devicePixelRatio/2},$=0,we()})),De=r(()=>{Promise.resolve().then(()=>(Ee(),de))}),Oe={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(()=>{let e;try{e=De.main(),e instanceof Promise&&(e=e.catch(e=>{throw Oe.error(`The unlisted script "tab-preview" crashed on startup!`,e),e}))}catch(e){throw Oe.error(`The unlisted script "tab-preview" crashed on startup!`,e),e}return e})()})();