/**
 * Sidechery in-page rail
 * ---------------------------------------------------------------------------
 * Renders the real Sidebery sidebar (sidebar/sidebar.html) inside an iframe
 * that lives in the page itself instead of Chrome's side panel slot.
 *
 * Why: Chrome's native side panel has a hard-coded minimum width (~320px) and
 * cannot auto-hide. An in-page overlay is not bound by those rules.
 *
 * Features:
 *   - collapse to a thin edge strip, expand on hover (auto-hide)
 *   - drag-to-resize from 100px to 60vw
 *   - left / right edge
 *   - pin (always visible) / auto-hide modes
 *   - everything persists in chrome.storage.local
 *   - isolated in a closed Shadow DOM, so page CSS cannot break it
 * ---------------------------------------------------------------------------
 */
;(() => {
  'use strict'

  // Never run inside iframes (including our own sidebar iframe).
  if (window.top !== window.self) return
  // Only real web pages.
  if (!/^https?:$/.test(location.protocol)) return
  const B = globalThis.browser?.runtime?.id ? globalThis.browser : globalThis.chrome

  /* ---------------------------------------------------- context liveness *
   * Reloading or updating the extension invalidates the context of every
   * content script that is already on a page. From that moment each chrome.*
   * call throws "Extension context invalidated" — and it throws SYNCHRONOUSLY,
   * so `.catch()` on the returned promise does not help. Left unhandled this
   * produces a zombie rail: the UI is still painted, its iframe points at a
   * dead chrome-extension:// URL, and no click does anything.
   */
  let dead = false

  function isCtxError(e) {
    return /context invalidated/i.test(String(e?.message ?? e))
  }

  function contextAlive() {
    if (dead) return false
    try { return !!B.runtime?.id } catch (e) { return false }
  }

  /**
   * Run an extension-API call, degrading to a clean shutdown when it dies.
   * Chrome reports an invalidated context in two ways depending on the call and
   * the version: a synchronous throw, or a rejected promise. Both are covered.
   */
  function api(fn) {
    if (dead) return undefined
    try {
      const r = fn()
      if (r && typeof r.then === 'function') {
        return r.catch(e => {
          if (isCtxError(e)) { shutdown(); return undefined }
          throw e
        })
      }
      return r
    } catch (e) {
      if (isCtxError(e)) { shutdown(); return undefined }
      throw e
    }
  }

  // A previous instance may still be on the page. If its context is alive we
  // were simply injected twice — leave it alone. If it is dead, take over:
  // teardown() is pure DOM, so calling it on a dead instance is safe.
  const prev = window.__sdbrRail
  if (prev) {
    let prevAlive = false
    try { prevAlive = !!prev.alive } catch (e) { prevAlive = false }
    if (prevAlive) return
    // Prefer shutdown(): it also clears the predecessor's watchdog. Without
    // that, two instances would keep removing each other's host (they share
    // the same element id) and the rail would visibly thrash. Fall back to
    // destroy() for builds that predate shutdown().
    //
    // The flag keeps the predecessor from showing its "refresh the tab" hint:
    // at this moment `window.__sdbrRail` still points at it, so its own
    // successor check cannot see us yet. Cleared once we have mounted.
    try {
      window.__sdbrRailTakeover = true
      if (typeof prev.shutdown === 'function') prev.shutdown()
      else prev.destroy?.()
    } catch (e) { /* already broken */ }
  }

  const HOST_ID = 'sdbr-rail-host'
  const MIN_W = 100
  let SIDEBAR_URL = ''
  try { SIDEBAR_URL = B.runtime.getURL('sidebar/sidebar.html') } catch (e) { SIDEBAR_URL = '' }

  const SCHEMA = 6

  const DEFAULTS = {
    schema: SCHEMA,
    enabled: true,
    width: 280,
    edge: 'left',
    collapsedWidth: 6,
    autoHide: true,
    pinned: false,
    showDelay: 120,
    hideDelay: 450,
    dimWhenCollapsed: true,
    shiftPage: true,
    // Must mirror the controller's RAIL_DEFAULTS: pickSettings() only
    // round-trips the keys listed here, so omitting them would silently erase
    // the memo the background keeps for restoring Sidebery's own setting.
    preventTabActivation: true,
    savedActivateLastTab: null,
    // Keep the sidebar iframe alive while the tab is hidden. Destroying it on
    // every tab switch made Sidebery rebuild the tab tree from scratch (all
    // tabs logged "no props"), which moved branches between parents.
    keepSidebarAlive: true,
    frameBg: '#231c2f',
    toolbarBg: '#3a3346',
    accent: '',
  }

  /**
   * Older builds defaulted `shiftPage` to false and persisted every key, so a
   * plain merge would keep the old overlay behaviour forever after an upgrade.
   */
  function migrate(raw) {
    const next = Object.assign({}, DEFAULTS, raw || {})
    if ((Number(raw?.schema) || 0) < 4) next.shiftPage = DEFAULTS.shiftPage
    next.schema = SCHEMA
    return next
  }

  let S = Object.assign({}, DEFAULTS)
  let host = null
  let shadow = null
  let panel = null
  let grip = null
  let frame = null
  let frameWanted = false
  let expanded = false
  let showTimer = 0
  let hideTimer = 0
  let watchdog = 0

  /* ---------------------------------------------------------------- state */

  async function loadSettings() {
    try {
      if (!contextAlive()) { shutdown(); return }
      const r = await api(() => B.storage.local.get('rail_settings'))
      S = migrate(r?.rail_settings)
    } catch (e) {
      if (isCtxError(e)) shutdown()
      S = Object.assign({}, DEFAULTS)
    }
  }

  function saveSettings(patch) {
    Object.assign(S, patch)
    applyVars()
    api(() => B.storage.local.set({ rail_settings: pickSettings() }))?.catch?.(() => {})
    api(() => B.runtime.sendMessage({ __sdbrRail: 1, action: 'settings', settings: pickSettings() }))?.catch?.(() => {})
  }

  // Persisted separately (and silently) so a navigation to chrome://newtab and
  // back restores the rail exactly as it was: pinned stays pinned, hovered-open
  // stays open, collapsed stays collapsed.
  let lastOpenTimer = 0
  let lastOpenValue = null
  function rememberOpen(open) {
    if (lastOpenValue === open) return
    lastOpenValue = open
    clearTimeout(lastOpenTimer)
    lastOpenTimer = setTimeout(() => {
      // Synchronous throw on a dead context: api() is what keeps this quiet.
      api(() => B.storage.local.set({ rail_last_open: open }))?.catch?.(() => {})
    }, 250)
  }

  function pickSettings() {
    const out = {}
    for (const k of Object.keys(DEFAULTS)) out[k] = S[k]
    return out
  }

  /* ------------------------------------------------------------ shadow css */

  const CSS = `
:host {
  all: initial;
  --w: 280px;
  --cw: 6px;
  --frame-bg: #231c2f;
  --toolbar-bg: #3a3346;
  --accent: #47cfff;
  --grip-w: 5px;
  position: fixed;
  top: 0;
  bottom: 0;
  z-index: 2147483647;
  pointer-events: none;
  font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  color-scheme: light dark;
}
:host([data-edge="left"])  { left: 0; }
:host([data-edge="right"]) { right: 0; }

.panel {
  position: absolute;
  top: 0;
  bottom: 0;
  width: var(--w);
  display: flex;
  flex-direction: column;
  background: var(--frame-bg);
  box-shadow: 0 0 0 1px rgba(0,0,0,.35), 0 0 24px rgba(0,0,0,.35);
  pointer-events: auto;
  transition: transform .18s ease, opacity .18s ease;
  will-change: transform;
}
:host([data-edge="left"])  .panel { left: 0;  transform: translateX(calc(-1 * var(--w) + var(--cw))); }
:host([data-edge="right"]) .panel { right: 0; transform: translateX(calc(var(--w) - var(--cw))); }
:host([data-open="1"]) .panel { transform: translateX(0); }
:host([data-open="0"][data-dim="1"]) .panel { opacity: .55; }

/* invisible while collapsed so it never eats page clicks */
:host([data-open="0"]) .panel { pointer-events: none; }
:host([data-open="0"]) .head,
:host([data-open="0"]) .frame { visibility: hidden; }

.head {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  gap: 4px;
  height: 26px;
  padding: 0 4px;
  background: var(--toolbar-bg);
  cursor: default;
  user-select: none;
}
.head .spacer { flex: 1 1 auto; }
.head .ttl {
  font-size: 10px;
  letter-spacing: .06em;
  text-transform: uppercase;
  opacity: .55;
  color: #fff;
  white-space: nowrap;
  overflow: hidden;
}
.head button {
  all: unset;
  box-sizing: border-box;
  width: 20px;
  height: 20px;
  display: grid;
  place-items: center;
  border-radius: 5px;
  cursor: pointer;
  color: #fff;
  opacity: .7;
  font-size: 12px;
  line-height: 1;
}
.head button:hover { opacity: 1; background: rgba(255,255,255,.14); }
.head button:active { background: rgba(255,255,255,.22); }
.head button[data-on="1"] { color: var(--accent); opacity: 1; }

.frame {
  flex: 1 1 auto;
  width: 100%;
  border: 0;
  display: block;
  background: var(--frame-bg);
}

/* the always-hoverable edge strip */
.grip {
  position: absolute;
  top: 0;
  bottom: 0;
  width: var(--cw);
  pointer-events: auto;
  cursor: pointer;
  background: linear-gradient(to right, rgba(0,0,0,.28), rgba(0,0,0,0));
  opacity: .5;
  transition: opacity .18s ease;
}
:host([data-edge="right"]) .grip {
  background: linear-gradient(to left, rgba(0,0,0,.28), rgba(0,0,0,0));
}
:host([data-edge="left"])  .grip { left: 0; }
:host([data-edge="right"]) .grip { right: 0; }
.grip:hover { opacity: 1; }
:host([data-open="1"]) .grip { opacity: 0; pointer-events: none; }

/* resize handle sits on the inner border of the panel */
.resize {
  position: absolute;
  top: 0;
  bottom: 0;
  width: var(--grip-w);
  pointer-events: auto;
  cursor: ew-resize;
  background: transparent;
  transition: background .15s ease;
}
:host([data-edge="left"])  .resize { right: calc(-1 * var(--grip-w) / 2); }
:host([data-edge="right"]) .resize { left: calc(-1 * var(--grip-w) / 2); }
.resize:hover, .resize[data-drag="1"] { background: var(--accent); opacity: .55; }
:host([data-open="0"]) .resize { pointer-events: none; }
`

  /* ------------------------------------------------------------------- dom */

  function build() {
    if (document.getElementById(HOST_ID)) document.getElementById(HOST_ID).remove()

    host = document.createElement('div')
    host.id = HOST_ID
    host.setAttribute('data-edge', S.edge)
    host.setAttribute('data-open', '0')
    host.setAttribute('data-dim', S.dimWhenCollapsed ? '1' : '0')

    shadow = host.attachShadow({ mode: 'open' })

    const style = document.createElement('style')
    style.textContent = CSS
    shadow.appendChild(style)

    panel = document.createElement('div')
    panel.className = 'panel'

    const head = document.createElement('div')
    head.className = 'head'

    const ttl = document.createElement('span')
    ttl.className = 'ttl'
    ttl.textContent = 'Sidechery'

    const pinBtn = mkBtn('📌', 'Pin / unpin (auto-hide)')
    pinBtn.dataset.title = 'pin'
    pinBtn.dataset.on = S.pinned ? '1' : '0'
    pinBtn.addEventListener('click', () => {
      const pinned = !S.pinned
      saveSettings({ pinned })
      pinBtn.dataset.on = pinned ? '1' : '0'
      if (pinned) open(true)
      else scheduleHide()
    })

    const sideBtn = mkBtn('⇄', 'Switch side')
    sideBtn.addEventListener('click', () => {
      const edge = S.edge === 'left' ? 'right' : 'left'
      saveSettings({ edge })
      applyVars()
    })

    const panelBtn = mkBtn('▤', 'Open the native side panel in this window')
    panelBtn.addEventListener('click', () => {
      api(() => B.runtime.sendMessage({ __sdbrRail: 1, action: 'openPanel' }))?.catch?.(() => {})
    })

    const cfgBtn = mkBtn('⚙', 'Sidechery settings')
    cfgBtn.addEventListener('click', () => {
      api(() => B.runtime.sendMessage({ __sdbrRail: 1, action: 'openOptions' }))?.catch?.(() => {})
    })

    const closeBtn = mkBtn('✕', 'Turn off the in-page rail')
    closeBtn.addEventListener('click', () => {
      saveSettings({ enabled: false })
      teardown()
    })

    const spacer = document.createElement('span')
    spacer.className = 'spacer'

    head.append(ttl, spacer, panelBtn, cfgBtn, pinBtn, sideBtn, closeBtn)
    panel.appendChild(head)

    // The sidebar iframe is created lazily, on first expand.
    const resize = document.createElement('div')
    resize.className = 'resize'
    panel.appendChild(resize)
    wireResize(resize)

    grip = document.createElement('div')
    grip.className = 'grip'
    grip.title = 'Sidechery rail'

    shadow.append(panel, grip)

    // Hover behaviour: expand on enter, collapse on leave.
    const enter = () => open()
    const leave = () => { if (!S.pinned) scheduleHide() }
    panel.addEventListener('mouseenter', enter)
    panel.addEventListener('mouseleave', leave)
    grip.addEventListener('mouseenter', enter)
    grip.addEventListener('mouseleave', leave)
    grip.addEventListener('click', () => open(true))

    document.documentElement.appendChild(host)
    applyVars()
    startWatchdog()
  }

  function mkBtn(label, title) {
    const b = document.createElement('button')
    b.type = 'button'
    b.textContent = label
    b.title = title
    return b
  }

  function applyVars() {
    if (!host) return
    host.setAttribute('data-edge', S.edge)
    host.setAttribute('data-dim', S.dimWhenCollapsed ? '1' : '0')
    host.style.setProperty('--w', clampW(S.width) + 'px')
    host.style.setProperty('--cw', Math.max(2, S.collapsedWidth | 0) + 'px')
    if (S.frameBg) host.style.setProperty('--frame-bg', S.frameBg)
    if (S.toolbarBg) host.style.setProperty('--toolbar-bg', S.toolbarBg)
    if (S.accent) host.style.setProperty('--accent', S.accent)

    // Page shifting is done by setPageShift() on <html> ONLY. An earlier build
    // also wrote a margin to <body>, which stacked on top of the <html> margin
    // and pushed the content twice the rail's width.
    document.body.dataset.sdbrRail = S.enabled ? 'on' : ''
    updatePageShift()
  }

  /* ------------------------------------------------------- page shifting */

  // Margins on <html> shrink the initial containing block, which is the only
  // reliable way to move `position: fixed` elements along with the content.
  function setPageShift(on) {
    const el = document.documentElement
    if (!el) return
    // setProperty() takes CSSOM (hyphenated) names; camelCase is silently
    // dropped by spec-conformant implementations.
    const side = S.edge === 'left' ? 'margin-left' : 'margin-right'
    const other = S.edge === 'left' ? 'margin-right' : 'margin-left'
    try {
      el.style.setProperty(other, '0px', 'important')
      el.style.setProperty(side, on ? clampW(S.width) + 'px' : '0px', 'important')
      el.style.setProperty('transition',
        on || S.shiftPage ? 'margin .18s ease' : '', 'important')
    } catch (e) { /* detached document */ }
  }

  /** Drop our own margins from <html>, leaving the site's own styles alone. */
  function clearPageShift() {
    const el = document.documentElement
    if (!el) return
    for (const p of ['margin-left', 'margin-right', 'transition']) {
      try { el.style.removeProperty(p) } catch (e) {}
    }
  }

  function updatePageShift(animate) {
    if (!S.enabled) return
    const on = !!S.shiftPage && expanded
    // A hook for page-level/user CSS; kept even in overlay mode.
    document.body.dataset.sdbrRailShift = on ? 'on' : 'off'
    if (!S.shiftPage) {
      // Overlay mode: the rail floats above the page, so the document margins
      // must stay exactly as the site left them.
      clearPageShift()
      return
    }
    if (animate === false) {
      const el = document.documentElement
      try { el.style.setProperty('transition', 'none', 'important') } catch (e) {}
      setPageShift(on)
      void el.offsetWidth
      try { el.style.setProperty('transition', 'margin .18s ease', 'important') } catch (e) {}
    } else {
      setPageShift(on)
    }
  }

  function clampW(w) {
    const max = Math.max(MIN_W + 1, Math.floor(window.innerWidth * 0.6))
    return Math.min(Math.max(MIN_W, Math.round(w)), max)
  }

  /* --------------------------------------------------------- iframe (lazy) */

  /* ------------------------------------------------- sidebar slot (lock) *
   * Sidechery allows one sidebar connection per browser window. This tab may
   * only run the sidebar iframe while the background says we own that slot,
   * and while the tab is actually visible. Otherwise several tabs in one
   * window would each run a full sidebar instance, overwrite each other's
   * connection, and rebuild the same tab tree concurrently — which is what
   * made tabs lose their groups.
   */
  let ownsSlot = false
  let claiming = false
  let evicted = false
  let hideGraceTimer = 0
  const HIDE_GRACE = 700

  function tabVisible() {
    return document.visibilityState !== 'hidden'
  }

  async function ensureFrame() {
    if (frame || !panel || !SIDEBAR_URL) return
    if (!tabVisible()) return
    if (claiming) return
    claiming = true
    try {
      const r = await api(() => B.runtime.sendMessage({ __sdbrRail: 1, action: 'claimSidebar' }))
      ownsSlot = !!r?.granted
    } catch (e) {
      if (isCtxError(e)) return
      ownsSlot = false
    } finally {
      claiming = false
    }
    if (!ownsSlot || !panel || frame) return
    if (!tabVisible()) { releaseSlot(); return }

    frameWanted = true
    frame = document.createElement('iframe')
    frame.className = 'frame'
    frame.setAttribute('allow', 'clipboard-write')
    frame.setAttribute('title', 'Sidechery sidebar')
    frame.src = SIDEBAR_URL
    // Insert before the resize handle so the handle stays on top.
    const rh = panel.querySelector('.resize')
    panel.insertBefore(frame, rh)
  }

  function releaseSlot() {
    if (!ownsSlot) return
    ownsSlot = false
    api(() => B.runtime.sendMessage({ __sdbrRail: 1, action: 'releaseSidebar' }))?.catch?.(() => {})
  }

  function dropFrame() {
    releaseSlot()
    if (!frame) return
    frame.remove()
    frame = null
    frameWanted = false
  }

  /* ------------------------------------------------------------ open/close */

  function open(immediate) {
    clearTimeout(hideTimer)
    if (expanded && frame) return
    if (!immediate && S.showDelay > 0) {
      clearTimeout(showTimer)
      showTimer = setTimeout(() => open(true), S.showDelay)
      return
    }
    clearTimeout(showTimer)
    expanded = true
    evicted = false            // an explicit expand is a request to take over
    ensureFrame()
    host?.setAttribute('data-open', '1')
    rememberOpen(true)
    applyVars()
  }

  function close(immediate) {
    clearTimeout(showTimer)
    if (!expanded) return
    if (!immediate && S.hideDelay > 0) {
      clearTimeout(hideTimer)
      hideTimer = setTimeout(() => close(true), S.hideDelay)
      return
    }
    clearTimeout(hideTimer)
    expanded = false
    host?.setAttribute('data-open', '0')
    rememberOpen(false)
    applyVars()
  }

  const scheduleHide = () => close(false)

  /* ---------------------------------------------------------------- resize */

  function wireResize(el) {
    let dragging = false
    let startX = 0
    let startW = 0

    el.addEventListener('pointerdown', e => {
      if (e.button !== 0) return
      dragging = true
      startX = e.clientX
      startW = clampW(S.width)
      el.dataset.drag = '1'
      el.setPointerCapture?.(e.pointerId)
      document.documentElement.style.cursor = 'ew-resize'
      document.documentElement.style.userSelect = 'none'
      // Freeze transitions so the drag feels 1:1.
      if (panel) panel.style.transition = 'none'
      updatePageShift(false)
      e.preventDefault()
      e.stopPropagation()
    })

    el.addEventListener('pointermove', e => {
      if (!dragging) return
      const dx = e.clientX - startX
      const w = S.edge === 'left' ? startW + dx : startW - dx
      S.width = clampW(w)
      host.style.setProperty('--w', S.width + 'px')
    })

    const stop = () => {
      if (!dragging) return
      dragging = false
      el.dataset.drag = '0'
      document.documentElement.style.cursor = ''
      document.documentElement.style.userSelect = ''
      if (panel) panel.style.transition = ''
      updatePageShift(false)
      saveSettings({ width: S.width })
    }
    el.addEventListener('pointerup', stop)
    el.addEventListener('pointercancel', stop)

    el.addEventListener('dblclick', () => saveSettings({ width: DEFAULTS.width }))
  }

  /* -------------------------------------------------------------- lifetime */

  /**
   * Remove the rail from the page but KEEP the watchdog running. Turning the
   * rail off is a stored preference, not a reason to stop self-healing: if it
   * is switched back on, or if the host is lost for any other reason, the
   * watchdog puts it back. The previous version cleared the interval here and
   * never restarted it, so one teardown killed the rail in that tab for good.
   */
  function teardown() {
    clearTimeout(showTimer)
    clearTimeout(hideTimer)
    clearTimeout(hideGraceTimer)
    dropFrame()          // also releases the sidebar slot
    ownsSlot = false
    host?.remove()
    host = shadow = panel = grip = frame = null
    expanded = false
    document.body.style.marginLeft = ''
    document.body.style.marginRight = ''
    delete document.body.dataset.sdbrRail
    delete document.body.dataset.sdbrRailShift
    clearPageShift()
  }

  /**
   * The extension context is gone. Stop every timer, remove the zombie UI and
   * tell the user what happened. The hint is built from plain DOM on purpose:
   * nothing that needs chrome.* may be used at this point.
   */
  function shutdown() {
    if (dead) return
    dead = true
    clearInterval(watchdog)
    clearTimeout(showTimer)
    clearTimeout(hideTimer)
    clearTimeout(lastOpenTimer)
    teardown()
    // A freshly injected instance may already have taken over (the worker
    // re-injects rail.js into open tabs right after an extension reload). In
    // that case the rail is fine and the hint would be a lie.
    let successor = false
    try {
      const cur = window.__sdbrRail
      successor = !!window.__sdbrRailTakeover || (!!cur && cur !== publicApi && !!cur.alive)
    } catch (e) { successor = !!window.__sdbrRailTakeover }
    if (!successor) showReloadHint()
    try { if (window.__sdbrRail === publicApi) window.__sdbrRail = null } catch (e) {}
  }

  function showReloadHint() {
    try {
      if (document.getElementById('sdbr-rail-reload-hint')) return
      const el = document.createElement('div')
      el.id = 'sdbr-rail-reload-hint'
      el.textContent = 'Sidechery reloaded — the rail in this tab is inactive. It will come back on its own, or refresh the tab.'
      el.setAttribute('style',
        'all:initial;position:fixed;z-index:2147483647;top:12px;left:50%;transform:translateX(-50%);' +
        'max-width:80vw;background:#231c2f;color:#fff;font:12px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;' +
        'padding:9px 14px;border-radius:9px;box-shadow:0 6px 24px rgba(0,0,0,.45);pointer-events:none;opacity:.96')
      document.documentElement.appendChild(el)
      setTimeout(() => { try { el.remove() } catch (e) {} }, 9000)
    } catch (e) { /* detached document */ }
  }

  /** Rebuild from scratch, preserving whatever state we still know. */
  function rebuild() {
    const wasExpanded = expanded
    expanded = false
    frame = null
    build()
    if (S.pinned || wasExpanded || lastOpenValue) open(true)
  }

  /** Expand the way the user left it (pinned wins over the remembered state). */
  async function revive() {
    let last = false
    try {
      const r = await api(() => B.storage.local.get('rail_last_open'))
      last = !!r?.rail_last_open
    } catch (e) { if (isCtxError(e)) shutdown(); last = false }
    if (S.pinned || last) open(true)
  }

  function startWatchdog() {
    clearInterval(watchdog)
    watchdog = setInterval(() => {
      if (dead) return
      // Proactively notice an invalidated context instead of waiting for the
      // next call to throw.
      if (!contextAlive()) { shutdown(); return }
      if (!S.enabled) return
      if (!host || !host.isConnected) { rebuild(); return }
      // A claim can be denied (another tab owns the slot); retry only while we
      // are the visible, expanded tab and were not explicitly evicted.
      if (expanded && !frame && tabVisible() && !claiming && !evicted) ensureFrame()
    }, 1500)
  }

  async function init() {
    if (dead || !contextAlive()) { shutdown(); return }
    await loadSettings()
    if (dead) return
    // Ask the worker to re-assert the side-panel state; it also answers with
    // the authoritative settings, so a fresh tab cannot go out of sync.
    try {
      const r = await api(() => B.runtime.sendMessage({ __sdbrRail: 1, action: 'ready' }))
      if (r?.settings) S = migrate(r.settings)
    } catch (e) { if (isCtxError(e)) { shutdown(); return } }
    if (!S.enabled) { startWatchdog(); return }
    if (!SIDEBAR_URL) { startWatchdog(); return }   // dead on arrival
    build()
    await revive()
    // build() starts the watchdog; it also survives SPAs wiping foreign nodes.
  }

  /* ------------------------------------------------------------- messaging */

  try { B.runtime.onMessage.addListener(msg => {
    if (!msg || !msg.__sdbrRail) return
    if (msg.action === 'settings' && msg.settings) {
      const prev = S.enabled
      S = migrate(msg.settings)
      if (!S.enabled) { teardown(); return }
      if (!host) { build(); if (S.pinned) open(true) }
      else {
        applyVars()
        const pin = shadow?.querySelector('.head button')
        if (pin) pin.dataset.on = S.pinned ? '1' : '0'
        if (S.pinned) open(true)
        else if (prev && !expanded) close(true)
      }
    } else if (msg.action === 'toggle') {
      if (!host) { build(); open(true) }
      else if (expanded) close(true)
      else open(true)
    } else if (msg.action === 'open') {
      if (!host || !host.isConnected) rebuild()
      open(true)
    } else if (msg.action === 'close') {
      close(true)
    } else if (msg.action === 'restore') {
      // Coming back from a page that could not host the rail: mount if needed
      // and restore the exact state (pinned stays pinned, hovered stays open).
      if (!S.enabled) return
      if (!host || !host.isConnected) rebuild()
      else revive()
    } else if (msg.action === 'dropSidebar') {
      // Another tab in this window took the sidebar slot. Collapse as well:
      // staying expanded would make the watchdog re-claim on the next switch
      // and the two tabs would keep evicting each other.
      clearTimeout(hideGraceTimer)
      evicted = true
      dropFrame()
      close(true)
    } else if (msg.action === 'teardown') {
      teardown()
    }
  }) } catch (e) { if (isCtxError(e)) shutdown() }

  try { B.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.rail_settings) return
    const next = migrate(changes.rail_settings.newValue)
    S = next
    if (!next.enabled) { teardown(); return }
    // Self-heal: an enabled rail must always have a host, no matter what
    // happened to it before.
    if (!host || !host.isConnected) { rebuild(); return }
    applyVars()
    const pin = shadow?.querySelector('.head button')
    if (pin) pin.dataset.on = S.pinned ? '1' : '0'
  }) } catch (e) { if (isCtxError(e)) shutdown() }

  window.addEventListener('resize', () => {
    S.width = clampW(S.width)
    host?.style.setProperty('--w', S.width + 'px')
  })

  // Leaving the tab must release the sidebar slot immediately: the tab that
  // becomes visible will claim it and start its own instance.
  document.addEventListener('visibilitychange', () => {
    if (dead) return
    if (document.visibilityState === 'hidden') {
      if (S.keepSidebarAlive) return       // keep the instance: no tree rebuild
      // Legacy per-tab behaviour: release after a grace period. Correctness
      // does not depend on it — if another tab claims the slot meanwhile, the
      // background sends `dropSidebar` and we release at once.
      clearTimeout(hideGraceTimer)
      hideGraceTimer = setTimeout(() => {
        if (document.visibilityState === 'hidden') dropFrame()
      }, HIDE_GRACE)
    } else {
      clearTimeout(hideGraceTimer)
      // Re-create if we are expanded without a frame. Claiming here is safe:
      // the background refuses to take the slot from a live, active owner, and
      // a visible tab is by definition the active one.
      if (expanded && S.enabled && !frame) ensureFrame()
    }
  })

  // Navigating away or closing the tab must free the slot immediately.
  window.addEventListener('pagehide', () => { if (!dead) dropFrame() })

  const publicApi = {
    get settings() { return pickSettings() },
    get alive() { return contextAlive() },
    get isDead() { return dead },
    get ownsSidebarSlot() { return ownsSlot },
    get hasFrame() { return !!frame },
    get evicted() { return evicted },
    open: () => open(true),
    close: () => close(true),
    toggle: () => (expanded ? close(true) : open(true)),
    revive,
    rebuild,
    destroy: teardown,
    shutdown,
    set: patch => saveSettings(patch),
  }
  window.__sdbrRail = publicApi
  try { delete window.__sdbrRailTakeover } catch (e) { window.__sdbrRailTakeover = undefined }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true })
  } else {
    init()
  }
})()
