/**
 * Sidechery in-page rail — background controller
 * ---------------------------------------------------------------------------
 * Appended to the end of bg/background.js. The synchronous half lives in the
 * prelude at the very top of the same file.
 *
 * Design notes (all three came from real bugs):
 *
 * 1. Only documented sidePanel API is used. `setOptions({path:''})` is NOT a
 *    documented way to disable a panel (`path` must be "a local resource
 *    within the extension package"), and on some builds it leaves the panel
 *    armed. The documented way is `enabled:false`, plus `close()` (141+) to
 *    dismiss a panel that is already open.
 *
 * 2. `sidePanel.open()` "may only be called in response to a user action".
 *    `tabs.onActivated` is not one, so the panel CANNOT be opened
 *    automatically when the user switches to a new tab. What we can do — and
 *    do — is arm it and flip `openPanelOnActionClick` on, so a single click on
 *    the toolbar icon opens it.
 *
 * 3. Every mutation of Chrome state goes through one serialized queue. The
 *    previous version let a debounced re-apply race with the tab-tracking
 *    path, and the loser of that race skipped the broadcast that brings the
 *    rail back.
 * ---------------------------------------------------------------------------
 */
;(() => {
  'use strict'

  const API = globalThis.browser?.runtime?.id ? globalThis.browser : globalThis.chrome
  const TAG = '[sidechery rail]'
  const SCHEMA = 6

  const RAIL_DEFAULTS = {
    schema: SCHEMA,
    enabled: true,
    width: 280,
    edge: 'left',
    collapsedWidth: 6,
    autoHide: true,
    pinned: false,
    showDelay: 120,
    hideDelay: 450,
    dimWhenCollapsed: true,
    shiftPage: true,
    // Sidebery activates a real Chrome tab on every panel switch; the rail has
    // to recreate the sidebar on each tab switch, so this must stay off.
    preventTabActivation: true,
    savedActivateLastTab: null,
    keepSidebarAlive: true,
    frameBg: '#231c2f',
    toolbarBg: '#3a3346',
    accent: '',
  }

  const SIDEBAR_PATH = 'sidebar/sidebar.html'

  /**
   * Older builds shipped `shiftPage: false` as the default and persisted every
   * key, so an upgrade would silently keep the old overlay behaviour. The
   * schema stamp makes that a one-time correction instead of a permanent one.
   */
  function migrate(raw) {
    const s = Object.assign({}, RAIL_DEFAULTS, raw || {})
    const v = Number(raw?.schema) || 0
    if (v < 4) s.shiftPage = RAIL_DEFAULTS.shiftPage
    s.schema = SCHEMA
    return s
  }

  /* ------------------------------------------------- Sidebery's own settings *
   * `activateLastTabOnPanelSwitching` makes Sidebery call
   * tabs.update(id, {active: true}) whenever it switches panels
   * (Tabs.activateLastActiveTabOf). A normal sidebar does that once per panel
   * click; the rail's sidebar is recreated on every tab switch, so it fired
   * constantly and visibly hijacked the focus.
   *
   * Patching the compiled default is not enough — Sidebery merges stored
   * settings over the defaults — so while the rail is on we hold the stored
   * value down, remember what it was, and put it back when the rail is off.
   */
  let writingSideberySettings = false

  async function readSideberySettings() {
    try {
      const r = await API.storage.local.get('settings')
      return r?.settings && typeof r.settings === 'object' ? r.settings : null
    } catch (e) { return null }
  }

  async function writeSideberySettings(patch) {
    const cur = await readSideberySettings()
    if (!cur) return false
    writingSideberySettings = true
    try {
      await API.storage.local.set({ settings: Object.assign({}, cur, patch) })
      return true
    } finally {
      setTimeout(() => { writingSideberySettings = false }, 0)
    }
  }

  /** Returns a rail_settings patch when the memo had to change. */
  async function enforceTabActivation(s) {
    if (!s.enabled || !s.preventTabActivation) return restoreTabActivation(s)
    const cur = await readSideberySettings()
    if (!cur) return null                       // fresh profile: patched default applies
    if (cur.activateLastTabOnPanelSwitching === false) return null
    const memo = s.savedActivateLastTab === null || s.savedActivateLastTab === undefined
      ? !!cur.activateLastTabOnPanelSwitching
      : s.savedActivateLastTab
    await writeSideberySettings({ activateLastTabOnPanelSwitching: false })
    console.info(`${TAG} activateLastTabOnPanelSwitching forced off (was ${memo}); ` +
      `it would steal the focus on every tab switch. Set preventTabActivation:false to opt out.`)
    return { savedActivateLastTab: memo }
  }

  async function restoreTabActivation(s) {
    const memo = s.savedActivateLastTab
    if (memo === null || memo === undefined) return null
    const cur = await readSideberySettings()
    if (cur && cur.activateLastTabOnPanelSwitching !== !!memo) {
      await writeSideberySettings({ activateLastTabOnPanelSwitching: !!memo })
      console.info(`${TAG} activateLastTabOnPanelSwitching restored to ${!!memo}`)
    }
    return { savedActivateLastTab: null }
  }

  /** Persist a rail_settings patch without re-entering the whole sync path. */
  async function memoSettings(patch) {
    if (!patch) return
    const next = migrate(Object.assign({}, await getSettings(), patch))
    await API.storage.local.set({ rail_settings: next })
  }

  /* --------------------------------------------------------- url support */

  const UNSUPPORTED = /^(chrome|chrome-extension|chrome-untrusted|chrome-search|edge|about|devtools|view-source|moz-extension):/i
  const WEBSTORE = /^https:\/\/(?:chrome\.google\.com\/webstore|chromewebstore\.google\.com)\//i

  /** Content scripts cannot run here, so the rail cannot exist here. */
  function railSupportsUrl(url) {
    if (!url) return false
    if (WEBSTORE.test(url)) return false
    return /^https?:/i.test(url) && !UNSUPPORTED.test(url)
  }

  /* ------------------------------------------------------------ settings */

  async function getSettings() {
    try {
      const r = await API.storage.local.get('rail_settings')
      return migrate(r.rail_settings)
    } catch (e) {
      return Object.assign({}, RAIL_DEFAULTS)
    }
  }

  async function setSettings(patch) {
    const next = migrate(Object.assign({}, await getSettings(), patch || {}))
    await API.storage.local.set({ rail_settings: next })
    await syncChromeState(next)
    broadcast({ __sdbrRail: 1, action: 'settings', settings: next })
    return next
  }

  /* ------------------------------------------------- serialized mutations */

  let queue = Promise.resolve()
  function serial(fn) {
    const run = queue.then(fn, fn)
    queue = run.then(() => {}, () => {})
    return run
  }

  const safe = (label, p) => Promise.resolve(p).catch(e => {
    console.warn(TAG, label, 'failed:', e?.message || e)
  })

  /* ------------------------------------------------- sidebar slot ownership *
   * Sidechery's IPC keeps ONE sidebar connection per browser window
   * (`sidebarConnections` is a Map keyed by windowId). The rail renders the
   * sidebar in an iframe, and an iframe exists per tab — so without a lock,
   * every tab in a window would register as the sidebar for that window,
   * overwriting each other. The losers keep reconnecting
   * ("IPC.request bg: cacheTabsData: No port, or closed state") and several
   * instances rebuild the same tab tree at once, which shows up as tabs
   * spontaneously losing their groups.
   *
   * Therefore: exactly one tab per window may hold a live sidebar iframe, and
   * the background is the authority on which one that is.
   */
  const sidebarOwner = new Map()   // windowId -> tabId

  function tellTab(tabId, action) {
    if (tabId === undefined || tabId === null) return
    API.tabs.sendMessage(tabId, { __sdbrRail: 1, action }).catch?.(() => {})
  }

  async function claimSidebar(tabId, windowId) {
    if (tabId === undefined || tabId === null) return { granted: false }
    const wid = windowId ?? activeWindowId
    if (wid === undefined || wid === null) return { granted: true }   // unknown window: do not block
    const cur = sidebarOwner.get(wid)
    if (cur === tabId) return { granted: true, windowId: wid }

    if (cur !== undefined) {
      // Recreating the sidebar is destructive: Sidebery restores the tab tree
      // from saved per-tab props, and if the previous instance was killed
      // before its debounced save ran, the tree comes back flat and branches
      // migrate. So the slot is only taken away from an owner that is gone or
      // no longer the active tab — never from a live one.
      let ownerAlive = false
      try {
        const t = await API.tabs.get(cur)
        ownerAlive = !!t && t.windowId === wid && !!t.active
      } catch (e) { ownerAlive = false }
      if (ownerAlive) return { granted: false, reason: 'owned', owner: cur }
      tellTab(cur, 'dropSidebar')
    }
    sidebarOwner.set(wid, tabId)
    return { granted: true, windowId: wid }
  }

  function releaseSidebar(tabId, windowId) {
    const wid = windowId ?? activeWindowId
    if (wid !== undefined && sidebarOwner.get(wid) === tabId) sidebarOwner.delete(wid)
  }

  /** Hand the slot over when the user switches tabs inside a window. */
  function transferSidebar(windowId, newTabId) {
    const cur = sidebarOwner.get(windowId)
    if (cur === newTabId) return
    if (cur !== undefined) tellTab(cur, 'dropSidebar')
    sidebarOwner.delete(windowId)   // the newly visible tab claims it itself
  }

  /* --------------------------------------------------- active tab tracking */

  let activeTabId = null
  let activeTabUrl = ''
  let activeWindowId = null
  const activeTabByWin = new Map()

  // 'off' = rail disabled, the native panel owns everything
  // 'rail' = rail is the sidebar, native panel disabled and closed
  // 'panel' = rail is on, but this tab cannot host it => native panel stands in
  let panelMode = 'unknown'
  let panelOpen = false

  async function noteActiveTab(tabId) {
    try {
      const tab = await API.tabs.get(tabId)
      if (!tab) return
      activeTabId = tabId
      activeTabUrl = tab.url || ''
      if (tab.windowId !== undefined) {
        activeWindowId = tab.windowId
        activeTabByWin.set(tab.windowId, tabId)
      }
    } catch (e) { return }
    serial(syncChromeState).catch(() => {})
  }

  async function noteActiveTabOfWindow(windowId) {
    try {
      const [tab] = await API.tabs.query({ active: true, windowId })
      if (tab?.id) await noteActiveTab(tab.id)
    } catch (e) { /* ignore */ }
  }

  /* ------------------------------------------------------ state machine */

  function wantedMode(s) {
    if (!s.enabled) return 'off'
    return railSupportsUrl(activeTabUrl) ? 'rail' : 'panel'
  }

  /**
   * The only function allowed to touch sidePanel state. Idempotent: calling it
   * twice in a row must not flicker the panel or re-broadcast needlessly.
   */
  async function syncChromeState(settings) {
    const s = settings || await getSettings()
    const want = wantedMode(s)

    // The toolbar click must never be swallowed by Chrome while the rail is
    // the sidebar; on stand-in pages we hand the click back to the panel.
    globalThis.__sdbrRailMode = !!s.enabled
    globalThis.__sdbrRailState = s

    const memo = await enforceTabActivation(s)
    if (memo) await memoSettings(memo)

    if (want !== panelMode) {
      const prev = panelMode
      panelMode = want

      if (want === 'rail') {
        await safe('setPanelBehavior', API.sidePanel?.setPanelBehavior?.({ openPanelOnActionClick: false }))
        if (panelOpen && activeWindowId !== null) {
          await safe('close(window)', API.sidePanel?.close?.({ windowId: activeWindowId }))
        }
        await safe('setOptions(disable)', API.sidePanel?.setOptions?.({ enabled: false }))
        panelOpen = false
        console.info(`${TAG} ${globalThis.__sdbrRailBuild || '?'} | mode rail | panel disabled` +
          (prev === 'panel' ? ' (stand-in withdrawn)' : ''))
        // Ask every tab to bring the rail back the way the user left it.
        broadcast({ __sdbrRail: 1, action: 'restore' })
      } else if (want === 'panel') {
        await safe('setOptions(arm)', API.sidePanel?.setOptions?.({ path: SIDEBAR_PATH, enabled: true }))
        await safe('setPanelBehavior', API.sidePanel?.setPanelBehavior?.({ openPanelOnActionClick: true }))
        console.info(`${TAG} ${globalThis.__sdbrRailBuild || '?'} | mode panel | active tab ` +
          `${activeTabUrl || '?'} cannot host the rail; panel armed, ` +
          `click the toolbar icon to open it (open() needs a user gesture)`)
      } else {
        await safe('setOptions(restore)', API.sidePanel?.setOptions?.({ path: SIDEBAR_PATH, enabled: true }))
        await safe('setPanelBehavior', API.sidePanel?.setPanelBehavior?.({ openPanelOnActionClick: true }))
        console.info(`${TAG} ${globalThis.__sdbrRailBuild || '?'} | mode off | native panel restored`)
      }
    } else if (want === 'rail') {
      // Re-assert without changing mode: Chrome resets panel state on window
      // and session changes, and the worker is killed at will.
      await safe('setPanelBehavior', API.sidePanel?.setPanelBehavior?.({ openPanelOnActionClick: false }))
      await safe('setOptions(disable)', API.sidePanel?.setOptions?.({ enabled: false }))
    }
    return s
  }

  async function broadcast(msg) {
    try {
      const tabs = await API.tabs.query({})
      for (const tab of tabs) {
        if (!tab?.id || !railSupportsUrl(tab.url)) continue
        API.tabs.sendMessage(tab.id, msg).catch?.(() => {})
      }
    } catch (e) { /* ignore */ }
  }

  /* ------------------------------------------------------------- toggling */

  let toggling = null
  function toggleRail(force) {
    if (toggling) return toggling
    toggling = (async () => {
      const cur = await getSettings()
      const next = force === undefined ? !cur.enabled : !!force
      console.info(`${TAG} toggle: rail ${cur.enabled} -> ${next}`)
      const s = await setSettings({ enabled: next })
      broadcast({ __sdbrRail: 1, action: next ? 'restore' : 'teardown' })
      return s
    })().finally(() => { toggling = null })
    return toggling
  }

  /* ----------------------------------------------------------- messaging */

  API.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.__sdbrRail) return

    if (msg.action === 'ready') {
      serial(() => getSettings().then(s => syncChromeState(s).then(() => s)))
        .then(s => sendResponse({ settings: s, panelMode, activeTabUrl }))
        .catch(() => sendResponse({ settings: Object.assign({}, RAIL_DEFAULTS) }))
      return true
    }
    if (msg.action === 'getSettings' || msg.action === 'status') {
      ;(async () => {
        const [s, sb] = await Promise.all([getSettings(), readSideberySettings()])
        sendResponse({
          settings: s,
          build: globalThis.__sdbrRailBuild,
          mode: globalThis.__sdbrRailMode,
          ready: globalThis.__sdbrRailReady,
          panelMode,
          panelOpen,
          activeTabId,
          activeTabUrl,
          activeTabSupportsRail: railSupportsUrl(activeTabUrl),
          sidebarOwners: Object.fromEntries(sidebarOwner),
          sideberyActivateLastTab: sb?.activateLastTabOnPanelSwitching,
        })
      })().catch(() => {})
      return true
    }
    if (msg.action === 'settings') {
      setSettings(msg.settings).then(s => sendResponse({ settings: s })).catch(() => {})
      return true
    }
    if (msg.action === 'claimSidebar') {
      claimSidebar(sender?.tab?.id, sender?.tab?.windowId)
        .then(r => sendResponse(r))
        .catch(() => sendResponse({ granted: false }))
      return true
    }
    if (msg.action === 'releaseSidebar') {
      releaseSidebar(sender?.tab?.id, sender?.tab?.windowId)
      sendResponse({ ok: true })
      return
    }
    if (msg.action === 'toggle') { toggleRail(); return }
    if (msg.action === 'enable') { toggleRail(true); return }
    if (msg.action === 'disable') { toggleRail(false); return }
    if (msg.action === 'openOptions') {
      API.runtime.openOptionsPage?.().catch?.(() => {})
      return
    }
    if (msg.action === 'openPanel') {
      // Called from a click inside the rail, so a user gesture exists.
      const tabId = sender?.tab?.id ?? activeTabId
      const winId = sender?.tab?.windowId ?? activeWindowId
      ;(async () => {
        await safe('setOptions(arm)', API.sidePanel?.setOptions?.({ path: SIDEBAR_PATH, enabled: true }))
        const opened = await safe('sidePanel.open',
          tabId != null ? API.sidePanel?.open?.({ tabId }) : API.sidePanel?.open?.({ windowId: winId }))
        if (opened === undefined && API.sidePanel?.open) {
          panelOpen = true
          panelMode = 'panel'
        }
      })()
      return
    }
  })

  API.commands.onCommand.addListener(cmd => {
    if (cmd === 'toggle_rail') toggleRail()
  })

  // The icon toggles the rail — except on pages that cannot host it, where it
  // opens the stand-in panel instead of switching the rail off behind the
  // user's back.
  API.action.onClicked.addListener(() => {
    const s = globalThis.__sdbrRailState
    if (s?.enabled && !railSupportsUrl(activeTabUrl)) {
      const tabId = activeTabId
      ;(async () => {
        await safe('setOptions(arm)', API.sidePanel?.setOptions?.({ path: SIDEBAR_PATH, enabled: true }))
        await safe('sidePanel.open', API.sidePanel?.open?.({ tabId }))
      })()
      return
    }
    toggleRail()
  })

  // Know when the panel really opens/closes so close() is only called when
  // there is something to close.
  API.sidePanel?.onOpened?.addListener(info => {
    panelOpen = true
    if (info?.windowId !== undefined) activeWindowId = info.windowId
  })
  API.sidePanel?.onClosed?.addListener(() => { panelOpen = false })

  /* -------------------------------------------------------------- events */

  let reapplyTimer = 0
  function reapplySoon() {
    clearTimeout(reapplyTimer)
    reapplyTimer = setTimeout(() => { serial(syncChromeState).catch(() => {}) }, 250)
  }

  API.tabs.onActivated?.addListener(info => {
    if (info?.windowId !== undefined) transferSidebar(info.windowId, info.tabId)
    if (info?.tabId) noteActiveTab(info.tabId)
  })
  API.tabs.onUpdated?.addListener((tabId, change, tab) => {
    if (!change?.url && !change?.status) return
    if (!tab?.active) return
    activeTabId = tabId
    activeTabUrl = tab.url || ''
    if (tab.windowId !== undefined) {
      activeWindowId = tab.windowId
      activeTabByWin.set(tab.windowId, tabId)
    }
    serial(syncChromeState).catch(() => {})
  })
  API.tabs.onRemoved?.addListener((tabId, info) => {
    if (info?.windowId !== undefined && sidebarOwner.get(info.windowId) === tabId) {
      sidebarOwner.delete(info.windowId)
    }
    if (info?.windowId !== undefined && activeTabByWin.get(info.windowId) === tabId) {
      activeTabByWin.delete(info.windowId)
      if (activeTabId === tabId) { activeTabId = null; activeTabUrl = '' }
    }
  })
  API.webNavigation?.onCompleted?.addListener(d => {
    if (d?.frameId !== 0) return
    ;(async () => {
      try {
        const tab = await API.tabs.get(d.tabId)
        if (!tab?.active) return
        activeTabId = d.tabId
        activeTabUrl = tab.url || ''
        if (tab.windowId !== undefined) {
          activeWindowId = tab.windowId
          activeTabByWin.set(tab.windowId, d.tabId)
        }
      } catch (e) { return }
      serial(syncChromeState).catch(() => {})
    })()
  })
  API.windows.onRemoved?.addListener(w => { sidebarOwner.delete(w) })
  API.windows.onFocusChanged?.addListener(w => {
    if (w === -1) return
    activeWindowId = w
    const tabId = activeTabByWin.get(w)
    if (tabId) noteActiveTab(tabId)
    else noteActiveTabOfWindow(w)
  })

  /**
   * Reloading the extension invalidates the context of every content script
   * already on a page, which used to leave a zombie rail behind and forced the
   * user to refresh each tab by hand. We can do that for them: `scripting` is
   * in the manifest and `<all_urls>` is granted, so re-injecting rail.js gives
   * every open tab a live instance. The dying instance detects the successor
   * through `window.__sdbrRail.alive` and steps aside quietly.
   */
  async function reinjectEverywhere(reason) {
    if (!API.scripting?.executeScript) return
    try {
      const tabs = await API.tabs.query({})
      let done = 0
      let skipped = 0
      for (const tab of tabs) {
        if (!tab?.id || !railSupportsUrl(tab.url)) { skipped++; continue }
        try {
          await API.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['rail/rail.js'],
          })
          done++
        } catch (e) { skipped++ }
      }
      console.info(`${TAG} re-injected the rail into ${done} tab(s) after ${reason}` +
        (skipped ? `, ${skipped} skipped` : ''))
    } catch (e) {
      console.warn(TAG, 're-injection failed:', e?.message || e)
    }
  }

  let reassertTimer = 0
  API.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.settings || writingSideberySettings) return
    const v = changes.settings.newValue?.activateLastTabOnPanelSwitching
    if (v !== true) return
    clearTimeout(reassertTimer)
    reassertTimer = setTimeout(() => { serial(syncChromeState).catch(() => {}) }, 300)
  })

  API.runtime.onInstalled.addListener(details => {
    serial(syncChromeState)
      .then(() => reinjectEverywhere(details?.reason || 'install'))
      .catch(() => {})
  })
  API.runtime.onStartup.addListener(() => { serial(syncChromeState).catch(() => {}) })

  /* ------------------------------------------------------------- startup */

  serial(async () => {
    try {
      const [tab] = await API.tabs.query({ active: true, lastFocusedWindow: true })
      if (tab?.id) {
        activeTabId = tab.id
        activeTabUrl = tab.url || ''
        if (tab.windowId !== undefined) {
          activeWindowId = tab.windowId
          activeTabByWin.set(tab.windowId, tab.id)
        }
      }
    } catch (e) { /* ignore */ }
    // panelMode must reflect reality before the first sync, otherwise sync
    // sees no transition and skips the calls that actually configure Chrome.
    const s = await getSettings()
    panelMode = 'unknown'
    await syncChromeState(s)
    // Force the first configuration through even if `want` looks unchanged.
    await safe('setPanelBehavior', API.sidePanel?.setPanelBehavior?.({
      openPanelOnActionClick: wantedMode(s) !== 'rail',
    }))
    if (wantedMode(s) === 'rail') {
      await safe('setOptions(disable)', API.sidePanel?.setOptions?.({ enabled: false }))
      broadcast({ __sdbrRail: 1, action: 'restore' })
    }
  }).catch(() => {})

  /* --------------------------------------------------------- diagnostics */

  globalThis.__sdbrRailToggle = toggleRail
  globalThis.__sdbrRailReinject = () => reinjectEverywhere('manual')
  globalThis.__sdbrRailSync = () => serial(syncChromeState)
  globalThis.__sdbrRailStatus = async () => ({
    build: globalThis.__sdbrRailBuild,
    mode: globalThis.__sdbrRailMode,
    ready: globalThis.__sdbrRailReady,
    panelMode,
    panelOpen,
    activeTabId,
    activeTabUrl,
    activeTabSupportsRail: railSupportsUrl(activeTabUrl),
    sidebarOwners: Object.fromEntries(sidebarOwner),
    sideberyActivateLastTab: (await readSideberySettings())?.activateLastTabOnPanelSwitching,
    settings: await getSettings(),
  })
})()
