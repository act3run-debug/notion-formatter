# Tracker Support | CTPAY: создание задачи выплат из формы, подзадачи по центрам, назначения, rollup
# runtime python311, entrypoint index.handler, env: TOKEN (OAuth), ORG (X-Cloud-Org-Id)
import os, json, requests

T = "https://api.tracker.yandex.net/v3"
F = "https://api.forms.yandex.net/v1"
TOKEN = os.environ["TOKEN"]
ORG = os.environ["ORG"]
QH = {"Authorization": "OAuth " + TOKEN, "X-Cloud-Org-Id": ORG, "Content-Type": "application/json"}
QF = "6ac4d15ff8fd033006da508f--"          # префикс локальных полей CTPAY
FORM = "6ac4d1d6b93f980e66d68e1d"
QUEUE, T_PAY, T_CTR = "CTPAY", "ctpayPayment", "ctpayCenter"
S_CHECK, S_DONE, A_FINAL = "ctpCenterCheck", "ctpCenterDone", "toFinalCheck"


def api(m, p, b=None):
    r = requests.request(m, T + p, headers=QH, json=b)
    r.raise_for_status()
    return r.json() if r.text else {}


def users():
    """Карта всех пользователей Трекера: passportUid / cloudUid / c:cloudUid / email / login -> user."""
    m, page = {}, 1
    while page < 20:
        r = api("GET", f"/users?perPage=500&page={page}")
        if not isinstance(r, list) or not r:
            break
        for u in r:
            for k in (u.get("passportUid"), u.get("cloudUid"), u.get("email"), u.get("login")):
                if k:
                    m[str(k)] = u
            if u.get("cloudUid"):
                m["c:" + u["cloudUid"]] = u
        page += 1
    return m


def resolve(ref, label, um):
    """id участника из формы ('2260158543' или 'c:<cloudUid>') -> пользователь Трекера."""
    u = um.get(str(ref))
    if u:
        return u
    try:  # запасной путь: suggest формы по имени
        s = requests.get(f"{F}/surveys/{FORM}/suggest", headers=QH,
                         params={"question": "cra", "text": label or ""}).json()
        for x in s if isinstance(s, list) else []:
            if str(x.get("id")) == str(ref):
                return {"cloudUid": x.get("cloud_uid"), "display": x.get("text") or label,
                        "login": x.get("login"), "email": x.get("email")}
    except Exception:
        pass
    cu = str(ref)[2:] if str(ref).startswith("c:") else None
    return {"cloudUid": cu, "display": label} if cu else None


def create_from_answer(aid, email):
    """Этап 1: ответ формы -> задача «Выплата КИ» со всеми полями."""
    ans = requests.get(f"{F}/answers", headers=QH, params={"answer_id": aid}).json()
    d = {q["id"]: q for q in ans["data"]}
    port = d["portfolio"]["value"][0]                      # {"id": "<shortId проекта>", "label": ...}
    cutoff, acts = d["cutoff"]["value"], d["actsend"]["value"]
    um = users()
    proj = {}
    try:
        proj = api("GET", f"/projects/{port['id']}")
    except Exception:
        pass
    lines, cras = [], {}
    for row in d["centers"]["value"]:
        r = {x["id"]: x for x in row}
        name = str(r["center"]["value"]).strip()
        ref = (r["cra"]["value"] or [{}])[0]
        u = resolve(ref.get("id"), ref.get("label"), um)
        if not u or not u.get("cloudUid"):
            continue
        lines.append(f"{name}|{u['cloudUid']}|{u.get('display') or u['cloudUid']}")
        cras[u["cloudUid"]] = {"cloudUid": u["cloudUid"]}
    body = {
        "queue": QUEUE, "type": T_PAY,
        "summary": f"Выплаты КИ: {port.get('label')}, срез {cutoff}",
        "deadline": acts,
        QF + "portfolio": port.get("label"),
        QF + "cutoffDate": cutoff,
        QF + "actsEndDate": acts,
        QF + "centers": "\n".join(lines),
        QF + "cras": list(cras.values()),
        "description": (f"Процесс выплат запущен через форму: https://forms.yandex.ru/cloud/{FORM}/ "
                        f"(ответ {aid}).\nПортфель проекта: {port.get('label')}\n"
                        f"Дата среза: {cutoff}\nДата окончания генерации актов: {acts}\n"
                        f"Центры и ответственные CRA:\n" +
                        "\n".join(f"— {l.split('|')[0]} ({l.split('|')[2]})" for l in lines)),
    }
    lead = proj.get("lead") or {}
    if lead.get("id"):
        body[QF + "sad"] = {"id": lead["id"]}
    author = email and (um.get(str(email)) or {}).get("login")
    if author:
        body["author"] = author
    return api("POST", "/issues", body)["key"]


def children(key):
    """Подзадачи задачи (связи subtask, direction outward)."""
    out = []
    for l in api("GET", f"/issues/{key}/links"):
        if (l.get("type") or {}).get("id") == "subtask" and l.get("direction") == "outward":
            out.append(l["object"])
    return out


def centers(key):
    """Этап 6: создать подзадачи «Проверка центра» по строкам поля «Центры и CRA» (идемпотентно)."""
    i = api("GET", f"/issues/{key}")
    have = {c["display"] for c in children(key)}
    created = []
    for line in (i.get(QF + "centers") or "").split("\n"):
        if "|" not in line:
            continue
        name, cu, disp = (line.split("|") + ["", "", ""])[:3]
        summ = f"{key}: {name}"
        if summ in have:
            continue
        b = {"queue": QUEUE, "type": T_CTR, "summary": summ, "parent": {"key": key},
             "assignee": {"cloudUid": cu}, QF + "centerName": name,
             "description": (f"Проверьте данные генератора выплат по центру «{name}» "
                             f"(родительская задача {key}).\n"
                             f"После проверки переведите задачу в статус «Проверено CRA» — "
                             f"далее центр проверит SAD.")}
        if i.get("deadline"):
            b["deadline"] = i["deadline"]
        sad = i.get(QF + "sad")
        if sad:
            b[QF + "sad"] = {"id": sad["id"]}
        created.append(api("POST", "/issues", b)["key"])
    return created or None


def assign(key, to):
    """Назначить исполнителя: to='sad' — SAD из поля (или из родителя), to='author' — автор задачи."""
    i = api("GET", f"/issues/{key}")
    u = None
    if to == "sad":
        u = i.get(QF + "sad")
        if not u and i.get("parent"):
            u = api("GET", f"/issues/{i['parent']['key']}").get(QF + "sad")
    elif to == "author":
        u = i.get("createdBy")
    if u and u.get("id"):
        api("PATCH", f"/issues/{key}", {"assignee": {"id": u["id"]}})
        return u.get("display")
    return None


def rollup(key):
    """Этап 7: все подзадачи-центры проверены -> родительская задача на финальную проверку.

    Без гонки: статус только что закрытой подзадачи (key) не перечитывается — она точно
    в «Центр проверен» (триггер срабатывает на этом переходе); остальные читаются свежими.
    """
    i = api("GET", f"/issues/{key}")
    pk = (i.get("parent") or {}).get("key")
    if not pk:
        return None
    p = api("GET", f"/issues/{pk}")
    if (p.get("status") or {}).get("key") != S_CHECK:
        return None
    kids = [c["key"] for c in children(pk)]
    if not kids:
        return None
    for k in kids:
        if k == key:
            continue
        if (api("GET", f"/issues/{k}").get("status") or {}).get("key") != S_DONE:
            return None
    api("POST", f"/issues/{pk}/transitions/{A_FINAL}/_execute", {})
    return pk


def _dict(x):
    if isinstance(x, (bytes, bytearray)):
        x = x.decode("utf-8", "ignore")
    if isinstance(x, str):
        try:
            x = json.loads(x or "{}")
        except Exception:
            return {}
    return x if isinstance(x, dict) else {}


def resp(payload):
    return {"statusCode": 200, "headers": {"Content-Type": "application/json"},
            "body": json.dumps(payload, ensure_ascii=False)}


def handler(event, context):
    b = _dict(event)
    if "httpMethod" in b or "queryStringParameters" in b:  # HTTP-конверт рантайма
        b = {**(b.get("queryStringParameters") or {}), **_dict(b.get("body"))}
    if b.get("action") == "echo":
        return resp({"ok": True, "result": str(event)[:400]})
    if "answer_id" in b:
        return resp({"ok": True, "result": create_from_answer(b["answer_id"], b.get("email"))})
    r = {"centers": centers, "assign": lambda k: assign(k, b.get("to")), "rollup": rollup}[b["action"]](b["issue"])
    return resp({"ok": True, "result": r})
