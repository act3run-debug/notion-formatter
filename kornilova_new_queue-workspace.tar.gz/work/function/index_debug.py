import json

def handler(event, context):
    t = type(event).__name__
    if isinstance(event, dict):
        keys = ",".join(list(event.keys())[:15])
        body = event.get("body")
        return f"dict keys=[{keys}] body_type={type(body).__name__} body={str(body)[:200]}"
    return f"{t}: {str(event)[:300]}"
