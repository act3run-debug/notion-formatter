## Кандидаты в context.md (сквозные находки 2026-10-07, задача CTPAY)

### В раздел 5 (Tracker):
- Переход в статус: `POST /v3/issues/{key}/transitions/{actionId}/_execute` (actionId — из `GET /v3/workflows/{Wxx}`; workflows очереди: `GET /v3/queues/{key}/workflows` → карта Wxx→типы).
- Дочерние задачи: JSON-фильтр `{"parent": ...}` в `_search` ИГНОРИРУЕТСЯ (возвращает всё), QL-фильтра `Parent:` нет. Правильно — `GET /v3/issues/{key}/links`: связи `type.id=="subtask"`, у родителя `direction=="outward"` (дочерние), у ребёнка `"inward"` (родитель). В свежих связях `status` может отсутствовать — статусы детей перечитывать отдельными GET.
- `author` при создании задачи через API задаётся (`POST /issues {... "author": "<login>"}`) → `createdBy` станет он, а не владелец токена.
- Локальные поля при создании/PATCH — по полному id `"<queueVersionId>--<fieldKey>"`; `assignee`/user-поля принимают `{"id": uid}` и `{"cloudUid": ...}`; `type` — строкой-ключом (`"ctpayPayment"`).
- ГОНКА ВЕБХУКОВ: триггер с Webhook-действием дёргает функцию в ту же секунду, что и переход; если функция сразу перечитывает статус этой же задачи (или её связи), она может увидеть СТАРЫЕ данные → в rollup-логике статус триггернувшей задачи не перечитывать (считать известным из условия триггера), остальные читать свежими GET.

### В раздел 6 (Yandex Cloud Functions):
- Публичный HTTP-вызов функции (python311): event — КОНВЕРТ `{httpMethod, headers, url, params, queryStringParameters, requestContext, body(str), isBase64Encoded, ...}`, тело запроса — строкой в `body`. Handler ДОЛЖЕН вернуть `{"statusCode": 200, "headers": {...}, "body": json.dumps(payload)}`: возврат dict без body → 200 с ПУСТЫМ телом; возврат не-JSON-строки → 502 ProxyIntegrationError «not a valid json».
- CreateVersion без `tag` автоматически получает `$latest`; новая версия подхватывается сразу (проверка по заголовку ответа `X-Function-Version-Id`).
-Diagnostic-приём: код функции недоступен, но стектрейсы 502 показывают исходные строки; временная версия-«эхо» (`return str(event)`) вскрывает формат event.

### В раздел 7 (Forms):
- Отправка ответа через API: `POST /v1/surveys/{id}/form` (OAuth) с телом `{slug: value}`; enum — СПИСОК SLUG-ов вариантов (`["2786"]`, не числовые id), серия — список словарей `[{sub_slug: value}]`, suggest-люди — список id (`["c:<cloudUid>"]` федерация, `["<passportUid>"]` личный аккаунт), даты — ISO `YYYY-MM-DD`. Ошибки валидации возвращаются списком `[{loc,msg,error_code}]`.
- `dry_run=true` и даже реальная отправка возвращают `"correct": false, "integrations": []` — это НЕ признак ошибки; успешность интеграции проверять по эффекту (созданная задача/ответ `GET /v1/answers?answer_id=`).
-Resolving людей из ответа формы: в `GET /v1/answers?answer_id=` у suggest-вопросов `value: [{"id": "<passportUid>|c:<cloudUid>", "label": ...}]`; в Трекер маппится сканом `GET /v3/users?perPage=500&page=N` (~1038 чел., 3 страницы; сопоставление по passportUid/cloudUid/email/login) или `GET /v1/surveys/{id}/suggest?question=<slug>&text=<label>` (возвращает id/login/cloud_uid/email).
- Права на форму: `GET/POST /v1/surveys/{id}/access` (submit), `POST .../access/grant {action:"change",user:{cloud_uid}}` — выдача прав на правку другим пользователям.
