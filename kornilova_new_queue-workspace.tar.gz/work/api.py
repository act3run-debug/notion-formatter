"""Helper for Yandex Tracker / Forms API calls."""
import json, os, sys
import requests

TOKEN = os.environ.get("OAUTH", "y0__wgBEM-Q3bUIGPqsOiCu_fCDGTC40-KCCCHhEvRf0CXapaUvgQWDYH-0p-L0")
ORG = os.environ.get("ORG", "bpfb300ct6ef4t2kr3l1")

TR = "https://api.tracker.yandex.net"
FM = "https://api.forms.yandex.net"

def H(json_ct=True, oauth_scheme="Bearer"):
    h = {"Authorization": f"{oauth_scheme} {TOKEN}", "X-Cloud-Org-Id": ORG}
    if json_ct:
        h["Content-Type"] = "application/json"
    return h

def tr(method, path, body=None, base="/v3", raw=False, params=None, headers=None):
    url = f"{TR}{base}{path}"
    r = requests.request(method, url, headers=headers or H(), data=json.dumps(body) if body is not None else None, params=params, timeout=60)
    if raw:
        return r
    try:
        return r.json()
    except Exception:
        return {"_status": r.status_code, "_text": r.text[:2000]}

def fm(method, path, body=None, raw=False, params=None, headers=None, noauth=False):
    url = f"{FM}/v1{path}"
    h = H(json_ct=True, oauth_scheme="OAuth") if not noauth else {}
    if headers is not None:
        h = headers
    r = requests.request(method, url, headers=h, data=json.dumps(body) if body is not None else None, params=params, timeout=60)
    if raw:
        return r
    try:
        return r.json()
    except Exception:
        return {"_status": r.status_code, "_text": r.text[:2000]}

def pp(o):
    print(json.dumps(o, ensure_ascii=False, indent=1, default=str))
