import { chromium } from 'playwright-core';
import path from 'path';
const exec = path.resolve(process.cwd(), '..', 'env', 'chrome-linux64', 'chrome');
const extPath = path.resolve(process.cwd(), '..', 'extension-src');
const ctx = await chromium.launchPersistentContext('/tmp/pw-ext-profile', {
  executablePath: exec,
  headless: false,
  args: [
    '--no-sandbox', '--disable-gpu',
    `--disable-extensions-except=${extPath}`,
    `--load-extension=${extPath}`,
  ],
});
let sw;
if (ctx.serviceWorkers().length === 0) {
  sw = await ctx.waitForEvent('serviceworker', { timeout: 15000 });
} else {
  sw = ctx.serviceWorkers()[0];
}
console.log('SW URL:', sw.url());
const extId = sw.url().split('/')[2];
console.log('EXT ID:', extId);
const manifest = JSON.parse(await sw.evaluate(() => fetch(chrome.runtime.getURL('manifest.json')).then(r => r.text())));
console.log('manifest_version:', manifest.manifest_version, '| name:', manifest.name, '| version:', manifest.version);
await ctx.close();
console.log('EXT SMOKE OK');
