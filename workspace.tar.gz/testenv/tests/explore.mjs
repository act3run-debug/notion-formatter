// Разведка v2: закрепляем рейл, получаем sidebar iframe, изучаем DOM-селекторы дерева
import { launchExt, pinRail, railFrame, railInfo, outline, closeCtx, BASE } from './harness.mjs';

const ctx = await launchExt();
console.log('EXT:', ctx.sdbr.extId);
await pinRail(ctx);

const p1 = await ctx.newPage();
await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
await p1.waitForTimeout(1500);
console.log('--- railInfo p1:', JSON.stringify(await railInfo(p1)).slice(0, 300));
console.log('--- page outline:');
console.log(await outline(p1.mainFrame(), { root: 'body', depth: 4, max: 40 }));

const p2 = await ctx.newPage();
await p2.goto(`${BASE}/p2.html`, { waitUntil: 'domcontentloaded' });
const p3 = await ctx.newPage();
await p3.goto(`${BASE}/p3.html`, { waitUntil: 'domcontentloaded' });
await p3.waitForTimeout(2500);

try {
  const f = await railFrame(p3, 10000);
  console.log('--- sidebar iframe OK on p3');
  await p3.waitForTimeout(2500); // дать сайдбару отрисовать дерево
  console.log('--- sidebar outline (depth 7):');
  console.log(await outline(f, { root: 'body', depth: 7, max: 140 }));
} catch (e) {
  console.log('sidebar iframe NOT found:', e.message);
  console.log('--- p3 frames:', p3.frames().map(x => x.url().slice(0, 70)));
  console.log('--- p3 outline:', await outline(p3.mainFrame(), { depth: 4, max: 40 }));
}

await closeCtx(ctx);
console.log('EXPLORE2 DONE');
