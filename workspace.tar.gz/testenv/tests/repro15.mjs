// repro15: одна варианта, причина краша из stderr браузера
import { launchExt, setRailSettings, closeCtx, closeBlankPages, openPages, BASE } from './harness.mjs';
const sleep = ms => new Promise(r => setTimeout(r, ms));

const headless = process.env.HL === '1';
const ctx = await launchExt({ viewport: { width: 1000, height: 700 }, headless, minimalFlags: process.env.MIN === '1' });
let closed = false;
ctx.on('close', () => { closed = true; console.log('!! CONTEXT CLOSED'); });
await setRailSettings(ctx);
const p1 = await ctx.newPage();
await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
await closeBlankPages(ctx);
await openPages(ctx, [2, 3]);
await sleep(2500);
const r = await ctx.sdbr.sw.evaluate(async () => {
  const tabs = await chrome.tabs.query({ url: 'http://127.0.0.1:8901/p2.html' });
  const t = await chrome.tabs.discard(tabs[0].id);
  return !!t;
}).catch(e => 'ERR ' + e.message.slice(0, 60));
console.log('discard result:', r);
await sleep(2000);
let alive = 'DEAD';
try { alive = (await ctx.sdbr.sw.evaluate(async () => (await chrome.tabs.query({})).length)); } catch {}
console.log(`headless=${headless} ctxClosed=${closed} tabsAfter=${alive}`);
await closeCtx(ctx);
console.log('REPRO15 DONE');
