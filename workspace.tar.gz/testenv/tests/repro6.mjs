import { launchExt, setRailSettings, closeCtx, BASE, railReady } from './harness.mjs';
console.log('1. launching');
const ctx = await launchExt();
console.log('2. launched');
await setRailSettings(ctx);
console.log('3. settings written');
for (let i = 1; i <= 6; i++) {
  try {
    const p = await ctx.newPage();
    console.log(`4.${i} newPage ok`);
    await p.goto(`${BASE}/p${i}.html`, { waitUntil: 'domcontentloaded' });
    console.log(`5.${i} goto ok`);
  } catch (e) {
    console.log(`FAIL at page ${i}:`, e.message.slice(0, 120));
    break;
  }
}
console.log('pages:', ctx.pages().length);
const last = ctx.pages()[ctx.pages().length - 1];
try {
  const f = await railReady(last, { timeout: 20000 });
  console.log('rail ready on last page');
} catch (e) { console.log('railReady failed:', e.message.slice(0, 100)); }
await closeCtx(ctx);
console.log('REPRO6 DONE');
