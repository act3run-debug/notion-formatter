// Локальный сервер тестовых страниц
import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(__dirname, 'fixtures', 'pages');
const PORT = process.env.PORT ? +process.env.PORT : 8901;

const server = http.createServer((req, res) => {
  const name = req.url.split('?')[0].replace(/^\/+/, '') || 'index.html';
  const file = path.join(ROOT, name);
  if (!file.startsWith(ROOT) || !fs.existsSync(file)) {
    res.writeHead(404); res.end('not found'); return;
  }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(fs.readFileSync(file));
});
server.listen(PORT, '127.0.0.1', () => console.log(`server on http://127.0.0.1:${PORT}`));
export { server, PORT };
if (process.argv[1] && process.argv[1].endsWith('server.mjs')) {
  process.on('SIGTERM', () => process.exit(0));
}
