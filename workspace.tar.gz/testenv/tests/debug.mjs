import fs from 'fs';
import { CHROME, EXT_PATH, launchExt, closeCtx } from './harness.mjs';
console.log('CHROME =', JSON.stringify(CHROME), 'exists:', fs.existsSync(CHROME));
console.log('EXT_PATH =', JSON.stringify(EXT_PATH), 'exists:', fs.existsSync(EXT_PATH));
try { fs.accessSync(CHROME, fs.constants.X_OK); console.log('X_OK: yes'); } catch (e) { console.log('X_OK: NO', e.code); }
const ctx = await launchExt();
console.log('launched, ext:', ctx.sdbr.extId);
await closeCtx(ctx);
console.log('DEBUG DONE');
