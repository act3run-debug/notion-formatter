// repro8: теряется ли дерево при переключении с разной выдержкой; что в tabsDataCache
import { launchExt, setRailSettings, closeCtx, closeBlankPages, openPages, railReady, stableTree, nestTab, pageByTitle, structure, BASE } from './harness.mjs';

const sleep = ms => new Promise(r => setTimeout(r, ms));
const cache = (ctx) => ctx.sdbr.sw.evaluate(async () => {
  const all = await chrome.storage.local.get('tabsDataCache');
  return JSON.stringify(all.tabsDataCache).slice(0, 700);
});

const ctx = await launchExt();
await setRailSettings(ctx);
const p1 = await ctx.newPage();
await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
await closeBlankPages(ctx);
const [p2, p3] = await openPages(ctx, [2, 3]);
const f = await railReady(p3);
let tree = await stableTree(f, { minTabs: 3 });
const c = pageByTitle(tree, 'TestPage2'), par = pageByTitle(tree, 'TestPage1');
await nestTab(f, c.id, par.id);
await sleep(1500);
tree = await stableTree(f, { minTabs: 1 });
console.log('A) tree on p3 after DnD:', JSON.stringify(structure(tree)));
console.log('A) cache:', await cache(ctx));

console.log('... ждём 8с (flush дебаунсов) ...');
await sleep(8000);
console.log('B) cache after 8s:', await cache(ctx));

// Переключение на p1
await p1.bringToFront();
await sleep(400);
const f1 = await railReady(p1, { timeout: 25000 });
const tree1 = await stableTree(f1, { minTabs: 1 });
console.log('C) tree on p1 after switch:', JSON.stringify(structure(tree1)));
console.log('C) cache:', await cache(ctx));

// И обратно на p3
await p3.bringToFront();
await sleep(400);
const f3 = await railReady(p3, { timeout: 25000 });
const tree3 = await stableTree(f3, { minTabs: 1 });
console.log('D) tree back on p3:', JSON.stringify(structure(tree3)));

await closeCtx(ctx);
console.log('REPRO8 DONE');
