// Разведка v13: ветка через DnD в сайдбаре + поиск кнопки сворачивания
import { launchExt, pinRail, railReady, closeCtx, BASE } from './harness.mjs';

const ctx = await launchExt();
await pinRail(ctx);

const p1 = await ctx.newPage();
await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
let f = await railReady(p1);
const p2 = await ctx.newPage(); await p2.goto(`${BASE}/p2.html`, { waitUntil: 'domcontentloaded' });
const p3 = await ctx.newPage(); await p3.goto(`${BASE}/p3.html`, { waitUntil: 'domcontentloaded' });
await p3.waitForTimeout(1500);
f = await railReady(p3); // сайдбар на активной p3
await p3.waitForTimeout(2500);

const dumpTree = (fr) => fr.evaluate(() => [...document.querySelectorAll('.Tab')].map(t => ({
  id: t.id, lvl: +t.dataset.lvl, parent: t.dataset.parent, folded: t.dataset.folded,
  sel: t.dataset.selected, act: t.dataset.active,
  title: (t.querySelector('.title')?.textContent || '').trim().slice(0, 12),
})));
console.log('--- tree before DnD:', JSON.stringify(await dumpTree(f)));

// DnD: тащим TestPage1 (tab p1) на TestPage2 (tab p2) — центр = вложить
const tabs = await dumpTree(f);
const t1 = tabs.find(t => t.title === 'TestPage1'), t2 = tabs.find(t => t.title === 'TestPage2');
if (t1 && t2) {
  const src = f.locator('#' + t1.id), dst = f.locator('#' + t2.id);
  await src.dragTo(dst);
  await p3.waitForTimeout(2000);
  console.log('--- tree after DnD:', JSON.stringify(await dumpTree(f)));
  // Полный HTML родителя — ищем контролы сворачивания
  const par = (await dumpTree(f)).find(t => t.parent === 'true');
  if (par) {
    const html = await f.evaluate(id => document.getElementById(id)?.outerHTML, '#' + par.id);
    console.log('--- parent tab HTML:', html?.slice(0, 1500));
  }
} else console.log('tabs not found', JSON.stringify(tabs));

await closeCtx(ctx);
console.log('EXPLORE13 DONE');
