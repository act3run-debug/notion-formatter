// repro7: 6 вкладок с --process-per-site + проверка discard
import { launchExt, setRailSettings, closeCtx, closeBlankPages, openPages, railReady, stableTree, nestTab, pageByTitle, dumpTree, chromeTabs, discardTab } from './harness.mjs';

const ctx = await launchExt();
await setRailSettings(ctx);
let pages;
try {
  pages = await openPages(ctx, [1, 2, 3, 4, 5, 6]);
  console.log('6 pages OK');
} catch (e) {
  console.log('openPages FAIL:', e.message.slice(0, 100), '| pages:', ctx.pages().length);
}
await closeBlankPages(ctx);
const last = pages[pages.length - 1];
const f = await railReady(last);
let tree = await stableTree(f, { minTabs: 6 });
console.log('tree flat:', tree.map(t => `${t.title}@${t.lvl}`).join(' '));

// Вложим p6 в p5
const c = pageByTitle(tree, 'TestPage6'), p = pageByTitle(tree, 'TestPage5');
await nestTab(f, c.id, p.id);
await new Promise(r => setTimeout(r, 1500));
tree = await stableTree(f, { minTabs: 1 });
console.log('tree after nest:', tree.map(t => `${t.title}@${t.lvl}${t.parent ? '(P)' : ''}`).join(' '));

// Discard p6 (ребёнок, неактивная)
const kid = pageByTitle(tree, 'TestPage6');
const ok = await discardTab(ctx, +kid.id);
await new Promise(r => setTimeout(r, 1500));
const tabs = await chromeTabs(ctx);
console.log('discard returned:', ok, '| chrome discarded flags:', tabs.filter(t => t.url.includes('p6')).map(t => t.discarded));
tree = await stableTree(f, { minTabs: 1 });
console.log('tree after discard:', tree.map(t => `${t.title}@${t.lvl}${t.discarded ? '(D)' : ''}`).join(' '));

await closeCtx(ctx);
console.log('REPRO7 DONE');
