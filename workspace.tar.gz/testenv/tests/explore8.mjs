// Разведка v8: включение дерева вкладок (tabsTree) через settings
import { launchExt, pinRail, railReady, closeCtx, BASE } from './harness.mjs';

const ctx = await launchExt();
await pinRail(ctx);
const p1 = await ctx.newPage();
await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
const f = await railReady(p1);

// Пишем настройки Sidebery: дерево включено
await ctx.sdbr.sw.evaluate(() => chrome.storage.local.set({ settings: { tabsTree: true, tabsTreeLimits: true } }));
await p1.waitForTimeout(1500);

// Что Sidebery сохранила в ответ (если смержила и перезаписала — ключей будет много)
const s1 = await ctx.sdbr.sw.evaluate(async () => {
  const r = await chrome.storage.local.get('settings');
  return { keys: Object.keys(r.settings || {}), tabsTree: r.settings?.tabsTree };
});
console.log('--- settings after write:', JSON.stringify(s1).slice(0, 300));

const p1id = await ctx.sdbr.sw.evaluate(async () => {
  const t = await chrome.tabs.query({ url: 'http://127.0.0.1:8901/p1.html' });
  return t[0]?.id;
});
const kid = await ctx.sdbr.sw.evaluate(async ([pid, base]) => {
  const t = await chrome.tabs.create({ url: `${base}/p2.html`, openerTabId: pid, active: false });
  return t.id;
}, [p1id, BASE]);
await p1.waitForTimeout(2500);

const tree = await f.evaluate(() => [...document.querySelectorAll('.Tab')].map(t => ({
  id: t.id, lvl: t.dataset.lvl, parent: t.dataset.parent, title: (t.querySelector('.title')?.textContent || '').trim().slice(0, 15),
})));
console.log('--- tree:', JSON.stringify(tree));

// План Б: если lvl=0 — пробуем UI-настройку? Сначала проверим ответ 'ready' от bg (авторитетные настройки)
await closeCtx(ctx);
console.log('EXPLORE8 DONE');
