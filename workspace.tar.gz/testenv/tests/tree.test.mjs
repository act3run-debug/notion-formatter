// ============================================================================
// Баг #1: группировка вкладок на рейле должна быть предсказуемой.
// При любом переключении вкладок структура дерева (порядок, уровни,
// родительство) обязана оставаться неизменной.
//
// Механика бага: каждый таб-свитч уничтожает сайдбар (transferSidebar ->
// dropSidebar), новый экземпляр восстанавливает дерево из сохранённых props.
// Сохранение — дебаунс ~1.5-2с. Свитч внутри этого окна = плоское дерево
// («ветка переехала»). T1-T7 — стабилизация (проходят уже сейчас),
// T8-T9 — спецификация окна уязвимости (пройдут, когда баг закрыт на 100%).
// ============================================================================
import { test, before, after } from 'node:test';
import assert from 'node:assert';
import {
  launchExt, closeCtx, setRailSettings, railReady, closeBlankPages, openPages,
  switchTo, stableTree, structure, nestTab, pageByTitle, activePage, dumpTree, BASE,
} from './harness.mjs';

const sleep = ms => new Promise(r => setTimeout(r, ms));
let ctx, pages, baseStructure;
const MIN = 5;

// Дамп родительских связей из фонового кэша (правда bg)
const cacheDump = () => ctx.sdbr.sw.evaluate(async () => {
  const all = await chrome.storage.local.get('tabsDataCache');
  const c = all.tabsDataCache;
  if (!c) return 'NO-CACHE';
  return Object.values(c).flat().map(t => `${t.id}${t.parentId ? '->' + t.parentId : ''}`).join(',');
}).catch(e => 'ERR ' + e.message);

async function ensureBranches(f, tries = 3) {
  // Цель: p1 { p2 { p3 } }, p4 { p5 }
  for (const [child, parent] of [['TestPage2', 'TestPage1'], ['TestPage3', 'TestPage2'], ['TestPage5', 'TestPage4']]) {
    for (let i = 0; i < tries; i++) {
      const tree = await stableTree(f, { minTabs: 1 });
      const c = pageByTitle(tree, child), p = pageByTitle(tree, parent);
      if (!c || !p) throw new Error('вкладка не найдена в дереве: ' + child);
      if (p.parent && c.lvl === p.lvl + 1) break;
      await nestTab(f, c.id, p.id);
      await sleep(1500);
    }
  }
  return stableTree(f, { minTabs: 1 });
}

async function currentSidebar() {
  const p = await activePage(ctx);
  const f = await railReady(p, { timeout: 30000 });
  return { page: p, frame: f };
}

async function fixture() {
  ctx = await launchExt();
  // Тихий режим: создаём вкладки БЕЗ сайдбаров (иначе каждый таб на мгновение
  // поднимает экземпляр Sidebery и рендерер вылетает по памяти в 1GB)
  await setRailSettings(ctx, { pinned: false, rail_last_open: false });
  const p1 = await ctx.newPage();
  await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
  await closeBlankPages(ctx);
  pages = [p1, ...(await openPages(ctx, [2, 3, 4, 5]))];
  // Включаем закреплённый рейл — сайдбар появится только на активной вкладке
  await setRailSettings(ctx);
  const f = await railReady(pages[4]);
  await ensureBranches(f);
  await sleep(3000); // даём дебаунсам отработать — базовое дерево зафиксировано
  const { frame: f2 } = await currentSidebar();
  const tree = await stableTree(f2, { minTabs: MIN });
  baseStructure = structure(tree);
  console.log('BASELINE:', JSON.stringify(baseStructure));
  console.log('CACHE-AFTER-FIXTURE:', await cacheDump());
  assert.ok(baseStructure.some(s => s.includes(':1:') || s.includes(':2:')), 'в базовом дереве есть вложенность');
}

before(async () => {
  for (let attempt = 1; ; attempt++) {
    try { await fixture(); return; } catch (e) {
      if (attempt >= 2 || !/Target crashed|has been closed/i.test(String(e.message))) throw e;
      console.log('фикстура крашнулась (память?) — пробую ещё раз');
      try { await closeCtx(ctx); } catch {}
      await sleep(3000);
    }
  }
});

after(async () => { await closeCtx(ctx); });

function assertStructure(tree, msg) {
  assert.deepStrictEqual(structure(tree), baseStructure, msg +
    '\nожидалось: ' + JSON.stringify(baseStructure) +
    '\nполучено:  ' + JSON.stringify(structure(tree)));
}

test('T1: последовательные переключения сохраняют структуру', { timeout: 300000 }, async () => {
  let first = true;
  for (const i of [2, 4, 0, 3, 1, 0, 4, 2]) {
    const { tree, frame } = await switchTo(ctx, pages[i], { minTabs: MIN });
    if (first) { first = false; console.log('CACHE-AFTER-FIRST-SWITCH:', await cacheDump()); }
    if (JSON.stringify(structure(tree)) !== JSON.stringify(baseStructure)) {
      console.log(`CACHE-ON-FAIL(TestPage${i + 1}):`, await cacheDump());
      // плоское дерево держится навсегда или всё-таки восстановится?
      await sleep(8000);
      const again = await dumpTree(frame);
      console.log(`RECHECK-8S(TestPage${i + 1}):`, JSON.stringify(structure(again)));
    }
    assertStructure(tree, `после переключения на TestPage${i + 1}`);
  }
});

test('T2: быстрые переключения (без ожидания пересборки) сохраняют структуру', { timeout: 180000 }, async () => {
  for (const i of [1, 3, 0, 4, 2, 0, 3, 1, 4, 0]) {
    await pages[i].bringToFront();
    await sleep(150);
  }
  const { frame } = await currentSidebar();
  const tree = await stableTree(frame, { minTabs: MIN });
  assertStructure(tree, 'после серии быстрых переключений');
});

test('T3: переключения во время пересборки сайдбара (гонка) сохраняют структуру', { timeout: 180000 }, async () => {
  for (const i of [2, 4, 1, 3, 0]) {
    await pages[i].bringToFront();
    await sleep(500);
  }
  const { frame } = await currentSidebar();
  const tree = await stableTree(frame, { minTabs: MIN });
  assertStructure(tree, 'после гоночных переключений');
});

test('T4: дети никогда не меняют родителя', { timeout: 60000 }, async () => {
  const { frame } = await currentSidebar();
  const tree = await stableTree(frame, { minTabs: MIN });
  const by = {}; for (const t of tree) by[t.title] = t;
  const idx = {}; tree.forEach((t, i) => idx[t.title] = i);
  assert.ok(by.TestPage1.parent, 'TestPage1 остаётся родителем');
  assert.strictEqual(by.TestPage2.lvl, by.TestPage1.lvl + 1, 'TestPage2 — ребёнок TestPage1');
  assert.strictEqual(by.TestPage3.lvl, by.TestPage2.lvl + 1, 'TestPage3 — ребёнок TestPage2');
  assert.ok(by.TestPage4.parent, 'TestPage4 остаётся родителем');
  assert.strictEqual(by.TestPage5.lvl, by.TestPage4.lvl + 1, 'TestPage5 — ребёнок TestPage4');
  assert.ok(idx.TestPage2 > idx.TestPage1 && idx.TestPage3 > idx.TestPage2, 'ветка p1 непрерывна');
  assert.ok(idx.TestPage5 > idx.TestPage4, 'ветка p4 непрерывна');
  assert.ok(idx.TestPage4 > idx.TestPage3 || idx.TestPage1 > idx.TestPage5, 'ветки не пересекаются');
});

test('T5: свёрнутая ветка переживает переключения и разворачивается без потерь', { timeout: 240000 }, async () => {
  let { page, frame } = await currentSidebar();
  let tree = await stableTree(frame, { minTabs: 1 });
  const p1t = pageByTitle(tree, 'TestPage1');
  if (!p1t.folded) {
    await frame.locator('#tab' + p1t.id + ' .exp').click({ timeout: 8000 });
    await sleep(1000);
  }
  await sleep(2500); // дебаунс сохранения folded
  for (const i of [3, 4, 0, 2]) {
    await pages[i].bringToFront();
    await sleep(500);
  }
  ({ page, frame } = await currentSidebar());
  tree = await stableTree(frame, { minTabs: 1 });
  const p1b = pageByTitle(tree, 'TestPage1');
  assert.ok(p1b, 'TestPage1 на месте');
  assert.ok(p1b.folded, 'ветка осталась свёрнутой после переключений');
  if (p1b.folded) {
    await frame.locator('#tab' + p1b.id + ' .exp').click({ timeout: 8000 });
    await sleep(1000);
  }
  tree = await stableTree(frame, { minTabs: MIN });
  assertStructure(tree, 'после разворачивания ветки');
});

test('T6: keepSidebarAlive=false — структура всё равно стабильна', { timeout: 240000 }, async () => {
  await setRailSettings(ctx, { keepSidebarAlive: false });
  await sleep(1000);
  try {
    for (const i of [1, 4, 0, 3, 2, 0]) {
      const { tree } = await switchTo(ctx, pages[i], { minTabs: MIN });
      assertStructure(tree, `keepSidebarAlive=false, после TestPage${i + 1}`);
    }
  } finally {
    await setRailSettings(ctx, { keepSidebarAlive: true });
  }
});

test('T7: фоновая правда (chrome.tabs) — все вкладки живы', { timeout: 60000 }, async () => {
  const tabs = await ctx.sdbr.sw.evaluate(async () =>
    (await chrome.tabs.query({})).map(t => ({ url: (t.url || '').slice(-12) })));
  assert.ok(tabs.length >= MIN, 'все вкладки живы: ' + tabs.length);
});

// ================== СПЕЦИФИКАЦИЯ ОКНА УЯЗВИМОСТИ (баг ещё жив) ==================

test('T8: свитч СРАЗУ после изменения дерева (<1с) сохраняет новую структуру', { timeout: 180000 }, async () => {
  let { page, frame } = await currentSidebar();
  let tree = await stableTree(frame, { minTabs: MIN });
  // Мутация: переносим TestPage5 из-под TestPage4 в TestPage1
  let mutated = null;
  for (let i = 0; i < 3 && !mutated; i++) {
    const c = pageByTitle(tree, 'TestPage5'), np = pageByTitle(tree, 'TestPage1');
    await nestTab(frame, c.id, np.id);
    await sleep(400);
    tree = await dumpTree(frame);
    const p1t = pageByTitle(tree, 'TestPage1'), p5t = pageByTitle(tree, 'TestPage5');
    const idx = {}; tree.forEach((t, i) => idx[t.title] = i);
    if (p1t?.parent && p5t && p5t.lvl === p1t.lvl + 1 && idx.TestPage5 > idx.TestPage1) {
      mutated = structure(tree);
    } else {
      tree = await stableTree(frame, { minTabs: 1 });
    }
  }
  assert.ok(mutated, 'DnD-мутация применилась');
  // Немедленный свитч — внутри окна дебаунса
  const target = pages.find((p, i) => i !== pages.indexOf(page)) || pages[0];
  await target.bringToFront();
  await sleep(350);
  const cur = await currentSidebar();
  const after = await stableTree(cur.frame, { minTabs: MIN });
  assert.deepStrictEqual(structure(after), mutated,
    'дерево, изменённое <1с назад, обязано пережить переключение вкладки');
});

test('T9: свитч через 1с после мутации + серия быстрых свитчей сохраняет структуру', { timeout: 240000 }, async () => {
  let { frame } = await currentSidebar();
  await sleep(3000); // вернуть дерево в сохранённое состояние после T8
  let tree = await stableTree(frame, { minTabs: MIN });
  // Новая мутация: TestPage3 -> TestPage4 (смена родителя у внука)
  let mutated = null;
  for (let i = 0; i < 3 && !mutated; i++) {
    const c = pageByTitle(tree, 'TestPage3'), np = pageByTitle(tree, 'TestPage4');
    const before = structure(tree);
    await nestTab(frame, c.id, np.id);
    await sleep(400);
    tree = await dumpTree(frame);
    const s = structure(tree);
    if (JSON.stringify(s) !== JSON.stringify(before)) mutated = s;
    else tree = await stableTree(frame, { minTabs: 1 });
  }
  assert.ok(mutated, 'мутация применилась');
  await sleep(1000); // середина окна дебаунса
  for (const i of [4, 1, 3, 0]) {
    await pages[i].bringToFront();
    await sleep(250);
  }
  const cur = await currentSidebar();
  const after = await stableTree(cur.frame, { minTabs: MIN });
  assert.deepStrictEqual(structure(after), mutated,
    'быстрые переключения сразу после мутации не должны ломать дерево');
});
