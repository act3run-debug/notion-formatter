// Разведка v9b: ветки через ссылки; дерево читаем из сайдбара АКТИВНОГО таба
import { launchExt, pinRail, railReady, closeCtx, BASE } from './harness.mjs';

const dumpTree = (f) => f.evaluate(() => [...document.querySelectorAll('.Tab')].map(t => ({
  id: t.id, lvl: +t.dataset.lvl, parent: t.dataset.parent, folded: t.dataset.folded,
  title: (t.querySelector('.title')?.textContent || '').trim().slice(0, 15),
})));

async function activeFrame(ctx) {
  // активная страница = та, у которой есть rail-iframe прямо сейчас
  for (const p of ctx.pages()) {
    const f = p.frames().find(fr => fr.url().includes('/sidebar/sidebar.html'));
    if (f) return { page: p, frame: f };
  }
  // иначе ждём на активной вкладке
  const tabs = await ctx.sdbr.sw.evaluate(() => chrome.tabs.query({ active: true, lastFocusedWindow: true }));
  const page = ctx.pages().find(p => p.url() === tabs[0]?.url);
  const frame = await railReady(page || ctx.pages()[ctx.pages().length - 1]);
  return { page: page || ctx.pages()[ctx.pages().length - 1], frame };
}

const ctx = await launchExt();
await pinRail(ctx);
const p1 = await ctx.newPage();
await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
const f0 = await railReady(p1);
await p1.waitForTimeout(1500);

const [popup] = await Promise.all([ctx.waitForEvent('page'), p1.click('#lnkW')]);
await popup.waitForLoadState('domcontentloaded');
await popup.waitForTimeout(2000);
let af = await activeFrame(ctx);
console.log('--- active page after click:', af.page.url().slice(-12));
console.log('--- tree:', JSON.stringify(await dumpTree(af.frame)));

const src = af.page;
const [popup2] = await Promise.all([ctx.waitForEvent('page'), src.click('#lnkA')]);
await popup2.waitForLoadState('domcontentloaded');
await popup2.waitForTimeout(2000);
af = await activeFrame(ctx);
console.log('--- tree after 2nd:', JSON.stringify(await dumpTree(af.frame)));

await closeCtx(ctx);
console.log('EXPLORE9B DONE');
