// repro12: бисекция — добавляем activePage/tagPages (executeScript) перед свитчем
import { launchExt, setRailSettings, closeCtx, closeBlankPages, openPages, railReady, stableTree, structure, nestTab, pageByTitle, activePage, BASE } from './harness.mjs';

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function ensureBranches(f) {
  for (const [child, parent] of [['TestPage2', 'TestPage1'], ['TestPage3', 'TestPage2'], ['TestPage5', 'TestPage4']]) {
    for (let i = 0; i < 3; i++) {
      const tree = await stableTree(f, { minTabs: 1 });
      const c = pageByTitle(tree, child), p = pageByTitle(tree, parent);
      if (c && p && p.parent && c.lvl === p.lvl + 1) break;
      await nestTab(f, c.id, p.id);
      await sleep(1500);
    }
  }
  return stableTree(f, { minTabs: 1 });
}

for (const variant of ['clean', 'with-executeScript']) {
  const ctx = await launchExt();
  await setRailSettings(ctx);
  const p1 = await ctx.newPage();
  await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
  await closeBlankPages(ctx);
  const pages = [p1, ...(await openPages(ctx, [2, 3, 4, 5]))];
  const f = await railReady(pages[4]);
  let tree = await ensureBranches(f);
  await sleep(3000);
  if (variant === 'with-executeScript') {
    await activePage(ctx); // tagPages (evaluate во всех страницах) + executeScript в активной
    const fr = await railReady(pages[4]);
    tree = await stableTree(fr, { minTabs: 1 });
  }
  await pages[2].bringToFront();
  await sleep(400);
  const f3 = await railReady(pages[2], { timeout: 25000 });
  tree = await stableTree(f3, { minTabs: 1 });
  const flat = !tree.some(t => t.lvl > 0);
  console.log(`[${variant}] после свитча: ${flat ? 'FLAT ✗' : 'NESTED ✓'} ${JSON.stringify(structure(tree))}`);
  await closeCtx(ctx);
}
console.log('REPRO12 DONE');
