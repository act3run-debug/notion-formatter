// ============================================================================
// Баг #3: выгрузка/заморозка вкладок не должна ломать дерево, фокус и рейл.
//
// ВАЖНО про окружение: в этой песочнице (контейнер, 1GB RAM, --no-sandbox)
// реальный chrome.tabs.discard роняет браузер (SIGSEGV в browser-процессе,
// воспроизведено на CfT 154 и 152, в headed/headless, с любым набором флагов,
// даже с ВЫКЛЮЧЕННЫМ расширением). Поэтому здесь выгрузка моделируется
// заморозкой страницы (CDP Page.setWebLifecycleState='frozen') — тем же
// lifecycle-путём, которым идёт discard до выгрузки.
// Настоящий discard проверяется тестом U7 при RUN_DISCARD=1 — запускайте
// этот файл на обычной машине (не в контейнере), где discard не падает.
// ============================================================================
import { test, before, after } from 'node:test';
import assert from 'node:assert';
import {
  launchExt, closeCtx, setRailSettings, railReady, closeBlankPages, openPages,
  stableTree, structure, nestTab, pageByTitle, activePage, activeTab, chromeTabs,
  discardTab, dumpTree, BASE,
} from './harness.mjs';

const sleep = ms => new Promise(r => setTimeout(r, ms));
const RUN_DISCARD = process.env.RUN_DISCARD === '1';
let ctx, pages, baseStructure;
const cdpSessions = new Map();

async function currentSidebar() {
  const p = await activePage(ctx);
  const f = await railReady(p, { timeout: 30000 });
  return { page: p, frame: f };
}

async function cdp(page) {
  if (!cdpSessions.has(page)) cdpSessions.set(page, await ctx.newCDPSession(page));
  return cdpSessions.get(page);
}
async function freeze(page) {
  try { await (await cdp(page)).send('Page.setWebLifecycleState', { state: 'frozen' }); return true; }
  catch (e) { console.log('  (freeze не сработал: ' + e.message.slice(0, 60) + ')'); return false; }
}
async function unfreeze(page) {
  try { await (await cdp(page)).send('Page.setWebLifecycleState', { state: 'active' }); return true; }
  catch { return false; }
}

before(async () => {
  ctx = await launchExt({ viewport: { width: 1100, height: 750 } });
  await setRailSettings(ctx, { pinned: false, rail_last_open: false }); // тихое создание вкладок
  const p1 = await ctx.newPage();
  await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
  await closeBlankPages(ctx);
  pages = [p1, ...(await openPages(ctx, [2, 3]))];
  await setRailSettings(ctx);
  await sleep(2500); // дать сайдбару полностью восстановиться перед DnD
  let built = false;
  for (let i = 0; i < 8 && !built; i++) {
    const cur = await currentSidebar();
    let tree = await stableTree(cur.frame, { minTabs: 3 }).catch(() => []);
    const c = pageByTitle(tree, 'TestPage2'), p = pageByTitle(tree, 'TestPage1');
    if (c && p && p.parent && c.lvl === p.lvl + 1) { built = true; break; }
    if (!c || !p) { await sleep(1200); continue; }
    await nestTab(cur.frame, c.id, p.id).catch(() => {});
    await sleep(1500);
  }
  assert.ok(built, 'фикстура: ветка p1{p2} построена');
  await sleep(3000);
  const { frame: f2 } = await currentSidebar();
  const tree = await stableTree(f2, { minTabs: 3 });
  baseStructure = structure(tree);
  console.log('UNLOAD-BASELINE:', JSON.stringify(baseStructure));
  assert.ok(baseStructure.some(s => s.includes(':1:')), 'ветка построена');
});

after(async () => { await closeCtx(ctx); });

test('U1: заморозка неактивного ребёнка — структура и фокус целы', { timeout: 120000 }, async () => {
  await pages[2].bringToFront(); // активна p3
  await sleep(300);
  const { frame } = await currentSidebar();
  const before = (await activeTab(ctx)).url;
  const ok = await freeze(pages[1]); // p2 — ребёнок, неактивна
  assert.ok(ok, 'заморозка применилась');
  await sleep(1200);
  const tree = await stableTree(frame, { minTabs: 3 });
  assert.deepStrictEqual(structure(tree), baseStructure, 'структура не изменилась после заморозки');
  assert.strictEqual((await activeTab(ctx)).url, before, 'фокус не ушёл');
});

test('U2: переключение при замороженном ребёнке — структура цела', { timeout: 120000 }, async () => {
  await pages[0].bringToFront();
  await sleep(300);
  const { frame } = await currentSidebar();
  const tree = await stableTree(frame, { minTabs: 3 });
  assert.deepStrictEqual(structure(tree), baseStructure, 'после свитча на p1 структура прежняя');
  const p2 = pageByTitle(tree, 'TestPage2');
  assert.ok(p2 && p2.lvl === 1, 'замороженная вкладка остаётся ребёнком в дереве');
});

test('U3: заморозка родителя ветки — дети не теряются', { timeout: 120000 }, async () => {
  await pages[2].bringToFront(); // активна p3
  await sleep(300);
  const { frame } = await currentSidebar();
  const ok = await freeze(pages[0]); // p1 — родитель
  assert.ok(ok, 'родитель заморожен');
  await sleep(1200);
  const tree = await stableTree(frame, { minTabs: 3 });
  assert.deepStrictEqual(structure(tree), baseStructure, 'структура после заморозки родителя');
  assert.ok(pageByTitle(tree, 'TestPage1')?.parent, 'родитель остался родителем');
});

test('U4: разморозка + активация — дерево восстанавливается, фокус предсказуем', { timeout: 120000 }, async () => {
  await unfreeze(pages[0]);
  await pages[0].bringToFront();
  await sleep(500);
  const p = await activePage(ctx);
  const f = await railReady(p, { timeout: 30000 });
  const tree = await stableTree(f, { minTabs: 3 });
  assert.deepStrictEqual(structure(tree), baseStructure, 'после разморозки структура прежняя');
  assert.ok((await activeTab(ctx)).url.includes('p1.html'), 'активна именно p1');
});

test('U5: массовая заморозка + быстрые переключения — структура цела', { timeout: 180000 }, async () => {
  await pages[0].bringToFront();
  await sleep(300);
  await freeze(pages[1]);
  await freeze(pages[2]);
  await sleep(600);
  for (const i of [2, 1, 2, 0, 1]) { // активация размораживает страницы
    await pages[i].bringToFront();
    await sleep(800);
  }
  await unfreeze(pages[0]).catch(() => {});
  const p = await activePage(ctx);
  const f = await railReady(p, { timeout: 30000 });
  const tree = await stableTree(f, { minTabs: 3 });
  assert.deepStrictEqual(structure(tree), baseStructure, 'после массовой заморозки и скачков структура прежняя');
});

test('U6: заморозка сразу за DnD-мутацией + мгновенный свитч (гонка)', { timeout: 180000 }, async () => {
  await sleep(2500);
  let { frame } = await currentSidebar();
  let tree = await stableTree(frame, { minTabs: 1, minAge: 1500 });
  let mutated = null;
  for (let i = 0; i < 3 && !mutated; i++) {
    const c = pageByTitle(tree, 'TestPage3'), p = pageByTitle(tree, 'TestPage1');
    const before = structure(tree);
    await nestTab(frame, c.id, p.id);
    await sleep(400);
    const now = structure(await dumpTree(frame));
    if (JSON.stringify(now) !== JSON.stringify(before)) mutated = now;
    else tree = await stableTree(frame, { minTabs: 1, minAge: 800 });
  }
  assert.ok(mutated, 'мутация применилась');
  await freeze(pages.find(pg => pg.url().includes('p2.html'))); // заморозка внутри окна дебаунса
  const target = pages.find(pg => pg.url().includes('p2.html'));
  await target.bringToFront(); // её активация = разморозка + reload-free resume
  await sleep(400);
  const p = await activePage(ctx);
  const f = await railReady(p, { timeout: 30000 });
  tree = await stableTree(f, { minTabs: 3 });
  const p3t = pageByTitle(tree, 'TestPage3'), p1t = pageByTitle(tree, 'TestPage1');
  assert.ok(p1t?.parent && p3t?.lvl === p1t.lvl + 1,
    'мутация+заморозка+свитч: p3 осталась ребёнком p1. Дерево: ' + JSON.stringify(structure(tree)));
});

// U7 — только на нормальной машине (не контейнер): реальный chrome.tabs.discard
test('U7: реальный discard (RUN_DISCARD=1) — структура цела', { timeout: 180000, skip: !RUN_DISCARD }, async () => {
  await pages[2].bringToFront();
  await sleep(300);
  const { frame } = await currentSidebar();
  const tabs = await chromeTabs(ctx);
  const p2id = tabs.find(t => t.url.includes('p2.html'))?.id;
  assert.ok(await discardTab(ctx, p2id), 'discard сработал');
  await sleep(1500);
  const tabs2 = await chromeTabs(ctx);
  assert.ok(tabs2.find(t => t.url.includes('p2.html'))?.discarded, 'p2 discarded');
  const tree = await stableTree(frame, { minTabs: 3 });
  assert.deepStrictEqual(structure(tree), baseStructure, 'структура после discard');
  assert.ok(pageByTitle(tree, 'TestPage2')?.discarded, 'статус discarded виден в сайдбаре');
});
