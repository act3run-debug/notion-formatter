// repro16: discard под puppeteer-core (без Playwright)
import puppeteer from 'puppeteer-core';

const CHROME = process.env.CHROME_BIN || '/tmp/sdbr-chrome/chrome-linux64/chrome';
const EXT = '/home/user/extension-src';
const browser = await puppeteer.launch({
  executablePath: CHROME,
  headless: false,
  args: ['--no-sandbox', '--disable-gpu', '--no-first-run', '--user-data-dir=/tmp/pptr-profile',
    `--disable-extensions-except=${EXT}`, `--load-extension=${EXT}`],
});
browser.on('disconnected', () => console.log('!! BROWSER DISCONNECTED'));
const page = await browser.newPage();
await page.goto('http://127.0.0.1:8901/p1.html');
const page2 = await browser.newPage();
await page2.goto('http://127.0.0.1:8901/p2.html');
const page3 = await browser.newPage();
await page3.goto('http://127.0.0.1:8901/p3.html');
await new Promise(r => setTimeout(r, 2500));

// SW расширения
const swTarget = await browser.waitForTarget(t => t.type() === 'service_worker' && t.url().includes('background'), { timeout: 15000 });
const sw = await swTarget.worker();
const r = await sw.evaluate(async () => {
  const tabs = await chrome.tabs.query({ url: 'http://127.0.0.1:8901/p2.html' });
  if (!tabs[0]) return 'no-tab';
  const t = await chrome.tabs.discard(tabs[0].id);
  return !!t;
});
console.log('discard result:', r);
await new Promise(r2 => setTimeout(r2, 2000));
try {
  const n = await sw.evaluate(async () => (await chrome.tabs.query({})).length);
  console.log('ALIVE, tabs:', n);
  const d = await sw.evaluate(async () => (await chrome.tabs.query({})).map(t => `${(t.url||'').slice(-9)}:${!!t.discarded}`).join(' '));
  console.log('discarded flags:', d);
} catch (e) { console.log('DEAD:', e.message.slice(0, 60)); }
await browser.close().catch(() => {});
console.log('REPRO16 DONE');
