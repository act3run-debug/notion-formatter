// Разведка v7b: настройки Sidebery после инициализации
import { launchExt, pinRail, railReady, closeCtx, BASE } from './harness.mjs';

const ctx = await launchExt();
await pinRail(ctx);
const p1 = await ctx.newPage();
await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
await railReady(p1);
await p1.waitForTimeout(2000);

const info = await ctx.sdbr.sw.evaluate(async () => {
  const all = await chrome.storage.local.get(null);
  const out = { keys: Object.keys(all) };
  const sb = all.sidebar;
  if (sb && typeof sb === 'object') {
    out.sidebarKeys = Object.keys(sb).slice(0, 30);
    const s = sb.settings || sb;
    const cand = Object.entries(s).filter(([k]) => /tree|group|fold|opener|nest|discard|unload/i.test(k));
    out.treeSettings = Object.fromEntries(cand.slice(0, 25));
  }
  const c = all.tabsDataCache?.['0'];
  if (c) {
    out.cacheWinKeys = Object.keys(c);
    out.cacheSample = JSON.stringify(c).slice(0, 500);
  }
  return out;
});
console.log(JSON.stringify(info, null, 1).slice(0, 2200));
await closeCtx(ctx);
console.log('EXPLORE7B DONE');
