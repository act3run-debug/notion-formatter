import os
d = '/home/user/testenv/tests/fixtures/pages'
os.makedirs(d, exist_ok=True)
colors = ['#e74c3c','#3498db','#2ecc71','#f39c12','#9b59b6','#1abc9c','#e67e22','#34495e','#fd79a8','#00b894']
for i in range(1, 11):
    c = colors[i-1]
    open(os.path.join(d, f'p{i}.html'), 'w').write(
f'''<!doctype html><html><head><meta charset="utf-8"><title>TestPage{i}</title></head>
<body style="background:{c};color:#fff;font-family:sans-serif">
<h1>Test Page {i}</h1><p>Stable content for tab {i}.</p>
<button id="btn{i}" onclick="document.title='TestPage{i}-clicked'">click me</button>
</body></html>''')
open(os.path.join(d, 'index.html'), 'w').write('<!doctype html><title>Index</title><h1>Index</h1>')
print('pages:', len(os.listdir(d)))
