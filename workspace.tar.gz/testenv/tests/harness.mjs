// ============================================================================
// Самодостаточный харнесс для автотестов sidechery-rail-extension.
// Всё необходимое создаёт/чинит сам в рантайме (песочница может терять файлы
// между вызовами; снапшот воркспейса ограничен ~128MB — держим всё лёгким).
//
// Расположения:
//   Chrome:  /tmp/sdbr-chrome/chrome-linux64/chrome  (качается за ~11с если нет)
//   Страницы: /tmp/sdbr-pages/  (генерируются)
//   Сервер:  http://127.0.0.1:8901
//   Xvfb:    :98
//   Расширение: /home/user/extension-src (фолбэк: /tmp/sdbr-ext из repo/zip)
// ============================================================================
import { chromium } from 'playwright-core';
import { spawnSync, spawn } from 'child_process';
import fs from 'fs';
import os from 'os';
import net from 'net';
import path from 'path';

export const CHROME_URL = 'https://storage.googleapis.com/chrome-for-testing-public/154.0.8037.92/linux64/chrome-linux64.zip';
export const CHROME = process.env.CHROME_BIN || '/tmp/sdbr-chrome/chrome-linux64/chrome';
export const EXT_PRIMARY = '/home/user/extension-src';
export const EXT_FALLBACK = '/tmp/sdbr-ext';
export const REPO_ZIP = '/home/user/repo/sidechery-rail-extension.zip';
export const PAGES_DIR = '/tmp/sdbr-pages';
export const BASE = 'http://127.0.0.1:8901';
export const DISPLAY = ':98';

const sh = (cmd, opts = {}) => spawnSync('bash', ['-c', cmd], { encoding: 'utf8', timeout: 600000, ...opts });

export function extPath() {
  if (fs.existsSync(path.join(EXT_PRIMARY, 'manifest.json'))) return EXT_PRIMARY;
  if (!fs.existsSync(path.join(EXT_FALLBACK, 'manifest.json'))) {
    if (fs.existsSync(REPO_ZIP)) {
      fs.mkdirSync(EXT_FALLBACK, { recursive: true });
      sh(`python3 -m zipfile -e ${REPO_ZIP} ${EXT_FALLBACK}/`);
    } else {
      sh(`git clone --depth 1 https://github.com/act3run-debug/notion-formatter /tmp/sdbr-repo && python3 -m zipfile -e /tmp/sdbr-repo/sidechery-rail-extension.zip ${EXT_FALLBACK}/`);
    }
  }
  return EXT_FALLBACK;
}

function ensureAptDeps() {
  // Быстрая проверка: нужны ли системные либы (по ключевым файлам)
  const probe = sh(`ldd ${CHROME} 2>/dev/null | grep -c "not found" || echo 99`).stdout.trim();
  const noXvfb = sh(`command -v Xvfb`).status !== 0;
  if (probe === '0' && !noXvfb) return;
  console.log('[ensure] apt-get install deps...');
  sh(`apt-get update -qq && DEBIAN_FRONTEND=noninteractive apt-get install -y -qq unzip xvfb libnss3 libnspr4 libatk1.0-0 libatk-bridge2.0-0 libcups2 libdrm2 libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 libxrandr2 libgbm1 libpango-1.0-0 libcairo2 libasound2 libatspi2.0-0 libx11-6 libxcb1 libxext6 fonts-liberation dbus dbus-user-session >/dev/null 2>&1`);
}

function ensureChrome() {
  const ok = fs.existsSync(CHROME) && sh(`"${CHROME}" --version 2>/dev/null`).status === 0;
  if (ok) return;
  if (!fs.existsSync(CHROME)) {
    console.log('[ensure] downloading chrome (~11s)...');
    fs.mkdirSync('/tmp/sdbr-chrome', { recursive: true });
    const py = `
import urllib.request, zipfile, os
zp='/tmp/sdbr-chrome.zip'
urllib.request.urlretrieve('${CHROME_URL}', zp)
with zipfile.ZipFile(zp) as z: z.extractall('/tmp/sdbr-chrome')
os.remove(zp)
for b in ('chrome','chrome_crashpad_handler'):
    p='/tmp/sdbr-chrome/chrome-linux64/'+b
    if os.path.exists(p): os.chmod(p, 0o755)
`;
    fs.writeFileSync('/tmp/sdbr-getchrome.py', py);
    const r = sh(`python3 /tmp/sdbr-getchrome.py`);
    if (r.status !== 0) throw new Error('chrome download failed: ' + r.stderr);
  }
  ensureAptDeps();
  if (sh(`"${CHROME}" --version 2>/dev/null`).status !== 0) throw new Error('chrome still not runnable');
}

function ensureNodeModules() {
  if (fs.existsSync('/home/user/testenv/node_modules/playwright-core')) return;
  console.log('[ensure] npm ci...');
  const lock = fs.existsSync('/home/user/testenv/package-lock.json');
  sh(`cd /home/user/testenv && ${lock ? 'npm ci' : 'npm i playwright-core puppeteer-core @playwright/test'} --no-audit --no-fund >/dev/null 2>&1`);
}

function ensureXvfb() {
  const alive = sh(`pgrep -x Xvfb >/dev/null && [ -S /tmp/.X11-unix/X98 ]`).status === 0;
  if (alive) return;
  sh(`rm -f /tmp/.X98-lock /tmp/.X11-unix/X98`);
  const p = spawn('Xvfb', [DISPLAY, '-screen', '0', '1920x1080x24'], { detached: true, stdio: 'ignore' });
  p.unref();
  spawnSync('sleep', ['2']);
}

function ensurePages() {
  fs.mkdirSync(PAGES_DIR, { recursive: true });
  const colors = ['#e74c3c','#3498db','#2ecc71','#f39c12','#9b59b6','#1abc9c','#e67e22','#34495e','#fd79a8','#00b894'];
  for (let i = 1; i <= 10; i++) {
    const f = path.join(PAGES_DIR, `p${i}.html`);
    fs.writeFileSync(f, `<!doctype html><html><head><meta charset="utf-8"><title>TestPage${i}</title></head>
<body style="background:${colors[i-1]};color:#fff;font-family:sans-serif">
<h1>Test Page ${i}</h1><p>Stable content for tab ${i}.</p>
<button id="btn${i}" onclick="document.title='TestPage${i}-clicked'">click me</button>
<a id="lnkA" href="p${(i % 10) + 1}.html" target="_blank" style="color:#fff;display:block;margin:8px">open p${(i % 10) + 1}</a>
<a id="lnkB" href="p${((i + 1) % 10) + 1}.html" target="_blank" style="color:#fff;display:block;margin:8px">open p${((i + 1) % 10) + 1}</a>
<a id="lnkW" href="p${i}.html" target="_blank" style="color:#fff;display:block;margin:8px">open self-child</a>
</body></html>`);
  }
  fs.writeFileSync(path.join(PAGES_DIR, 'index.html'), '<!doctype html><title>Index</title><h1>Index</h1>');
}

const SERVER_SRC = `
import http from 'http'; import fs from 'fs'; import path from 'path';
const ROOT = '${PAGES_DIR}';
http.createServer((req,res)=>{
  const name = req.url.split('?')[0].replace(/^\\/+/, '') || 'index.html';
  const file = path.join(ROOT, name);
  if (!file.startsWith(ROOT) || !fs.existsSync(file)) { res.writeHead(404); res.end('nf'); return; }
  res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'}); res.end(fs.readFileSync(file));
}).listen(8901,'127.0.0.1');
`;

function portOpen(port) {
  return new Promise(res => {
    const s = net.connect(port, '127.0.0.1');
    s.on('connect', () => { s.destroy(); res(true); });
    s.on('error', () => res(false));
    setTimeout(() => { s.destroy(); res(false); }, 1500);
  });
}

async function serverHealthy() {
  try {
    const r = await fetch(BASE + '/p1.html');
    return r.ok && (await r.text()).includes('Test Page 1');
  } catch { return false; }
}

async function ensureServer() {
  if (await serverHealthy()) return;
  // Убить любой процесс, держащий порт ( bracket-trick чтобы pkill не убил сам себя )
  sh(`pkill -9 -f '[s]dbr-server' ; pkill -9 -f '[s]erver\\.mjs'`);
  await new Promise(r => setTimeout(r, 400));
  fs.writeFileSync('/tmp/sdbr-server.mjs', SERVER_SRC);
  const p = spawn('node', ['/tmp/sdbr-server.mjs'], { detached: true, stdio: 'ignore' });
  p.unref();
  for (let i = 0; i < 15; i++) { if (await serverHealthy()) return; await new Promise(r => setTimeout(r, 300)); }
  throw new Error('server failed to start');
}

export async function ensureEnv() {
  // Зомби-хромы от упавших прогонов съедают 1GB RAM — прибираем
  sh(`killall -9 chrome chrome_crashpad_handler 2>/dev/null || true`);
  ensureNodeModules();
  ensureChrome();
  ensureXvfb();
  ensurePages();
  await ensureServer();
  extPath(); // гарантируем наличие расширения
  console.log('[ensure] ENV READY');
}

export async function launchExt(opts = {}) {
  await ensureEnv();
  process.env.DISPLAY = process.env.DISPLAY || DISPLAY;
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'sdbr-'));
  const ext = opts.extPath || extPath();
  const ctx = await chromium.launchPersistentContext(profile, {
    executablePath: CHROME,
    headless: opts.headless ?? false,
    args: opts.minimalFlags
      ? ['--no-sandbox', `--disable-extensions-except=${ext}`, `--load-extension=${ext}`, ...(opts.args || [])]
      : [
          '--no-sandbox', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
          '--disable-dev-shm-usage',
          ...(opts.processPerSite === false ? [] : ['--process-per-site']),
          `--disable-extensions-except=${ext}`,
          `--load-extension=${ext}`,
          ...(opts.args || []),
        ],
    viewport: opts.viewport || { width: 1280, height: 800 },
  });
  let sw = ctx.serviceWorkers()[0];
  if (!sw) sw = await ctx.waitForEvent('serviceworker', { timeout: 20000 });
  const extId = sw.url().split('/')[2];
  ctx.sdbr = { extId, sw, profile };
  return ctx;
}

// Кадр рейла (iframe с sidebar.html) внутри страницы
export async function railFrame(page, timeout = 20000) {
  const t0 = Date.now();
  for (;;) {
    const f = page.frames().find(fr => fr.url().includes('/sidebar/sidebar.html'));
    if (f) return f;
    if (Date.now() - t0 > timeout) throw new Error('rail iframe not found on ' + page.url());
    await page.waitForTimeout(200);
  }
}

// Надёжный драйвер: ждём iframe сайдбара, подталкивая рейл через SW и reload
export async function railReady(page, { timeout = 30000 } = {}) {
  const ctx = page.context();
  const sw = ctx.sdbr?.sw;
  const t0 = Date.now();
  let nudged = 0, reloaded = 0;
  for (;;) {
    const f = page.frames().find(fr => fr.url().includes('/sidebar/sidebar.html'));
    if (f) { try { await f.waitForLoadState('domcontentloaded'); } catch {} return f; }
    const el = Date.now() - t0;
    if (sw && el > 2000 * (nudged + 1) && nudged < 4) {
      nudged++;
      await sw.evaluate(async (url) => {
        try {
          const tabs = await chrome.tabs.query({ url });
          for (const t of tabs) chrome.tabs.sendMessage(t.id, { __sdbrRail: 1, action: 'open' }).catch(() => {});
        } catch {}
      }, page.url()).catch(() => {});
    }
    if (el > 12000 && reloaded === 0) {
      reloaded = 1;
      await page.reload({ waitUntil: 'domcontentloaded' }).catch(() => {});
    }
    if (el > timeout) throw new Error('rail not ready on ' + page.url());
    await page.waitForTimeout(250);
  }
}

export function railInfo(page) {
  return page.evaluate(() => {
    const r = window.__sdbrRail;
    const panel = document.querySelector('[class*=sdbr], [id*=sdbr]');
    return {
      hasGlobal: !!r,
      globalKeys: r ? Object.keys(r).slice(0, 20) : [],
      panelFound: panel ? (panel.className || panel.id) : null,
      iframes: [...document.querySelectorAll('iframe')].map(f => f.src).slice(0, 5),
    };
  });
}

// Закрепить рейл (pinned, без auto-hide) — сайдбар-iframe будет создан сразу
export async function pinRail(ctx) {
  await ctx.sdbr.sw.evaluate(() => chrome.storage.local.set({
    rail_settings: { schema: 6, enabled: true, pinned: true, autoHide: false, keepSidebarAlive: true, preventTabActivation: true, width: 320, edge: 'left', shiftPage: true },
    rail_last_open: true,
  }));
}

// Компактный контур DOM (проникает в open shadow roots)
export function outline(target, { root = 'body', depth = 4, max = 120 } = {}) {
  return target.evaluate(({ root, depth, max }) => {
    const out = [];
    const walk = (el, d) => {
      if (d > depth || out.length >= max) return;
      const kids = el.shadowRoot ? [...el.shadowRoot.children] : [...el.children];
      if (el.shadowRoot && out.length < max) out.push('  '.repeat(d) + '#shadow(' + el.tagName.toLowerCase() + ')');
      for (const c of kids) {
        if (out.length >= max) return;
        const cls = (typeof c.className === 'string' && c.className)
          ? '.' + c.className.trim().split(/\s+/).slice(0, 3).join('.') : '';
        const id = c.id ? '#' + c.id : '';
        const txt = c.children.length === 0 ? (c.textContent || '').trim().slice(0, 25) : '';
        out.push('  '.repeat(d + (el.shadowRoot ? 1 : 0)) + c.tagName.toLowerCase() + id + cls + (txt ? ` "${txt}"` : ''));
        walk(c, d + 1);
      }
    };
    const el = document.querySelector(root);
    if (el) walk(el, 0);
    return out.join('\n');
  }, { root, depth, max });
}

export async function closeCtx(ctx) {
  try { await ctx.close(); } catch {}
  try { fs.rmSync(ctx.sdbr?.profile, { recursive: true, force: true }); } catch {}
  // Graceful close достаточно; killall -9 плодит зомби (pid1 в контейнере не reap'ит)
}

/* ============================ высокоуровневые хелперы ============================ */

// Записать rail_settings (pin + патч) и разослать их всем http-вкладкам
// (так же, как это делает bg setSettings -> broadcast) — rail.js на action
// 'settings' сразу применяет их и открывает/закрывает панель при pinned.
export async function setRailSettings(ctx, patch = {}) {
  const settings = Object.assign({
    schema: 6, enabled: true, pinned: true, autoHide: false,
    keepSidebarAlive: true, preventTabActivation: true,
    width: 320, edge: 'left', shiftPage: true,
  }, patch);
  await ctx.sdbr.sw.evaluate(async (s) => {
    await chrome.storage.local.set({ rail_settings: s, rail_last_open: !!s.pinned });
    const tabs = await chrome.tabs.query({});
    for (const t of tabs) {
      if (/^http/.test(t.url || '')) {
        chrome.tabs.sendMessage(t.id, { __sdbrRail: 1, action: 'settings', settings: s }).catch(() => {});
      }
    }
  }, settings);
}

// DOM-теги страниц (видны из isolated world расширения) — для поиска активной
export async function tagPages(ctx) {
  const pages = ctx.pages();
  for (let i = 0; i < pages.length; i++) {
    pages[i].__tag = i;
    await pages[i].evaluate(n => { document.documentElement.dataset.pwTag = String(n); }, i).catch(() => {});
  }
}

export async function activeTab(ctx) {
  return ctx.sdbr.sw.evaluate(async () => {
    const [t] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    return t ? { id: t.id, url: t.url, title: t.title } : null;
  });
}

export async function activePage(ctx) {
  await tagPages(ctx);
  const tag = await ctx.sdbr.sw.evaluate(async () => {
    const [t] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!t) return null;
    try {
      const [r] = await chrome.scripting.executeScript({
        target: { tabId: t.id },
        func: () => document.documentElement.dataset.pwTag ?? null,
      });
      return r.result;
    } catch { return null; }
  });
  return ctx.pages().find(p => p.__tag === +tag) ?? null;
}

export async function chromeTabs(ctx) {
  return ctx.sdbr.sw.evaluate(async () => (await chrome.tabs.query({})).map(t => ({
    id: t.id, url: t.url || '', title: t.title || '', active: t.active,
    discarded: !!t.discarded, windowId: t.windowId,
  })));
}

export async function discardTab(ctx, id) {
  return ctx.sdbr.sw.evaluate(i => chrome.tabs.discard(i).then(t => !!t, () => false), id);
}

// Снимок дерева сайдбара: порядок, уровни, родительство, свернутость
export const dumpTree = (frame) => frame.evaluate(() =>
  [...document.querySelectorAll('.Tab')].map(t => ({
    id: t.id.replace(/^tab/, ''),
    lvl: +t.dataset.lvl,
    parent: t.dataset.parent === 'true',
    folded: t.dataset.folded === 'true',
    discarded: t.dataset.discarded === 'true',
    paused: t.dataset.paused === 'true',
    active: t.dataset.active === 'true',
    title: (t.querySelector('.title')?.textContent || '').trim().slice(0, 20),
  })));

// Структура без изменчивых полей — для сравнения «до/после»
export const structure = (tree) => tree.map(t => `${t.id}:${t.lvl}:${t.parent ? 'P' : '-'}`);

// Ждём, пока дерево перестанет меняться (сайдбар пересобрался И восстановил данные).
// Консервативно: минимум minAge мс наблюдения + два равных снимка с интервалом gap.
export async function stableTree(frame, { minTabs = 1, timeout = 25000, minAge = 4000, gap = 1200 } = {}) {
  let prev = null;
  const t0 = Date.now();
  for (;;) {
    const cur = await dumpTree(frame).catch(() => null);
    const age = Date.now() - t0;
    if (cur && cur.length >= minTabs && prev && age >= minAge &&
        JSON.stringify(cur) === JSON.stringify(prev)) return cur;
    prev = cur;
    if (age > timeout) return cur || [];
    await new Promise(r => setTimeout(r, gap));
  }
}

// Переключиться на страницу и дождаться готового сайдбара с устойчивым деревом
export async function switchTo(ctx, page, { minTabs = 1, settle = 300 } = {}) {
  await page.bringToFront();
  await page.waitForTimeout(settle);
  const frame = await railReady(page, { timeout: 30000 });
  const tree = await stableTree(frame, { minTabs });
  return { page, frame, tree };
}

// Вложить childId в parentId через DnD (drop в центр = стать ребёнком)
export async function nestTab(frame, childId, parentId, tries = 4) {
  let lastErr;
  for (let i = 0; i < tries; i++) {
    try {
      await frame.locator('#tab' + childId).dragTo(frame.locator('#tab' + parentId), { timeout: 8000, force: true });
      return;
    } catch (e) {
      lastErr = e;
      await new Promise(r => setTimeout(r, 1500)); // сайдбар утрясётся — повторим
    }
  }
  throw new Error('nestTab failed: ' + String(lastErr).slice(0, 100));
}

// Клик по кнопке сворачивания ветки (.exp) на вкладке
export async function clickExp(frame, tabId) {
  await frame.locator('#tab' + tabId + ' .exp').click({ timeout: 5000 });
}

// Закрыть стартовые about:blank страницы
export async function closeBlankPages(ctx) {
  for (const p of ctx.pages()) {
    if (p.url() === 'about:blank') await p.close().catch(() => {});
  }
}

// Открыть набор тестовых страниц, вернуть массив Page
export async function openPages(ctx, nums) {
  const out = [];
  for (const n of nums) {
    const p = await ctx.newPage();
    await p.goto(`${BASE}/p${n}.html`, { waitUntil: 'domcontentloaded' });
    out.push(p);
  }
  return out;
}

// Назвать страницы для удобства (title каждой = TestPageN)
export function pageByTitle(tree, title) {
  return tree.find(t => t.title === title);
}
