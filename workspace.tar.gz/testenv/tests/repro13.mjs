// repro13: диагностика падения браузера в unload-сценарии
import { launchExt, setRailSettings, closeCtx, closeBlankPages, openPages, railReady, stableTree, structure, nestTab, pageByTitle, activePage, activeTab, chromeTabs, discardTab, BASE } from './harness.mjs';

const sleep = ms => new Promise(r => setTimeout(r, ms));
const ctx = await launchExt();
ctx.on('close', () => console.log('!! CONTEXT CLOSED'));
const p1 = await ctx.newPage();
await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
await closeBlankPages(ctx);
const pages = [p1, ...(await openPages(ctx, [2, 3]))];
pages.forEach((p, i) => p.on('crash', () => console.log(`!! PAGE ${i} CRASHED`)));
const f = await railReady(pages[2]);
for (let i = 0; i < 3; i++) {
  const tree = await stableTree(f, { minTabs: 1, minAge: 1500 });
  const c = pageByTitle(tree, 'TestPage2'), par = pageByTitle(tree, 'TestPage1');
  if (c && par && par.parent && c.lvl === par.lvl + 1) break;
  await nestTab(f, c.id, par.id);
  await sleep(1500);
}
await sleep(3000);
console.log('fixture done');

console.log('step1: bringToFront p3'); await pages[2].bringToFront(); await sleep(300);
console.log('step2: activePage'); const ap = await activePage(ctx); console.log('  ok:', !!ap);
console.log('step3: railReady'); const fr = await railReady(ap, { timeout: 20000 }); console.log('  ok:', !!fr);
console.log('step4: activeTab'); console.log('  ', JSON.stringify(await activeTab(ctx)));
console.log('step5: chromeTabs'); const tabs = await chromeTabs(ctx); console.log('  count:', tabs.length);
const p2id = tabs.find(t => t.url.includes('p2.html'))?.id;
console.log('step6: discard p2 id=' + p2id);
const ok = await discardTab(ctx, p2id);
console.log('  discard ok:', ok);
await sleep(1500);
console.log('step7: chromeTabs again'); const tabs2 = await chromeTabs(ctx);
console.log('  discarded flags:', tabs2.map(t => `${t.url.slice(-9)}:${t.discarded}`).join(' '));
console.log('step8: tree'); const tree = await stableTree(fr, { minTabs: 3 });
console.log('  ', JSON.stringify(structure(tree)));
await closeCtx(ctx);
console.log('REPRO13 DONE');
