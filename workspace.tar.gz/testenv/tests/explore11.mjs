// Разведка v11: состояние __sdbrRail в каждом табе через chrome.scripting (isolated world)
import { launchExt, pinRail, railReady, closeCtx, BASE } from './harness.mjs';

const ctx = await launchExt();
await pinRail(ctx);
ctx.sdbr.sw.on('console', m => { const t = m.text(); if (/rail|claim|slot/i.test(t)) console.log('[sw]', t.slice(0, 140)); });

const p1 = await ctx.newPage();
await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
await railReady(p1);
console.log('p1 rail ready, frames:', p1.frames().length);

const probe = () => ctx.sdbr.sw.evaluate(async () => {
  const tabs = await chrome.tabs.query({});
  const out = [];
  for (const t of tabs) {
    if (!/^http/.test(t.url || '')) { out.push({ id: t.id, url: (t.url||'').slice(0,20), skip: true, active: t.active }); continue; }
    try {
      const [r] = await chrome.scripting.executeScript({
        target: { tabId: t.id },
        func: () => {
          const api = window.__sdbrRail;
          return {
            hasApi: !!api,
            host: !!document.getElementById('sdbr-rail-host'),
            iframes: document.querySelectorAll('iframe').length,
            state: api ? { alive: api.alive, dead: api.isDead, hasFrame: api.hasFrame, owns: api.ownsSidebarSlot, evicted: api.evicted, pinned: api.settings.pinned, enabled: api.settings.enabled } : null,
          };
        },
      });
      out.push({ id: t.id, url: (t.url||'').slice(-14), active: t.active, ...r.result });
    } catch (e) { out.push({ id: t.id, url: (t.url||'').slice(-14), err: String(e).slice(0, 80) }); }
  }
  return out;
});

console.log('--- BEFORE click:'); console.log(JSON.stringify(await probe(), null, 0));

const [popup] = await Promise.all([ctx.waitForEvent('page'), p1.click('#lnkW')]);
await popup.waitForLoadState('domcontentloaded');
await popup.waitForTimeout(3000);
console.log('--- AFTER click (+3s):'); console.log(JSON.stringify(await probe(), null, 0));

// Попробуем вручную открыть рейл в активном табе
const manual = await ctx.sdbr.sw.evaluate(async () => {
  const [t] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const [r] = await chrome.scripting.executeScript({
    target: { tabId: t.id },
    func: () => { try { window.__sdbrRail?.open(); return 'open() called, hasFrame=' + window.__sdbrRail?.hasFrame } catch (e) { return 'ERR ' + e.message } },
  });
  return r.result;
});
console.log('--- manual open on active tab:', manual);
await popup.waitForTimeout(2500);
console.log('--- AFTER manual (+2.5s):'); console.log(JSON.stringify(await probe(), null, 0));

await closeCtx(ctx);
console.log('EXPLORE11 DONE');
