// Разведка v5: структура Tab-узлов, storage-ключи, настройки дерева
import { launchExt, pinRail, railReady, closeCtx, BASE } from './harness.mjs';

const ctx = await launchExt();
await pinRail(ctx);
const p1 = await ctx.newPage();
await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
const f = await railReady(p1);
await p1.waitForTimeout(2000);

const dom = await f.evaluate(() => {
  const tabs = [...document.querySelectorAll('.Tab')];
  return {
    tabCount: tabs.length,
    firstTabHTML: tabs[0] ? tabs[0].outerHTML.slice(0, 500) : null,
    tabClasses: tabs.map(t => t.className),
    tabAttrs: tabs[0] ? [...tabs[0].attributes].map(a => a.name) : [],
    groups: document.querySelectorAll('.Group').length,
    tabListHTMLstart: document.querySelector('.TabList')?.innerHTML.slice(0, 200),
  };
});
console.log('--- DOM:', JSON.stringify(dom, null, 1).slice(0, 1600));

const st = await ctx.sdbr.sw.evaluate(async () => {
  const all = await chrome.storage.local.get(null);
  const out = { keys: Object.keys(all) };
  if (all.settings) {
    const s = all.settings;
    out.treeKeys = Object.fromEntries(Object.entries(s).filter(([k]) =>
      /tree|group|fold|activat|unload|discard/i.test(k)).map(([k, v]) => [k, v]));
  }
  return out;
});
console.log('--- storage keys:', st.keys.join(', '));
console.log('--- tree-ish settings:', JSON.stringify(st.treeKeys, null, 1).slice(0, 900));

await closeCtx(ctx);
console.log('EXPLORE5 DONE');
