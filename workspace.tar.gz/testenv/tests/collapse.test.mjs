// ============================================================================
// Баг #2: клик по кнопке сворачивания ветки (.exp) не должен переключать фокус
// (активировать вкладку). Проверяем при разных активных вкладках, в гонке с
// пересборкой сайдбара, при быстрых кликах.
// ============================================================================
import { test, before, after } from 'node:test';
import assert from 'node:assert';
import {
  launchExt, closeCtx, setRailSettings, railReady, closeBlankPages, openPages,
  stableTree, structure, nestTab, pageByTitle, activePage, activeTab, dumpTree, BASE,
} from './harness.mjs';

const sleep = ms => new Promise(r => setTimeout(r, ms));
let ctx, pages;

async function currentSidebar() {
  const p = await activePage(ctx);
  const f = await railReady(p, { timeout: 30000 });
  return { page: p, frame: f };
}
const activeUrl = async () => (await activeTab(ctx))?.url || '';
const tabIdByUrl = async (frag) => {
  const tabs = await ctx.sdbr.sw.evaluate(async () => (await chrome.tabs.query({})).map(t => ({ id: t.id, url: t.url || '' })));
  return tabs.find(t => t.url.includes(frag))?.id;
};

before(async () => {
  ctx = await launchExt();
  await setRailSettings(ctx, { pinned: false, rail_last_open: false }); // тихое создание вкладок
  const p1 = await ctx.newPage();
  await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
  await closeBlankPages(ctx);
  pages = [p1, ...(await openPages(ctx, [2, 3]))];
  await setRailSettings(ctx);
  await sleep(2500); // дать сайдбару полностью восстановиться перед DnD
  // Ветка: p1 { p2 }; p3 плоская. Кадр каждый раз берём заново — слот сайдбара
  // может переезжать между вкладками (broadcast открывает все рейлы сразу).
  let built = false;
  for (let i = 0; i < 8 && !built; i++) {
    const cur = await currentSidebar();
    const tree = await stableTree(cur.frame, { minTabs: 3 }).catch(() => []);
    const c = pageByTitle(tree, 'TestPage2'), p = pageByTitle(tree, 'TestPage1');
    if (c && p && p.parent && c.lvl === p.lvl + 1) { built = true; break; }
    if (c && p) { await nestTab(cur.frame, c.id, p.id).catch(() => {}); await sleep(1500); }
    else await sleep(1200);
  }
  assert.ok(built, 'фикстура: ветка p1{p2} построена');
  await sleep(3000); // фиксация дебаунсов
});

after(async () => { await closeCtx(ctx); });

test('C1: клик .exp при активной ДРУГОЙ вкладке не меняет активную вкладку', { timeout: 120000 }, async () => {
  // Активная = p3
  await pages[2].bringToFront();
  await sleep(300);
  let { frame } = await currentSidebar();
  let tree = await stableTree(frame, { minTabs: 3 });
  const before = await activeUrl();
  assert.ok(before.includes('p3.html'), ' precondition: активна p3, а не ' + before);

  const p1t = pageByTitle(tree, 'TestPage1');
  await frame.locator('#tab' + p1t.id + ' .exp').click({ timeout: 8000 });
  await sleep(700);
  const after = await activeUrl();
  assert.strictEqual(after, before, 'активная вкладка НЕ должна меняться при сворачивании');
  tree = await dumpTree(frame);
  assert.ok(pageByTitle(tree, 'TestPage1')?.folded, 'ветка свернулась');
});

test('C2: повторный клик (разворот) тоже не меняет активную вкладку', { timeout: 60000 }, async () => {
  const { frame } = await currentSidebar();
  let tree = await stableTree(frame, { minTabs: 1 });
  const p1t = pageByTitle(tree, 'TestPage1');
  if (p1t.folded) {
    const before = await activeUrl();
    await frame.locator('#tab' + p1t.id + ' .exp').click({ timeout: 8000 });
    await sleep(700);
    assert.strictEqual(await activeUrl(), before, 'разворот не украл фокус');
    tree = await dumpTree(frame);
    assert.ok(!pageByTitle(tree, 'TestPage1')?.folded, 'ветка развернулась');
  }
});

test('C3: клик .exp когда родитель сам активен — фокус остаётся на нём', { timeout: 120000 }, async () => {
  await pages[0].bringToFront(); // активна p1 (родитель)
  await sleep(300);
  const { frame } = await currentSidebar();
  const tree = await stableTree(frame, { minTabs: 3 });
  const p1t = pageByTitle(tree, 'TestPage1');
  const before = await activeUrl();
  await frame.locator('#tab' + p1t.id + ' .exp').click({ timeout: 8000 });
  await sleep(500);
  await frame.locator('#tab' + p1t.id + ' .exp').click({ timeout: 8000 }).catch(() => {});
  await sleep(500);
  assert.strictEqual(await activeUrl(), before, 'активная p1 осталась активной');
});

test('C4: серия быстрых кликов по .exp не уводит фокус', { timeout: 120000 }, async () => {
  await pages[2].bringToFront(); // активна p3
  await sleep(300);
  const { frame } = await currentSidebar();
  const tree = await stableTree(frame, { minTabs: 1 });
  const p1t = pageByTitle(tree, 'TestPage1');
  const before = await activeUrl();
  const exp = frame.locator('#tab' + p1t.id + ' .exp');
  for (let i = 0; i < 6; i++) {
    await exp.click({ timeout: 4000 }).catch(() => {});
    await sleep(120);
  }
  await sleep(600);
  assert.strictEqual(await activeUrl(), before, 'быстрые клики по .exp не меняют активную вкладку');
});

test('C5: клик .exp в момент пересборки сайдбара (гонка) не уводит фокус', { timeout: 120000 }, async () => {
  // Переключаемся и кликаем сразу, как только .exp появился — без стабилизации
  await pages[1].bringToFront(); // p2 (ребёнок)
  await sleep(250);
  const p = await activePage(ctx);
  const frame = await railReady(p, { timeout: 30000 });
  const before = await activeUrl();
  // Ждём появления родителя в DOM, но НЕ ждём stableTree
  await frame.locator('.Tab[data-parent="true"] .exp').first().waitFor({ timeout: 15000 });
  await frame.locator('.Tab[data-parent="true"] .exp').first().click({ timeout: 5000 }).catch(() => {});
  await sleep(800);
  const after = await activeUrl();
  assert.strictEqual(after, before, 'клик во время пересборки не активировал другую вкладку');
});

test('C6: свернул -> переключился -> вернулся: состояние и фокус корректны', { timeout: 180000 }, async () => {
  await sleep(2500); // дать состоянию улечься после C5
  let { frame } = await currentSidebar();
  let tree = await stableTree(frame, { minTabs: 1 });
  let p1t = pageByTitle(tree, 'TestPage1');
  // Нормализуем: развернуть
  if (p1t?.folded) {
    await frame.locator('#tab' + p1t.id + ' .exp').click({ timeout: 5000 }).catch(() => {});
    await sleep(800);
    tree = await stableTree(frame, { minTabs: 1 });
    p1t = pageByTitle(tree, 'TestPage1');
  }
  const full = structure(tree);
  await sleep(2500);
  // Свернуть, уйти на p3, вернуться на p2
  await frame.locator('#tab' + p1t.id + ' .exp').click({ timeout: 5000 });
  await sleep(500);
  const before = await activeUrl();
  await pages[2].bringToFront();
  await sleep(2500); // свёрнутое состояние должно сохраниться (дебаунс)
  assert.ok((await activeUrl()).includes('p3.html'), 'свитч сработал');
  await pages[1].bringToFront();
  await sleep(300);
  ({ frame } = await currentSidebar());
  tree = await stableTree(frame, { minTabs: 1 });
  p1t = pageByTitle(tree, 'TestPage1');
  assert.ok(p1t?.folded, 'свёрнутость пережила переключения');
  // Развернуть и проверить полную структуру
  await frame.locator('#tab' + p1t.id + ' .exp').click({ timeout: 5000 });
  await sleep(1000);
  tree = await stableTree(frame, { minTabs: 3 });
  assert.deepStrictEqual(structure(tree), full, 'структура не пострадала от свернуть/уйти/вернуться');
});

test('C7: sanity — клик по заголовку вкладки активирует её (обычное поведение живо)', { timeout: 120000 }, async () => {
  await sleep(2500);
  const { frame } = await currentSidebar();
  const tree = await stableTree(frame, { minTabs: 3 });
  const target = pageByTitle(tree, 'TestPage3');
  const before = await activeUrl();
  if (!before.includes('p3.html')) {
    await frame.locator('#tab' + target.id + ' .title').click({ timeout: 5000 });
    await sleep(1200);
    assert.ok((await activeUrl()).includes('p3.html'), 'клик по вкладке переключает на неё');
  }
});
