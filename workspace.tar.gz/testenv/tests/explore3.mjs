// Разведка v3: консоль, shadow DOM рейла, hover-триггер
import { launchExt, pinRail, closeCtx, BASE } from './harness.mjs';

const ctx = await launchExt();
await pinRail(ctx);

const p1 = await ctx.newPage();
p1.on('console', m => console.log('[page]', m.type(), m.text().slice(0, 160)));
ctx.sdbr.sw.on('console', m => console.log('[sw]', m.type(), m.text().slice(0, 160)));

await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
await p1.waitForTimeout(3000);

const shadowInfo = await p1.evaluate(() => {
  const host = document.querySelector('.sdbr-rail-host');
  if (!host) return { host: false };
  const sr = host.shadowRoot;
  if (!sr) return { host: true, shadow: false, outer: host.outerHTML.slice(0, 200) };
  const kids = [...sr.children].map(c => c.tagName + '.' + (c.className || ''));
  const panel = sr.querySelector('[class*=panel]');
  return {
    host: true, shadow: true, kids,
    panelHTML: panel ? panel.outerHTML.slice(0, 400) : null,
    iframes: sr.querySelectorAll('iframe').length,
    hostStyle: host.getAttribute('style')?.slice(0, 200),
  };
});
console.log('--- shadowInfo:', JSON.stringify(shadowInfo, null, 1).slice(0, 1200));
console.log('--- frames:', p1.frames().map(f => f.url().slice(0, 60)));

// Попробуем hover по левому краю
await p1.mouse.move(2, 400);
await p1.waitForTimeout(600);
await p1.mouse.move(20, 400);
await p1.waitForTimeout(1200);
console.log('--- after hover, frames:', p1.frames().map(f => f.url().slice(0, 60)));

// Прямой вызов open() из isolated world невозможен; проверим storage как видит его content script
const st = await ctx.sdbr.sw.evaluate(() => chrome.storage.local.get(['rail_settings', 'rail_last_open']));
console.log('--- storage:', JSON.stringify(st).slice(0, 400));

await closeCtx(ctx);
console.log('EXPLORE3 DONE');
