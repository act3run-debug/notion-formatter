// Разведка v14: HTML родительской вкладки + все кликабельные контролы
import { launchExt, pinRail, railReady, closeCtx, BASE } from './harness.mjs';

const ctx = await launchExt();
await pinRail(ctx);
const p1 = await ctx.newPage(); await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
await railReady(p1);
const p2 = await ctx.newPage(); await p2.goto(`${BASE}/p2.html`, { waitUntil: 'domcontentloaded' });
const p3 = await ctx.newPage(); await p3.goto(`${BASE}/p3.html`, { waitUntil: 'domcontentloaded' });
await p3.waitForTimeout(1500);
const f = await railReady(p3);
await p3.waitForTimeout(2500);

const tabs = await f.evaluate(() => [...document.querySelectorAll('.Tab')].map(t => ({ id: t.id, title: (t.querySelector('.title')?.textContent||'').trim() })));
const t1 = tabs.find(t => t.title === 'TestPage1'), t2 = tabs.find(t => t.title === 'TestPage2');
await f.locator('#' + t1.id).dragTo(f.locator('#' + t2.id));
await p3.waitForTimeout(1500);

const par = await f.evaluate(() => {
  const el = document.querySelector('.Tab[data-parent="true"]');
  if (!el) return null;
  return { html: el.outerHTML.slice(0, 2200) };
});
console.log('--- parent HTML:\n' + (par?.html || 'NONE'));

const ctrls = await f.evaluate(() => {
  const el = document.querySelector('.Tab[data-parent="true"]');
  return [...el.querySelectorAll('button, .ctrl, [class*=ctrl], [class*=fold], [class*=branch], svg use')].map(x =>
    x.tagName + ':' + (x.className?.baseVal ?? x.className ?? '') + ':' + (x.getAttribute('xlink:href') || x.getAttribute('href') || '')).slice(0, 20);
});
console.log('--- ctrls:', JSON.stringify(ctrls));

await closeCtx(ctx);
console.log('EXPLORE14 DONE');
