// Разведка v12: идентификация активной страницы через DOM-теги + дерево после link-open
import { launchExt, pinRail, railReady, closeCtx, BASE } from './harness.mjs';

const ctx = await launchExt();
await pinRail(ctx);

// Помечаем каждую страницу в DOM (видно из isolated world)
async function tagPages() {
  const pages = ctx.pages();
  for (let i = 0; i < pages.length; i++) {
    pages[i].__tag = i;
    await pages[i].evaluate(n => { document.documentElement.dataset.pwTag = String(n); }, i).catch(() => {});
  }
}
async function activePage() {
  await tagPages();
  const tag = await ctx.sdbr.sw.evaluate(async () => {
    const [t] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!t) return null;
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId: t.id }, func: () => document.documentElement.dataset.pwTag ?? null });
      return r.result;
    } catch { return null; }
  });
  return { page: ctx.pages().find(p => p.__tag === +tag) ?? null, tag };
}
const dumpTree = (f) => f.evaluate(() => [...document.querySelectorAll('.Tab')].map(t => ({
  id: t.id, lvl: +t.dataset.lvl, parent: t.dataset.parent, folded: t.dataset.folded,
  active: t.dataset.active, title: (t.querySelector('.title')?.textContent || '').trim().slice(0, 15),
})));

const p1 = await ctx.newPage();
await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
await railReady(p1);

const [popup] = await Promise.all([ctx.waitForEvent('page'), p1.click('#lnkW')]);
await popup.waitForLoadState('domcontentloaded');
await popup.waitForTimeout(1500);

const { page: ap, tag } = await activePage();
console.log('active tag:', tag, '| page found:', !!ap, ap?.url().slice(-14));
if (ap) {
  const f = await railReady(ap, { timeout: 20000 });
  await ap.waitForTimeout(2500);
  console.log('--- tree:', JSON.stringify(await dumpTree(f), null, 1));
} else {
  console.log('popup frames:', popup.frames().map(x => x.url().slice(0, 60)));
}

await closeCtx(ctx);
console.log('EXPLORE12 DONE');
