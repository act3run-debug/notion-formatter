// Разведка v6: дерево через openerTabId + форма tabsDataCache
import { launchExt, pinRail, railReady, closeCtx, BASE } from './harness.mjs';

const ctx = await launchExt();
await pinRail(ctx);
const p1 = await ctx.newPage();
await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
const f = await railReady(p1);

// id вкладки p1
const tabOf = async (page) => page.evaluate(() => 0); // placeholder
const tabsInfo = await ctx.sdbr.sw.evaluate(async () => {
  const tabs = await chrome.tabs.query({});
  return tabs.map(t => ({ id: t.id, url: (t.url || '').slice(0, 45), opener: t.openerTabId ?? null, active: t.active }));
});
console.log('--- tabs:', JSON.stringify(tabsInfo));

const p1tab = tabsInfo.find(t => t.url.includes('p1.html'));
// Создаём детей через openerTabId
const kids = await ctx.sdbr.sw.evaluate(async ([parentId, base]) => {
  const out = [];
  for (const n of [2, 3]) {
    const t = await chrome.tabs.create({ url: `${base}/p${n}.html`, openerTabId: parentId, active: false });
    out.push(t.id);
  }
  return out;
}, [p1tab.id, BASE]);
console.log('--- created kids:', kids);
await p1.waitForTimeout(2500);

const tree = await f.evaluate(() => [...document.querySelectorAll('.Tab')].map(t => ({
  id: t.id, lvl: t.dataset.lvl, parent: t.dataset.parent, folded: t.dataset.folded,
  active: t.dataset.active, title: (t.querySelector('.title')?.textContent || '').trim().slice(0, 20),
})));
console.log('--- sidebar tree:', JSON.stringify(tree, null, 1));

const cache = await ctx.sdbr.sw.evaluate(async () => {
  const all = await chrome.storage.local.get(['tabsDataCache', 'sidebar']);
  const out = {};
  if (all.tabsDataCache) {
    out.cacheTopKeys = Object.keys(all.tabsDataCache);
    const w = Object.values(all.tabsDataCache)[0];
    out.panels = w?.panels?.map?.(p => ({ id: String(p.id).slice(0,8), tabs: (p.tabs||[]).map(t => ({ id: t.id, lvl: t.lvl, pid: t.parentId })) }));
  }
  if (all.sidebar) out.sidebarType = typeof all.sidebar;
  return out;
});
console.log('--- tabsDataCache:', JSON.stringify(cache).slice(0, 1200));

await closeCtx(ctx);
console.log('EXPLORE6 DONE');
