// Разведка v4: 3 таба, railReady, дамп DOM сайдбара (селекторы дерева)
import { launchExt, pinRail, railReady, outline, closeCtx, BASE } from './harness.mjs';

const ctx = await launchExt();
await pinRail(ctx);

const pages = [];
for (const i of [1, 2, 3]) {
  const p = await ctx.newPage();
  await p.goto(`${BASE}/p${i}.html`, { waitUntil: 'domcontentloaded' });
  pages.push(p);
}
const p3 = pages[2];
const f3 = await railReady(p3);
console.log('p3 sidebar frame OK');
await p3.waitForTimeout(2500);

// Что в DOM сайдбара: классы-кандидаты
const cls = await f3.evaluate(() => {
  const set = new Set();
  document.querySelectorAll('*').forEach(el => {
    if (typeof el.className === 'string' && el.className) el.className.split(/\s+/).forEach(c => set.add(c));
  });
  return [...set].sort().join(' ');
});
console.log('--- sidebar classes:', cls.slice(0, 1500));

console.log('--- sidebar outline:');
console.log(await outline(f3, { root: 'body', depth: 6, max: 90 }));

// Переключимся на p1 — появится ли там сайдбар и что с деревом
await pages[0].bringToFront();
const f1 = await railReady(pages[0]);
await pages[0].waitForTimeout(1500);
console.log('p1 sidebar frame OK');
const titles = await f1.evaluate(() =>
  [...document.querySelectorAll('[class*=title], [class*=Title]')].map(e => e.textContent.trim().slice(0, 30)).filter(Boolean).slice(0, 25));
console.log('--- p1 sidebar titles:', JSON.stringify(titles));

await closeCtx(ctx);
console.log('EXPLORE4 DONE');
