// repro10: глубокое дерево (3 уровня) + две ветки; sweep задержки после DnD
import { launchExt, setRailSettings, closeCtx, closeBlankPages, openPages, railReady, stableTree, nestTab, pageByTitle, structure, activePage, BASE } from './harness.mjs';

const sleep = ms => new Promise(r => setTimeout(r, ms));

const ctx = await launchExt();
await setRailSettings(ctx);
const p1 = await ctx.newPage();
await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
await closeBlankPages(ctx);
const [p2, p3, p4, p5] = await openPages(ctx, [2, 3, 4, 5]);
const pages = [p1, p2, p3, p4, p5];

let cur = p5;
let f = await railReady(cur);
await stableTree(f, { minTabs: 5 });

async function ensureBranches(fr) {
  // p1{p2{p3}}, p4{p5}
  for (const [child, parent] of [['TestPage2', 'TestPage1'], ['TestPage3', 'TestPage2'], ['TestPage5', 'TestPage4']]) {
    for (let i = 0; i < 3; i++) {
      const tree = await stableTree(fr, { minTabs: 1 });
      const c = pageByTitle(tree, child), p = pageByTitle(tree, parent);
      if (c && p && p.parent && c.lvl === p.lvl + 1) break;
      await nestTab(fr, c.id, p.id);
      await sleep(1500);
    }
  }
  return stableTree(fr, { minTabs: 1 });
}

let tree = await ensureBranches(f);
console.log('fixture:', JSON.stringify(structure(tree)));
const good = structure(tree);

let pi = 0;
for (const delay of [1000, 2000, 4000, 8000]) {
  // если дерево плоское — пересобрать и выждать delay заново
  tree = await stableTree(f, { minTabs: 1 });
  if (JSON.stringify(structure(tree)) !== JSON.stringify(good)) {
    tree = await ensureBranches(f);
    console.log(`  (пересобрано: ${JSON.stringify(structure(tree))})`);
  }
  await sleep(delay);
  pi = (pi + 2) % 5;
  await pages[pi].bringToFront();
  await sleep(400);
  const p = await activePage(ctx);
  f = await railReady(p, { timeout: 25000 });
  tree = await stableTree(f, { minTabs: 1 });
  cur = p;
  const s = structure(tree);
  const ok = JSON.stringify(s) === JSON.stringify(good);
  console.log(`delay=${delay}ms -> ${ok ? 'OK ✓' : 'ИЗМЕНЕНО ✗'} ${JSON.stringify(s)}`);
}

await closeCtx(ctx);
console.log('REPRO10 DONE');
