// Разведка v10: таймлайн host/iframe по всем страницам после target=_blank клика
import { launchExt, pinRail, railReady, closeCtx, BASE } from './harness.mjs';

const ctx = await launchExt();
await pinRail(ctx);
ctx.sdbr.sw.on('console', m => {
  const t = m.text();
  if (/rail|slot|claim|drop|sidebar/i.test(t)) console.log(`[sw ${Date.now() % 100000}]`, t.slice(0, 150));
});

const p1 = await ctx.newPage();
await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
await railReady(p1);
console.log('p1 rail ready');

const snap = async (tag) => {
  const rows = [];
  for (const p of ctx.pages()) {
    const info = await p.evaluate(() => ({
      host: !!document.querySelector('.sdbr-rail-host'),
      hint: !!document.getElementById('sdbr-rail-reload-hint'),
    })).catch(() => ({ host: 'ERR', hint: 'ERR' }));
    rows.push(`${p.url().slice(-14)} host=${info.host} hint=${info.hint} frames=${p.frames().length}`);
  }
  const active = await ctx.sdbr.sw.evaluate(async () => {
    const [t] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    return t ? `${t.id}:${(t.url || '').slice(-12)}` : '?';
  }).catch(() => 'sw-err');
  console.log(`[${tag}] active=${active} | ${rows.join(' | ')}`);
};

await snap('before');
const [popup] = await Promise.all([ctx.waitForEvent('page'), p1.click('#lnkW')]);
console.log('popup opened:', popup.url().slice(-14));
popup.on('console', m => { if (/rail/i.test(m.text())) console.log('[popup]', m.text().slice(0, 120)); });
for (let i = 0; i < 10; i++) {
  await popup.waitForTimeout(1000);
  await snap(`t+${i + 1}s`);
}
await closeCtx(ctx);
console.log('EXPLORE10 DONE');
