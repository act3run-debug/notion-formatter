// repro14: бисекция краша при chrome.tabs.discard
import { launchExt, setRailSettings, closeCtx, closeBlankPages, openPages, BASE } from './harness.mjs';

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function tryVariant(name, settingsPatch, { withSidebar = false } = {}) {
  const ctx = await launchExt({ viewport: { width: 1000, height: 700 } });
  let closed = false;
  ctx.on('close', () => { closed = true; });
  await setRailSettings(ctx, settingsPatch);
  if (settingsPatch.rail_last_open === false) {
    await ctx.sdbr.sw.evaluate(() => chrome.storage.local.set({ rail_last_open: false }));
  }
  const p1 = await ctx.newPage();
  await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
  await closeBlankPages(ctx);
  const pages = [p1, ...(await openPages(ctx, [2, 3]))];
  await sleep(withSidebar ? 3000 : 2000);
  let discardOk = null, err = null;
  try {
    discardOk = await ctx.sdbr.sw.evaluate(async () => {
      const tabs = await chrome.tabs.query({ url: 'http://127.0.0.1:8901/p2.html' });
      if (!tabs[0]) return 'no-tab';
      const t = await chrome.tabs.discard(tabs[0].id);
      return !!t;
    });
  } catch (e) { err = e.message.slice(0, 80); }
  await sleep(1500);
  let alive = null;
  try {
    alive = await ctx.sdbr.sw.evaluate(async () => (await chrome.tabs.query({})).length);
  } catch (e) { alive = 'DEAD: ' + e.message.slice(0, 60); }
  console.log(`[${name}] discard=${discardOk} err=${err} ctxClosed=${closed} tabsAfter=${alive}`);
  await closeCtx(ctx);
  await sleep(500);
}

await tryVariant('A: rail pinned (sidebar живёт)', {});
await tryVariant('B: rail выключен', { enabled: false });
await tryVariant('C: rail включён, не pinned (нет сайдбара)', { pinned: false, autoHide: true, rail_last_open: false });
console.log('REPRO14 DONE');
