// repro9: окно уязвимости — через сколько секунд после изменения дерева переключение безопасно
import { launchExt, setRailSettings, closeCtx, closeBlankPages, openPages, railReady, stableTree, nestTab, pageByTitle, structure, activePage, BASE } from './harness.mjs';

const sleep = ms => new Promise(r => setTimeout(r, ms));
const isNested = (tree) => tree.some(t => t.lvl > 0);

const ctx = await launchExt();
await setRailSettings(ctx);
const p1 = await ctx.newPage();
await p1.goto(`${BASE}/p1.html`, { waitUntil: 'domcontentloaded' });
await closeBlankPages(ctx);
const [p2, p3] = await openPages(ctx, [2, 3]);

let cur = p3;
let f = await railReady(cur);
let tree = await stableTree(f, { minTabs: 3 });

for (const delay of [1000, 2000, 3000, 5000, 8000]) {
  // гарантируем наличие ветки (пересобираем DnD если плоско)
  tree = await stableTree(f, { minTabs: 1 });
  if (!isNested(tree)) {
    const c = pageByTitle(tree, 'TestPage2'), par = pageByTitle(tree, 'TestPage1');
    await nestTab(f, c.id, par.id);
    await sleep(1500);
    tree = await stableTree(f, { minTabs: 1 });
    console.log(`  (дерево пересобрано DnD: ${isNested(tree) ? 'nested' : 'FLAT!'})`);
  }
  await sleep(delay);
  // переключаемся на другую вкладку
  const next = cur === p3 ? p1 : p3;
  await next.bringToFront();
  await sleep(400);
  const p = await activePage(ctx);
  f = await railReady(p, { timeout: 25000 });
  tree = await stableTree(f, { minTabs: 1 });
  cur = p;
  console.log(`delay=${delay}ms -> ${isNested(tree) ? 'NESTED ✓' : 'FLAT ✗ (БАГ)'} ${JSON.stringify(structure(tree))}`);
}

await closeCtx(ctx);
console.log('REPRO9 DONE');
