#!/bin/bash
# Минимальная подготовка окружения ВРУЧНУЮ (обычно не нужна: harness.mjs чинит всё сам).
# Chrome живёт в /tmp/sdbr-chrome (вне снапшота воркспейса).
set -u
killall -9 chrome chrome_crashpad_handler 2>/dev/null || true
[ -d /home/user/testenv/node_modules/playwright-core ] || (cd /home/user/testenv && npm ci --no-audit --no-fund >/dev/null 2>&1)
if ! (pgrep -x Xvfb >/dev/null && [ -S /tmp/.X11-unix/X98 ]); then
  command -v Xvfb >/dev/null || bash /home/user/env/setup-deps.sh >/dev/null 2>&1
  rm -f /tmp/.X98-lock /tmp/.X11-unix/X98
  nohup Xvfb :98 -screen 0 1920x1080x24 >/tmp/xvfb98.log 2>&1 &
  sleep 2
fi
echo "ENV READY (chrome скачает harness при первом запуске теста)"
