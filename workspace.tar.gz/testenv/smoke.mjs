import { chromium } from 'playwright-core';
import path from 'path';
const exec = path.resolve(process.cwd(), '..', 'env', 'chrome-linux64', 'chrome');
const ctx = await chromium.launchPersistentContext('/tmp/pw-profile', {
  executablePath: exec,
  headless: false,
  args: ['--no-sandbox', '--disable-gpu'],
});
const page = await ctx.newPage();
await page.goto('data:text/html,<h1>OK</h1>');
console.log('title-content:', await page.evaluate(() => document.querySelector('h1').textContent));
console.log('browser version:', ctx.browser()?.version());
await ctx.close();
console.log('SMOKE OK');
