import urllib.request, json, os, zipfile, sys
want_major = sys.argv[1] if len(sys.argv) > 1 else '152'
d = json.load(urllib.request.urlopen('https://googlechromelabs.github.io/chrome-for-testing/known-good-versions-with-downloads.json', timeout=30))
cands = [v for v in d['versions'] if v['version'].startswith(want_major + '.') and any(x['platform'] == 'linux64' for x in v['downloads'].get('chrome', []))]
v = cands[-1]
url = [x['url'] for x in v['downloads']['chrome'] if x['platform'] == 'linux64'][0]
print('version:', v['version'], url)
dest = f'/tmp/sdbr-chrome{want_major}'
if not os.path.exists(dest + '/chrome-linux64/chrome'):
    zp = dest + '.zip'
    urllib.request.urlretrieve(url, zp)
    with zipfile.ZipFile(zp) as z:
        z.extractall(dest)
    os.remove(zp)
    for b in ('chrome', 'chrome_crashpad_handler'):
        p = f'{dest}/chrome-linux64/{b}'
        if os.path.exists(p):
            os.chmod(p, 0o755)
print('OK', dest + '/chrome-linux64/chrome')
