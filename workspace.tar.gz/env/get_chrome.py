import urllib.request, os, zipfile, time
base = '/tmp/arena/tenants/15640e7b-a210-4e4e-8b22-1374d5f970ea/sessions/d53118df-ef53-4939-a9dd-53b5a534c666/workspace/env'
os.makedirs(base, exist_ok=True)
url = open('/tmp/chrome_url.txt').read().splitlines()[0]
zp = os.path.join(base, 'chrome-linux64.zip')
t = time.time()
urllib.request.urlretrieve(url, zp)
print('downloaded MB:', round(os.path.getsize(zp)/1e6, 1), 'in', round(time.time()-t, 1), 's')
with zipfile.ZipFile(zp) as z:
    z.extractall(base)
os.remove(zp)
for b in ('chrome', 'chrome_crashpad_handler'):
    p = os.path.join(base, 'chrome-linux64', b)
    if os.path.exists(p):
        os.chmod(p, 0o755)
print('extracted to', os.path.join(base, 'chrome-linux64'))
