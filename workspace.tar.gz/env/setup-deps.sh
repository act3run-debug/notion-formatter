#!/bin/bash
# Переустановка системных зависимостей (apt-пакеты НЕ сохраняются между сессиями)
set -e
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  unzip xvfb libnss3 libnspr4 libatk1.0-0 libatk-bridge2.0-0 libcups2 \
  libdrm2 libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 libxrandr2 \
  libgbm1 libpango-1.0-0 libcairo2 libasound2 libatspi2.0-0 libx11-6 \
  libxcb1 libxext6 fonts-liberation fonts-noto-color-emoji dbus dbus-user-session
echo "DEPS OK"
