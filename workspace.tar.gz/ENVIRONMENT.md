# Окружение для автотестов sidechery-rail-extension

## Главная точка входа — testenv/tests/README.md
Там: как запускать тесты, текущий статус (9/9 tree, 6/7 collapse — C5 реальный остаток бага,
6/6 unload), знания об окружении. Харнесс самовосстанавливающийся — ручная подготовка не нужна.

## Коротко о раскладке
- `/home/user/extension-src/` — распакованное расширение (из repo/sidechery-rail-extension.zip)
- `/home/user/repo/` — клон репозитория
- `/home/user/testenv/tests/harness.mjs` — самодостаточный харнесс (ensureEnv чинит всё сам)
- `/home/user/testenv/tests/*.test.mjs` — три тест-файла (tree/collapse/unload)
- `/home/user/testenv/tests/explore*.mjs, repro*.mjs` — диагностические скрипты
- `/home/user/env/get_chrome.py, get_chrome_ver.py, setup-deps.sh` — запасные скрипты восстановления

## Что сохраняется между сессиями (снапшот ~128MB, только /home/user)
ENVIRONMENT.md, env/*.py+*.sh, repo/, extension-src/, testenv/ (package*.json, тесты, README).

## Что НЕ сохраняется — harness.ensureEnv() восстановит сам при первом запуске теста
- Chrome → /tmp/sdbr-chrome (11с); apt-зависимости и Xvfb (1-2 мин); node_modules (10с);
  тестовые страницы и HTTP-сервер :8901. НИЧЕГО из этого вручную делать не нужно.
- Вручную только если harness сломался: `bash /home/user/testenv/ensure-env.sh` + apt.

## Запуск
```bash
cd /home/user/testenv && npm test        # всё; DISPLAY поднимется сам
```

## Грабли песочницы (проверено на себе)
- HOME=/tmp, НЕ /home/user → только абсолютные пути /home/user.
- Bash heredoc подменяет литерал `/home/user` на `$ARENA_WORKSPACE` → скрипты создавать
  через write_file, не heredoc.
- `pkill -f chrome` убивает сам bash → `killall -9 chrome`.
- Зомби-хромы от упавших прогонов съедают 1GB RAM → ensureEnv делает killall перед стартом.
- `chrome.tabs.discard` в этом контейнере роняет браузер (SIGSEGV) — см. README тестов.
- Снапшот >128MB роняет ПРОИЗВОЛЬНЫЕ файлы воркспейса → держать /home/user лёгким
  (chrome живёт в /tmp!).
- Память 1GB: не больше ~5 http-вкладок в тесте, --process-per-site обязателен для tree-тестов.

## Контекст задачи (для следующей сессии)
Порт Sidebery (v5.6.1, MV3). Рейл = content script rail/rail.js: iframe с sidebar/sidebar.html
внутри каждой http-страницы; слот сайдбара ОДИН на окно (bg: rail/rail.background.part.js,
claimSidebar/transferSidebar/dropSidebar). Настройки Sidebery — chrome.storage.local['settings'],
настройки рейла — ['rail_settings']. Дерево вкладок: DOM .Tab c data-lvl/data-parent/data-folded/
data-discarded; правда bg — storage.local['tabsDataCache'] (parentId). При каждом переключении
вкладок сайдбар пересобирается (1–3с, переходная плоская фаза — норма).
ОСТАТОЧНЫЙ БАГ (тест C5, воспроизводится): клик по кнопке сворачивания ветки (.exp) во время
пересборки сайдбара активирует родительскую вкладку вместо простого сворачивания.
