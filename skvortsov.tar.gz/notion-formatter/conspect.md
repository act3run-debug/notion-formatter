# conspect.md — TRACKERSUPPORT-1674

## 1. Задача
TRACKERSUPPORT-1674 (id 6ab3e6622e5f8b5354cd9bc0, статус «На паузе», pendingReplyFrom 903, проект «Общие задачи PMO D&D» id 90, доска 214). Заявитель — Evgenii Skvortsov (uid 8000000000000470, он же lead очередей STDYMNG/CLNNSFTY/ALLNC).
Требование (улучшение): по Excel-файлу «Project plan 2.0.xlsx» (вложение 40417 задачи) создать **проект** со структурой: Эпик → Задача (очередь из D, тег из G) → Подзадача (очередь по цвету шрифта в I) → Чеклист-пункты (K). Чеклисты — только названия (без исполнителей/дедлайнов). Использовать ТОЛЬКО лист «Setup». Обязательна **итеративность**: повторная загрузка в проект, где уже есть эпики/задачи/подзадачи, не должна дублировать.

### Комментарий-уточнение от Скворцова (122597, 2026-10-07):
- Чеклисты: только название пункта; исполнителя/дедлайн заполнят участники позже.
- Пример строк 3–15: эпик "Study Setup" → задача "Central Trial documents" (очередь STUDY MANAGEMENT, тег "Study Team") → подзадача "Clinical Study Protocol (CSP)" (очередь STUDY MANAGEMENT **согласно цветовой легенде в столбце I**) → чеклист 13 пунктов.
- Только лист «Setup», остальные листы (Planning, Conduct, Study closure) игнорировать.

## 2. Текущая конфигурация
- Excel: /home/user/scripts/project_plan_2.0.xlsx (скачан через GET /v3/issues/TRACKERSUPPORT-1674/attachments/40417/... с OAuth; forms.yandex.ru/cloud/files без авторизации отдаёт HTML-логин).
- Лист Setup: заголовок в строке 2: B=Эпик ID, C=Эпик, D=Очередь(задачи), E=Задача ID, F=Задача, G=Тег 1, H=Подзадача ID, I=Подзадача, J=Чеклист ID, K=Чеклист-пункт, L=Owner (пуст). A3:A8 — легенда цветов шрифта. Данные: строки 3–202 (203 строки с данными, из них 6 строк чеклиста без подзадачи — строки 197-202 для задачи "Unblinding setup"? см. находки).
- Структура: 1 эпик (B=2, "Study Setup"); 11 задач; 70 подзадач (после trim-слияния "IP Import "/"IP Import"); чеклисты у ~40 подзадач + 3 пункта напрямую у задачи "Unblinding setup" (H/I пустые, J/K заполнены).
- Очереди (name→key): STUDY MANAGEMENT→STDYMNG(18), CLINICAL and SAFETY→CLNNSFTY(19), ALLIANCE→ALLNC(20), BIOMETRICS→BIMTRCS(21), QUALITY→QLTY(39, в листе не используется). PREREGLOCALPROC(75)="PreReg Local Processes", lead Kirill Andropov.
- Типы задач: epic=6, task=2 (есть во всех очередях). defaultType: STDYMNG/CLNNSFTY/BIMTRCS/QLTY=epic, ALLNC/NEWTASKS=task.
- Тестовая очередь: NEWTASKS (id 17). Удаление = POST /issues/{key}/_move?queue=DELETE&initialStatus=true&notify=false.
- Тестовый исполнитель: az.kirill.andropov (uid 8000000000000904). Тестовые проекты: 2785 «Тест Трекера 1» (6ab52829dc555b391e385f19), 2786 «Тест Трекера 2».

## 3. План
- [x] Прочитать TRACKERSUPPORT-1674 + комментарии + вложение
- [x] Распарсить лист Setup (эпики/задачи/теги/подзадачи/чеклисты/цвета-очереди)
- [x] Найти очереди по именам (STDYMNG и т.д.)
- [x] Прочитать доку API: создание проекта (v3/projects), создание задач с parent/project/tags, checklistItems (агент №1; доки локально scripts/doc_*)
- [x] Проверить триггеры/автодействия NEWTASKS и 4 целевых очередей (правило из context.md!) — агент №1, см. раздел 5
- [x] Скрипт-парсер Excel → JSON-структура (parse_setup.py → structure.json, агент №1)
- [x] Скрипт-импортёр (идемпотентный: поиск существующих по имени+родителю) — import_structure.py, агент №1
- [x] ТЕСТ в NEWTASKS: эпик/задачи/подзадачи/чеклисты/теги, повторный прогон (итеративность), проверка связей — УСПЕШНО (агент №1, отчёты test_report/test_rerun_report/iter_report.json)
- [x] Убрать тестовый мусор (в DELETE) — выполнено прошлой сессией, верифицировано агентом №2 2026-10-10: 84/84 в DELETE (cleanup_test_oct10.json)
- [x] Боевой прогон в NEWTASKS с ДРУГИМ эпиком (решение пользователя 2026-10-10): создание 81 + идемпотентность 0 + итеративность 2, уборка 83/83 в DELETE
- [ ] Вопросы пользователю: имя/lead целевого проекта; очередь эпика; исполнители; запускать ли в целевых очередях сейчас
- [ ] Боевой прогон (после подтверждения), отчёт, notify-tracker

## 4. Журнал (агент Qwen, 2026-10-10)
- Прочитал context.md + инструкции conspect. Создал conspect.md.
- Установил requests+openpyxl (pip НЕ сохраняется между сессиями — переустановить!). Скрипт-хелпер /home/user/scripts/api.py (call(method,path,body) → (status,json)).
- GET задачи + комментариев: требование и уточнения Скворцова (см. раздел 1).
- Скачал xlsx из вложения 40417 (через Tracker API с OAuth).
- Распарсил Setup: 203 строки данных, 1 эпик, 11 задач, 70 подзадач; цвета шрифта I = очередь подзадачи (theme4+tint0.4=STUDY MANAGEMENT, FFC00000=CLINICAL and SAFETY, theme8-0.25=BIOMETRICS, FF00B050=ALLIANCE, theme5=QUALITY). Все 197 цветных строк распознаны, unknown=0.
- GET /v3/queues/{ключ имени} → 404: в D стоят ИМЕНА очередей, не ключи. Список 127 очередей (поле name, не display!) → маппинг в разделе 2.
- Проверил триггеры/автодействия всех очередей (см. раздел 5). Прочитал доки API (create-issue, create-entity, add-checklist-item).
- Написал parse_setup.py → structure.json: 1 эпик (Study Setup, STDYMNG), 11 задач, 69 подзадач (после trim-слияния "IP Import"), 175 чеклист-пунктов (169 в подзадачах + 6 на задаче "Unblinding setup" строки 200–205).
- Написал import_structure.py (идемпотентный импортёр, dry_run, отчёт). Первый dry-run ЗАВИС: _search без обёртки {"filter":...} игнорирует условия и пагинирует всю организацию → исправил (v3 _search требует {"filter": flt}).
- **НАХОДКА 1:** в NEWTASKS уже есть тест прошлой сессии (2026-10-09, автор Kirill Andropov): эпик NEWTASKS-861 "Study Setup" с 11 задачами из Excel + "NEW Iterative Task" (NEWTASKS-942) — видимо, тест итеративности; и пустой эпик NEWTASKS-680 "Study Setup" (2026-10-06). Будет убрано в DELETE перед моим тестом.
- **НАХОДКА 2 (критично для боевого прогона):** в ЦЕЛЕВЫХ очередях уже есть ДВА реальных эпика "Study Setup": STDYMNG-910 (автор/исп. Natalia Baturina, 2026-06-09, status new, 21 ребёнок) и STDYMNG-930 (автор/исп. Tatiana Belikova, 2026-06-24, status inProgress, 24 ребёнка, вкл. BIMTRCS-1793 'Data Management Setup' 19 детей, BIMTRCS-1794 'Analysis & Reporting Setup' 4 ребёнка). Это РУЧНЫЕ структуры реальных людей, имена похожи на Excel, но НЕ совпадают точно (напр. 'Data Management Plan v1' vs excel 'Data Mangement Plan v1'; пункты чеклистов оформлены подзадачами; 'Regulatory ' с пробелом). Сливание Excel-2.0 в них по имени = трогать чужие задачи и получить мешанину. → ВОПРОС пользователю перед боевым прогоном (см. раздел 6).
- Убрал мусор прошлой сессии: дерево NEWTASKS-861 (83 задачи, вкл. 11 задач Excel + подзадачи + "NEW Iterative Task" 942) + пустой эпик NEWTASKS-680 + 16 «беспризорных» задач NEWTASKS-666..684 (тесты 2026-10-06, родители уже в DELETE) — ВСЕ перенесены в DELETE (100/100, маппинги: cleanup_prev_session.json, cleanup_stray.json). NEWTASKS чиста от структур этой задачи.
- Тест в NEWTASKS — **УСПЕШНО** (config: всё→NEWTASKS, epic_queue NEWTASKS, notify=false, без assignee):
  - Прогон 1 (после 2 падений на баге tkey — исправлен): создано 77 + найдено 4 (эпик NEWTASKS-947, задача 948, подзадачи 949/950 из оборванного прогона) = 81 задача (1 эпик+11 задач+69 подзадач). Чеклисты: 162 добавлено в этом прогоне + 13 (CSP) в оборванном = 175; **дедупликация между прогонами сработала** (в NEWTASKS-949 ровно 13, не 26).
  - Верификация: NEWTASKS-949 CSP чеклист=13 ✓, NEWTASKS-1027 Unblinding чеклист=6 ✓ (на самой задаче), детей у эпика=11 ✓, теги (Study Team/Country Operations/Supporting roles) ✓, типы epic/task ✓, parent ✓. Отчёт: test_report.json.
  - Прогон 2 (идемпотентность): **создано 0, найдено 81, чеклистов добавлено 0** (67 с). Отчёт: test_rerun_report.json.
  - Прогон 3 (итеративность, structure_iter.json = +задача "Site Monitoring (NEW)", +подзадача "CSP Addendum NEW" в существующую задачу, +1 пункт в существующий чеклист CSP): **создано ровно 3** (NEWTASKS-1029/1028/1030), найдено 81, чеклистов +4; CSP стал 14 пунктов, у эпика 12 детей. Отчёт: iter_report.json.
  - Восстановление после обрыва сессии работает (идемпотентный поиск продолжает с места обрыва).
- Уборка теста: (заполню).

### Журнал — агент №2 (Qwen), 2026-10-10, продолжение сессии (после OOM/переноса)
- Действия 1–4: скачал архив skvortsov.tar.gz с https://github.com/act3run-debug/notion-formatter (git clone в /home/user/notion-formatter), распаковал. Состав: conspect.md, uploads/ (conspect md instructions.md, context.md), scripts/ (api.py, parse_setup.py, import_structure.py, structure.json, structure_iter.json, test_config.json, test_run_config.json, отчёты test_report.json / test_rerun_report.json / iter_report.json, логи test_run*.log, уборочные cleanup_prev_session.json / cleanup_stray.json / stray_keys.json / cleanup_tree.py, доки doc_create_entity.md / doc_add_checklist_item.md / doc_llms.txt, project_plan_2.0.xlsx).
- Действия 5–7: прочитал uploads/conspect md instructions.md (правила ведения conspect.md), uploads/context.md (сквозной контекст: орг bpfb300ct6ef4t2kr3l1, уровни тестовости, правила пользователя, особенности Tracker/Forms/Cloud), conspect.md (состояние от агента №1).
- Действия 8–9: изучил scripts/api.py (хелпер call(method,path,body) c OAuth-токеном из context.md), parse_setup.py (парсер листа Setup: легенда цвета шрифта A4:A8 → очередь подзадачи, эпики/задачи/теги/подзадачи/чеклисты), import_structure.py (идемпотентный импортёр: --structure/--config/--report, dry_run, поиск эпика по queue+type=epic+summary, детей — через _search {filter:{parent}} по имени lower/strip, чеклисты — дедуп по тексту, синхронизация тегов PATCH).
- Вывод по состоянию: тест в NEWTASKS полностью успешен (81 задача, 175 пунктов чеклиста, идемпотентность и итеративность подтверждены). ОСТАЛОСЬ: (1) уборка тестового мусора NEWTASKS-947..1030 в DELETE; (2) заполнение раздела 7; (3) ответ пользователя на открытый вопрос про целевой эпик (STDYMNG-910 / STDYMNG-930 / новый) перед боевым прогоном.
- Замечание по среде: рабочая папка теперь /home/user/notion-formatter (в conspect старого агента пути /home/user/scripts/... — актуальны теперь как /home/user/notion-formatter/scripts/...). pip-пакеты (requests, openpyxl) между сессиями НЕ сохраняются — переустановить перед запуском скриптов.
- Действия 11–12: `pip install requests openpyxl` (requests 2.34.2, openpyxl 3.1.5). Связность с API проверена ЖИВЬЁМ: `GET /v3/users/me` → 200 (Дмитрий Быкадоров, uid …808) — OAuth-токен из context.md жив, агент №2 работает с реальным API.
- Действия 13–14: перечитал отчёты (test_report.json: создано 77/найдено 4, эпик NEWTASKS-947; test_rerun_report.json: 0/81; iter_report.json: 3/81, задач 12) и cleanup_tree.py (рекурсивный обход дерева bottom-up → `_move?queue=DELETE`).
- Действие 15 (**важная находка, live-проверка**): `GET /v3/issues/NEWTASKS-947` → ключ уже **DELETE-8705** (очередь DELETE, статус cancelled). То есть уборка тестового дерева БЫЛА выполнена прошлой сессией ПОСЛЕ последней записи в conspect (запись «Уборка теста: (заполню)» осталась незаполненной из-за обрыва).
- Действие 16: полная live-верификация всех 84 ключей из трёх отчётов (эпик + 11 задач + 69 подзадач + 3 итеративных NEWTASKS-1028/1029/1030): **84/84 находятся в очереди DELETE, в NEWTASKS не осталось ни одной, ошибок 0**. Маппинг NEWTASKS-N → DELETE-M сохранён в `scripts/verify_state.json` (создан агентом №2). → Пункт плана «Убрать тестовый мусор» фактически ВЫПОЛНЕН, раздел 7 заполняется.
- Действие 17: в NEWTASKS остались задачи, НЕ относящиеся к моему тесту: NEWTASKS-944/945/946 «Study Conduct (ТЕСТ)» (2026-10-09 18:18, автор Kirill Andropov — след прошлой сессии этой же задачи, лист Conduct) и артефакты 2026-10-06 (NEWTASKS-647 «CSP translation», 661 «Study Conduct (empty epic)», 662 «Task linked to epic by epic-link», 663 «Pre-existing standalone task (iterative load)», 664 «Related bug», 665 «Duplicate of Feasibility», 671 «Feasibility», 678 «Planning») + служебные «Тестовая подзадача» от триггера T136 и PROBE-*/[TEST-*]-задачи других задач. Чужое/не относящееся к TRACKERSUPPORT-1674 НЕ трогаю (правило 1 и 8: убирать только своё); по NEWTASKS-944..946 и 2026-10-06 артефактам — вопрос пользователю (раздел 6).
- Действия 18–19: live-перечитал TRACKERSUPPORT-1674: статус «Требуется информация», pendingReplyFrom 903 (т.е. ответ за нами), исполнитель Kirill Andropov, автор Evgenii Skvortsov, проект «Общие задачи PMO D&D» (90), updatedAt 2026-10-07T13:06. Комментариев всего 2 (122308 наш вопрос от 2026-10-06, 122597 ответ Скворцова от 2026-10-07) — **новых ответов от Скворцова нет**, открытый вопрос про целевой эпик по-прежнему не закрыт. Описание задачи совпадает с конспектом (D=очередь, C=эпик, F=задача, G=тег, I=подзадача, K=пункт чеклиста; критичны: parent-связи, чеклисты, итеративность). Вложения: 40417 «Project plan 2.0.xlsx» и **41578 «image.png»** (скриншот — конспектом агента №1 не описан, проверить). Связь: subtask → TRACKERSUPPORT-523 «Улучшения Tracker / Wiki…».
- Действие 20: запись в conspect (действия 11–19).
- Действие 21: список вложений TRACKERSUPPORT-1674 = 40417 (xlsx, робот Tracker, 2026-09-23) и 41578 (image.png, Скворцов, 2026-10-07 12:48 — за минуту до его комментария 122597).
- Действие 22: скачал image.png через Tracker API (GET /v3/issues/TRACKERSUPPORT-1674/attachments/41578/image.png, OAuth) → scripts/skvortsov_screenshot.png (92702 байт).
- Действие 23: просмотрел скриншот — иллюстрация строк 3–15 листа Setup: эпик «Study Setup», очередь STUDY MANAGEMENT, задача «Central Trial documents», тег «Study Team», подзадача «Clinical Study Protocol (CSP)» (синий шрифт = STUDY MANAGEMENT по легенде), чеклист из 13 пунктов («Create study in VCV - SAD» … «Translation QC - SAD, SCL»). НОВОЙ информации скриншот не несёт (ни имени проекта, ни целевого эпика) — согласуется с разделом 1 и комментарием 122597.
- Действие 24: (a) маппинг уборки теста scripts/cleanup_test_oct10.json (84 ключа NEWTASKS-N → DELETE-M, все queue=DELETE/cancelled); (b) live-проверка STDYMNG: эпики с точным summary «Study Setup» = STDYMNG-910 (Baturina, new, 21 ребёнок) и STDYMNG-930 (Belikova, inProgress, 24 ребёнка), плюс похожие 777 «Study SetUp» (Zheludkov, 0 детей), 797 «Study Setup / SAD» (Skvortsov, closed), 851 «Study Setup / SAD» (Belov, 1 ребёнок). → Боевой импортёр с epic_queue=STDYMNG НАЙДЁТ чужой эпик по точному имени и сольётся в него: без решения пользователя боевой прогон НЕ запускать.
- Действия 25–28: отладка правки conspect (ошибка якоря) + данная запись (заполнение разделов 6/7/8, отметки плана).
- Действие 28 (итог): conspect.md обновлён ТОЛЬКО дописыванием: раздел 3 (план — отмечены выполненные пункты), раздел 4 (журнал 20–28), раздел 6 (новые открытые вопросы 2 и 3), раздел 7 (заполнен маппингом уборки), раздел 8 (блок «состояние на сейчас» агента №2). Ни одна строка прежней истории не удалена.
- Действие 29: в scripts/import_structure.py добавлена поддержка конфигов `epic_key` (явный целевой эпик для слияния, напр. STDYMNG-930 — GET по ключу, поиск пропускается) и `force_new_epic` (создать НОВЫЙ эпик, не сливаясь с чужими одноимёнными). Синтаксис проверен. Без этих флагов боевой прогон в STDYMNG ОПАСЕН (нашёл бы чужой эпик «Study Setup» 910/930).

- Действия 30–32: запись conspect (25–30); dry-run превью трёх сценариев боевого импорта (prod_new_epic_dry / prod_merge930_dry / prod_merge910_dry — все только читают API); задан вопрос пользователю про целевой эпик и остатки в NEWTASKS (форма вопроса прервана пользователем).
- **РЕШЕНИЕ ПОЛЬЗОВАТЕЛЯ (2026-10-10, чат):** боевой прогон делать в NEWTASKS; там создавать ДРУГИЕ эпики (имена изменены) и привязывать к ним тестовые задачи — «тестируем работоспособность исполнения логики в отношении к сущностям трекера, не обязательно тестировать конкретные сущности». Реальные очереди (STDYMNG и др.) и чужие эпики 910/930 НЕ трогаем; открытый вопрос №1 о боевом импорте в реальные очереди остаётся открытым до отдельного решения.
- Действие 33: structure_newepic.json (эпик переименован в «Study Setup — боевой прогон 2026-10-10 (NEWTASKS)», задачи/подзадачи/чеклисты Excel без изменений) + конфиг prod_newtasks_newepic.json (все очереди→NEWTASKS, force_new_epic=true, notify=false).
- Действие 34: **БОЕВОЙ ПРОГОН №1 в NEWTASKS — УСПЕШНО**: создано 81 (эпик NEWTASKS-1031 type=epic + 11 задач + 69 подзадач), отчёт prod_run1_report.json. (Косметика: found=1 в отчёте — дубль-запись эпика из-за ветки force_new_epic в патче, на результат не влияет.)
- Действие 35: верификация: у эпика 1031 ровно 11 детей; чеклистов в дереве 175 (в т.ч. 6 на самой задаче NEWTASKS-1112 «Unblinding setup»); теги задач = Study Team / Supporting roles / Country Operations по Excel; parent-связи корректны.
- Действие 36: повторный прогон с force_new_epic=true СОЗДАЛ ВТОРОЙ комплект (81 задача, эпик NEWTASKS-1113) — **НАХОДКА: force_new_epic отключает идемпотентность по эпику** (каждый запуск создаёт новый эпик, дети ищутся под ним и создаются заново). Для идемпотентных прогонов использовать epic_key (или поиск без force_new_epic).
- Действие 37: дубль-дерево прогона №2 убрано: cleanup_tree.py NEWTASKS-1113 → 81/81 в DELETE, маппинг cleanup_prod_run2.json.
- Действие 38: прогон №3 (идемпотентность, конфиг prod_newtasks_idem.json с epic_key=NEWTASKS-1031): **создано 0, найдено 81, чеклистов добавлено 0** (68 с), отчёт prod_run3_idem_report.json.
- Действие 39: прогон №4 (итеративность, structure_newepic_iter.json: +задача «Site Monitoring (NEW)», +подзадача «CSP Addendum NEW», +1 пункт чеклиста в CSP): **создано ровно 2** (NEWTASKS-1195 задача, подзадача CSP Addendum NEW), найдено 81, отчёт prod_run4_iter_report.json.
- Действие 40: верификация итеративности (см. verify_iter_oct10.json) + данная запись.
- Действие 41: уборка боевого прогона №1: cleanup_tree.py NEWTASKS-1031 → **83/83 в DELETE** (81 прогон №1 + 1194 + 1195 итеративные), маппинг scripts/cleanup_prod_run1.json.
- Действие 42: верификация чистоты: в NEWTASKS 57 задач, моих (ключи ≥1031) не осталось; маппинги run1 (83) + run2 (81) — все DELETE; спот-проверка NEWTASKS-1031/1194/1113 → DELETE cancelled.
- Действие 43: NEWTASKS-1040 «Тест IAM-авторизации Tracker MCP» (created 2026-10-10 09:17, автор Vladislav Kumantcov) — ЧУЖАЯ задача, к моему тесту не относится → НЕ трогаю (правило 1).
- Действие 44: данная запись: раздел 7 дополнен артефактами боевого прогона, план отмечен, раздел 8 актуализирован.

### Итог боевого прогона в NEWTASKS (агент №2, 2026-10-10) — по решению пользователя
| Прогон | Конфиг | Результат |
|---|---|---|
| №1 создание | prod_newtasks_newepic.json (force_new_epic) | создано 81: эпик NEWTASKS-1031 + 11 задач + 69 подзадач; чеклистов 175; теги/parent/type проверены (prod_run1_report.json) |
| №2 (ошибка конфига) | тот же force_new_epic | создан дубль-комплект (эпик NEWTASKS-1113 + 80) → убран 81/81 в DELETE (cleanup_prod_run2.json); находка: force_new_epic отключает идемпотентность |
| №3 идемпотентность | prod_newtasks_idem.json (epic_key=1031) | создано 0, найдено 81, чеклистов +0 (prod_run3_idem_report.json) |
| №4 итеративность | structure_newepic_iter.json + epic_key | создано ровно 2 (NEWTASKS-1195 «Site Monitoring (NEW)», NEWTASKS-1194 «CSP Addendum NEW»), чеклист CSP 13→14 (prod_run4_iter_report.json, verify_iter_oct10.json) |
| Уборка | cleanup_tree.py | дерево 1031: 83/83 → DELETE (cleanup_prod_run1.json) |
## 5. Находки API
- GET /v3/queues возвращает поле `name` (не `display`); в списке `display=None`.
- forms.yandex.ru/cloud/files?path=... без авторизации → HTML (200) — качать вложения через Tracker API `/v3/issues/{key}/attachments/{id}/{filename}` с OAuth-заголовками.
- В списке очередей 127 шт., нужные существуют.
- (проверено ранее в context.md) удаление задач только через _move в DELETE.
- **Триггеры/автодействия (проверено 2026-10-10):**
  - NEWTASKS: T136 «Копирование приоритетов №2» (active) — на Event.comment-create создаёт подзадачу «Тестовая подзадача» → **не комментировать тестовые задачи в NEWTASKS**. T524/525/526 (active) — на clarifyingThePriority (не трогаем). T81/129/138/196/197/280 — неактивны. Автодействие 2 — неактивно.
  - STDYMNG, CLNNSFTY, BIMTRCS: триггеров/автодействий НЕТ.
  - ALLNC: T514 (active) Event.create → Transition в статус «Новый» (безвредно).
- API создания: задача `POST /v3/issues` {summary, queue, type, parent, tags[], project:{primary:shortId}, assignee, unique}; проект `POST /v3/entities/project` {"fields":{summary, lead, description,...}}; пункт чеклиста `POST /v3/issues/{key}/checklistItems` {"text": ...} (по одному); чтение чеклиста `GET /v3/issues/{key}/checklistItems`. Поиск `POST /v3/issues/_search` (summary — точное совпадение; parent — по родителю).
- Доки скачаны локально: scripts/doc_create_entity.md, doc_add_checklist_item.md, doc_llms.txt (индекс всех страниц API).

## 6. Решения и открытые вопросы
Решения:
- **Проект НЕ указываем** — пользователь (2026-10-10): «excel содержит исчерпывающую информацию; если проект не указан — его не нужно указывать». В Excel имени проекта нет (проверил все 4 листа). Задачи создаются без поля project.
- **Исполнитель не назначается** — столбец L (Owner) пуст во всех строках; Скворцов: аллокация позже.
- **Очередь эпика "Study Setup" = STDYMNG** (STUDY MANAGEMENT): D первой строки эпика (строка 3), defaultType очереди — epic, lead — Скворцов. В скрипте параметр конфигурации.
- Только лист Setup (комментарий Скворцова). Листы Planning (эпик 1), Conduct (эпик 3), Study closure — не используем сейчас.
- Очередь подзадачи — из цвета шрифта I (легенда A4:A8), не из D.
- Ключ идемпотентности — (имя + родитель); Excel-ID только для порядка. Trim имён обязателен ("IP Import "/"IP Import" → один).
- Чеклист-пункты без подзадачи (H/I пусто, J/K есть) — на саму задачу.
- Теги из G — как есть (теги в Трекере свободные, создаются автоматически).
Открытые вопросы (задать ПЕРЕД боевым прогоном):
1. **Целевой эпик для боевого импорта**: (A) создать НОВЫЙ эпик "Study Setup" в STDYMNG с чистой структурой Excel 2.0 (будет 3-й одноимённый); (B) слить в STDYMNG-930 (Belikova, inProgress — ближе всего к Excel); (C) слить в STDYMNG-910 (Baturina); (D) спросить Скворцова комментарием в TRACKERSUPPORT-1674. Без ответа боевой прогон НЕ делать (риск задеть задачи реальных людей).
2. **Остатки прошлых сессий в NEWTASKS** (агент №2, 2026-10-10): убрать ли NEWTASKS-944/945/946 «Study Conduct (ТЕСТ)» (2026-10-09) и артефакты 2026-10-06 (NEWTASKS-647, 661, 662, 663, 664, 665, 671, 678 — «CSP translation», «Study Conduct (empty epic)», «Planning», «Feasibility» и пр., созданы тем же токеном в рамках этой же задачи/семейства задач)? Агент №2 их НЕ трогал (правило 1). По умолчанию: не трогать, если пользователь не скажет иное.
3. **Нужен ли боевой прогон сейчас** — либо TRACKERSUPPORT-1674 закрывается как «возможность импорта продемонстрирована, скрипты готовы», а боевой запуск делает Скворцов/отдельный запрос.

## 7. Тестовые артефакты и уборка
(пока ничего не создано)
### Заполнено агентом №2, 2026-10-10 (live-верификация)
- Тест агента №1 в NEWTASKS: эпик NEWTASKS-947 + 11 задач + 69 подзадач (прогон 1) + NEWTASKS-1028/1029/1030 (итеративный прогон 3) = **84 задачи**. Убраны прошлой сессией (после последней записи журнала агента №1): все 84 перенесены в очередь DELETE (`_move?queue=DELETE&initialStatus=true&notify=false`), статусы cancelled.
- Полный маппинг NEWTASKS-N → DELETE-M: **scripts/cleanup_test_oct10.json** (исходник scripts/verify_state.json). Пример: NEWTASKS-947 → DELETE-8705, NEWTASKS-948 → DELETE-8630.
- В NEWTASKS после уборки не осталось ни одной задачи моего/агента №1 теста этой задачи (поиск по очереди: 56 задач — все чужие/других задач/служебные от триггера T136).
- Уборка мусора ДО теста (агент №1): дерево NEWTASKS-861 (83 задачи) + NEWTASKS-680 + 16 беспризорных NEWTASKS-666..684 → DELETE (cleanup_prev_session.json, cleanup_stray.json).
- Предстоит убрать: ничего из моего. По NEWTASKS-944..946 и артефактам 2026-10-06 — вопрос пользователю (раздел 6, п.2).
- Боевой прогон ещё не выполнялся → боевых артефактов нет.
- БОЕВОЙ ПРОГОН В NEWTASKS (агент №2): дерево эпика NEWTASKS-1031 (83 задачи: 81 + 2 итеративных) → DELETE, маппинг scripts/cleanup_prod_run1.json; дубль-дерево эпика NEWTASKS-1113 (81 задача, ошибка конфига force_new_epic) → DELETE, маппинг scripts/cleanup_prod_run2.json. Отчёты: prod_run1_report.json, prod_run2_report.json, prod_run3_idem_report.json, prod_run4_iter_report.json, verify_iter_oct10.json. В реальных очередях (STDYMNG/CLNNSFTY/ALLNC/BIMTRCS/QLTY) НИЧЕГО не создано и не изменено.

## 8. Для следующего агента
- Сессия: Qwen, 2026-10-10. Остановились: Excel распарсен, очереди найдены. ДАЛЬШЕ: (1) pip install requests openpyxl; (2) прочитать доку: llms.txt https://yandex.ru/support/tracker/ru/llms.txt → страницы про создание проектов (v3 /projects), checklist items, создание задач с parent/tags/project; (3) проверить триггеры NEWTASKS + STDYMNG/CLNNSFTY/ALLNC/BIMTRCS (GET /v3/triggers?queue=...) перед созданием задач; (4) написать parse_setup.py → structure.json и import_structure.py (dry-run режим обязателен); (5) тест в NEWTASKS.
- Скрипты: /home/user/scripts/api.py (хелпер), project_plan_2.0.xlsx (Excel).
- Парсер уже написан инлайн в журнальных bash-вызовах — логику цвета/легенды см. раздел 5 и журнал; переписать в parse_setup.py.
- Секреты: OAuth-токен в api.py (из context.md, не временный). IAM не нужен (всё через Tracker REST).

### Дополнение агента №2 (2026-10-10): состояние на сейчас
- ОСТАНОВИЛИСЬ (агент №2, конец смены 2026-10-10): боевой прогон в NEWTASKS с переименованным эпиком выполнен и убран (см. таблицу в разделе 4); логика импорта подтверждена end-to-end: создание иерархии эпик→задача→подзадача, теги, чеклисты (в т.ч. пункты напрямую на задаче), идемпотентность (0 дублей), итеративность (+2 задачи, +1 пункт чеклиста). Открытым остаётся вопрос №1 (импорт в РЕАЛЬНЫЕ очереди STDYMNG и др. / слияние в 910/930) — решать с пользователем/Скворцовым.
- (историч.) ОСТАНОВИЛИСЬ: тест завершён и убран (верифицировано live), боевой прогон ЗАБЛОКИРОВАН открытым вопросом №1 (целевой эпик в STDYMNG: новый / слить в 930 / слить в 910 / спросить Скворцова).
- ДАЛЬШЕ: (1) получить ответ пользователя (ask_user в чате; при необходимости notify-tracker в TRACKERSUPPORT-1698); (2) вариант «новый эпик»: импортёр найдёт чужой одноимённый эпик по точному имени — добавить в import_structure.py поддержку cfg['epic_key'] (пропустить поиск) либо уникальное имя; (3) варианты «слить в 910/930»: cfg['epic_key'] + dry_run и сверка имён детей (у 910/930 имена НЕ совпадают с Excel точно: «Data Management Plan v1» vs «Data Mangement Plan v1», «Regulatory » с пробелом) — решить, что считать дублем; (4) боевой прогон только после ответа; (5) отчёт + notify-tracker «Задача завершена».
- Файлы агента №2: scripts/verify_state.json, scripts/cleanup_test_oct10.json, scripts/skvortsov_screenshot.png (вложение 41578).
- Секреты: OAuth-токен в scripts/api.py (постоянный, из context.md). IAM не нужен.
