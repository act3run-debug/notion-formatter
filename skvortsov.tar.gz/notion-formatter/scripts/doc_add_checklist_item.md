---
metadata:
  - name: generator
    content: Diplodoc Platform v5.63.2
  - property: og:type
    content: article
  - property: article:section
    content: Справочник API
  - property: og:title
    content: Создать чеклист или добавить в него пункты
  - property: article:tag
    content: Техническая инструкция
alternate:
  - https://yandex.ru/support/tracker/en/api/issues/add-checklist-item.md
  - https://yandex.ru/support/tracker/ru/api/issues/add-checklist-item.md
  - href: https://yandex.ru/support/tracker/ru/api/issues/add-checklist-item.md
    type: text/markdown
    title: Markdown version
  - href: https://yandex.ru/support/tracker/ru/llms.txt?revision=r21584721
    rel: describedby
---
> **Documentation Index:** Fetch the complete configuration index at https://yandex.ru/support/tracker/ru/llms.txt?revision=r21584721


# Создать чеклист или добавить в него пункты

Запрос позволяет создать [чеклист](https://yandex.ru/support/tracker/user/checklist.html) и добавить в него новые пункты.

<div class="request_example yfm-code-floating-container method_post">
    <p>POST</p>
    <pre><code>https://api.tracker.yandex.net/v3/issues/{id_задачи}/checklistItems</code></pre>
    <button class="yfm-clipboard-button"><svg width="16" height="16" viewBox="0 0 24 24" class="yfm-clipboard-icon" data-animation="15">
    <path fill="currentColor" d="M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z"></path>
    <path stroke="currentColor" fill="transparent" strokewidth="1.5" d="M9.5 13l3 3l5 -5" visibility="hidden">
        <animate id="visibileAnimation-15" attributeName="visibility" from="hidden" to="visible" dur="0.2s" fill="freeze" begin=""></animate>
        <animate id="hideAnimation-15" attributeName="visibility" from="visible" to="hidden" dur="1s" begin="visibileAnimation-15.end+1" fill="freeze"></animate>
    </path>
</svg>
</button>
</div>

<!-- source: ru/api/_assets/style/methods.md -->

<!-- endsource: ru/api/_assets/style/methods.md -->

## Формат запроса {#query}

Перед выполнением запроса [получите доступ к API](https://yandex.ru/support/tracker/ru/api/access.md).

Чтобы создать чеклист или добавить в него новые пункты, используйте HTTP-запрос с методом `POST`. В теле запроса укажите параметры в формате JSON.

```json translate=no
POST /v3/issues/{id_задачи}/checklistItems
Host: api.tracker.yandex.net
Authorization: OAuth API_TOKEN
Content-Type: application/json
X-Org-ID или X-Cloud-Org-ID: ИДЕНТИФИКАТОР_ОРГАНИЗАЦИИ

{
    "text": "ТЕКСТ_ПУНКТА",
    "checked": true,
    "assignee" : "ЛОГИН_ИЛИ_ИДЕНТИФИКАТОР_ПОЛЬЗОВАТЕЛЯ",
    "deadline": {
            "date": "2021-05-09T00:00:00.000+0000",
            "deadlineType": "date"
        }
}
```
<!-- source: ru/api/_includes/headings.md -->
{% cut "Заголовки" %}

* `Host`: адрес узла, предоставляющего API.

* <!-- source: ru/api/_includes/authorization.md -->
  `Authorization`: токен для авторизации в одном из форматов:

    - `OAuth OAUTH_TOKEN` при авторизации по протоколу OAuth 2.0. [Читать подробнее](https://yandex.ru/support/tracker/ru/api/access.md#about_OAuth)

    - `Bearer IAM_TOKEN` при авторизации с помощью IAM-токена — если к Трекеру привязана организация Yandex Identity Hub. [Читать подробнее](https://yandex.ru/support/tracker/ru/api/access.md#iam-token)
  <!-- endsource: ru/api/_includes/authorization.md -->

* <!-- source: ru/api/_includes/content-type-json.md -->
  `Content-Type`: формат тела запроса. Должен иметь значение `application/json`.
  <!-- endsource: ru/api/_includes/content-type-json.md -->


* <!-- source: ru/api/_includes/org-id.md -->
  `X-Org-ID` или `X-Cloud-Org-ID`: идентификатор организации.

  - если к Трекеру привязана организация Яндекс 360 для бизнеса, используйте заголовок `X-Org-ID`,

  - если к Трекеру привязана организация Yandex Identity Hub, используйте заголовок `X-Cloud-Org-ID`.
  <!-- endsource: ru/api/_includes/org-id.md -->

  <!-- source: ru/api/_includes/org-id.md -->
  Чтобы узнать идентификатор организации, перейдите на страницу **Администрирование** → [**Организации**](https://tracker.yandex.ru/admin/orgs) и скопируйте значение поля **идентификатор**.
  <!-- endsource: ru/api/_includes/org-id.md -->


{% endcut %}
<!-- endsource: ru/api/_includes/headings.md -->

{% cut "Параметры тела запроса" %}

Тело запроса содержит информацию, необходимую для создания чеклиста или добавления в него пункта:

**Обязательные параметры**

Параметр | Описание | Тип данных
----- | ----- | -----
text | Текст пункта. | Строка


**Дополнительные параметры**

Параметр | Описание | Тип данных
----- | ----- | -----
checked | Отметка о выполнении пункта: <ul><li>`true` — пункт отмечен как выполненный;</li><li>`false` — пункт не отмечен как выполненный.</li></ul> | Логический
assignee | Идентификатор или логин пользователя, который назначен исполнителем пункта чеклиста. | Строка
[deadline](#deadline-checklist) | Дедлайн пункта чеклиста. | Объект


**Поля объекта** `deadline` {#deadline-checklist}

Параметр | Описание | Тип данных
----- | ----- | -----
date | Дата дедлайна в формате `YYYY-MM-DDThh:mm:ss.sss±hhmm`. | Дата
deadlineType | Тип данных параметра `deadline`. | Строка


{% endcut %}

## Формат ответа {#answer}

{% list tabs %}

- Запрос выполнен успешно

    <!-- source: ru/api/_includes/answer-200.md -->
    В случае успешного выполнения запроса API возвращает ответ с кодом `200 OK`.
    <!-- endsource: ru/api/_includes/answer-200.md -->

    Тело ответа содержит JSON-объект с параметрами чеклиста и задачи, в которую он был добавлен.

    ```json translate=no
    {
        "self": "https://api.tracker.yandex.net/v3/issues/ORG-3",
        "id": "5f981c00b982f075********",
        "key": "ORG-3",
        "version": 133,
        "lastCommentUpdatedAt": "2020-12-13T13:18:22.965+0000",
        "pendingReplyFrom": [
            {
                "self": "https://api.tracker.yandex.net/v3/users/11********",
                "id": "11********",
                 "display": "Имя Фамилия"
            }
        ],
        "summary": "My issue",
        "statusStartTime": "2020-11-03T11:19:24.733+0000",
        "updatedBy": {
            "self": "https://api.tracker.yandex.net/v3/users/11********",
            "id": "11********",
            "display": "Имя Фамилия"
        },
        "description": "My description",
        "type": {
            "self": "https://api.tracker.yandex.net/v3/issuetypes/2",
            "id": "2",
            "key": "task",
            "display": "Задача"
        },
        "priority": {
            "self": "https://api.tracker.yandex.net/v3/priorities/3",
            "id": "3",
            "key": "normal",
            "display": "Средний"
        },
        "previousStatusLastAssignee": {
            "self": "https://api.tracker.yandex.net/v3/users/11********",
            "id": "11********",
            "display": "Имя Фамилия"
        },
        "createdAt": "2020-10-27T13:09:20.085+0000",
        "followers": [
            {
                "self": "https://api.tracker.yandex.net/v3/users/11********",
                "id": "11********",
                "display": "Имя Фамилия"
            }
        ],
        "createdBy": {
            "self": "https://api.tracker.yandex.net/v3/users/11********",
            "id": "11********",
            "display": "Имя Фамилия"
        },
        "checklistItems": [
            {
                "id": "5fde5f0a1aee261d********",
                "text": "List item text",
                "textHtml": "List item text in HTML",
                "checked": false,
                "checklistItemType": "standard"
            }
        ],
        "votes": 0,
        "assignee": {
            "self": "https://api.tracker.yandex.net/v3/users/11********",
            "id": "11********",
            "display": "Имя Фамилия"
        },
        "deadline": "2020-10-28",
        "queue": {
            "self": "https://api.tracker.yandex.net/v3/queues/ORG",
            "id": "1",
            "key": "ORG",
            "display": "My queue"
        },
        "updatedAt": "2020-12-19T20:14:02.648+0000",
        "status": {
            "self": "https://api.tracker.yandex.net/v3/statuses/1",
            "id": "1",
            "key": "open",
            "display": "Открыт"
        },
        "previousStatus": {
            "self": "https://api.tracker.yandex.net/v3/statuses/3",
            "id": "3",
            "key": "resolved",
            "display": "Решен"
        },
        "favorite": false
    }
    ```

    {% cut "Параметры ответа" %}

    <!-- source: ru/api/_includes/issue-response-fields-note.md -->
    {% note info "" %}

    В таблице перечислены основные поля ответа. Полный список полей и их описание см. на странице [Параметры ответа](https://yandex.ru/support/tracker/ru/api/issues/response-fields.md).

    Также в ответе могут содержаться глобальные пользовательские поля и локальные поля очередей.

    {% endnote %}
    <!-- endsource: ru/api/_includes/issue-response-fields-note.md -->

    Параметр | Описание | Тип данных
    ----- | ----- | -----
    self | Адрес ресурса API, который содержит информацию о задаче. | Строка
    id | Идентификатор задачи. | Строка
    version | Версия задачи. Каждое изменение параметров увеличивает номер версии. <br>Редактирование задачи будет заблокировано, если версия достигнет предельного значения: для роботов `10100`, для пользователей `11100`. | Число
    key | Ключ задачи. | Строка
    [pendingReplyFrom](#pending-reply-from) | Объект с информацией о сотруднике, от которого ожидается ответ. | Объект
    lastCommentUpdatedAt | Время обновления последнего комментария. | Строка
    summary | Название задачи. | Строка
    statusStartTime | Время создание задачи. | Строка
    [updatedBy](#updated-by) | Объект с информацией о последнем сотруднике, изменявшим задачу. | Объект
    description | Описание задачи. | Строка
    [type](#type) | Объект с информацией о типе задачи. | Объект
    [priority](#priority) | Объект с информацией о приоритете. | Объект
    [previousStatusLastAssignee](#previous-status-last-assignee) | Объект с информацией об исполнителе задачи в предыдущем статусе. | Объект
    createdAt | Дата и время создания задачи. | Строка
    [followers](#followers) | Массив объектов с информацией о наблюдателях задачи. | Объект
    [createdBy](#created-by) | Объект с информацией о создателе задачи. | Объект
    [checklistItems](#checklist-items) | Массив объектов с информацией о пунктах чеклиста. | Объект
    votes | Количество голосов за задачу. | Число
    [assignee](#assignee) | Объект с информацией об исполнителе задачи. | Объект
    deadline | Крайний срок выполнения задачи. | Строка
    updatedAt | Дата и время последнего обновления задачи. | Строка
    [queue](#queue) | Объект с информацией об очереди задачи. | Объект
    [status](#status) | Объект с информацией о статусе задачи. | Объект
    [previousStatus](#previous-status) | Объект с информацией о предыдущем статусе задачи. | Объект
    favorite | Признак избранной задачи:<ul><li>`true` — пользователь добавил задачу в избранное;</li><li>`false` — задача не добавлена в избранное.</li></ul> | Число

    **Поля объекта** `updatedBy` {#updated-by}

    <!-- source: ru/api/_includes/user.md -->
    Параметр | Описание | Тип данных
    ----- | ----- | -----
    self | Адрес ресурса API, который содержит информацию о пользователе. | Строка
    id | Идентификатор пользователя. | Строка
    display | Отображаемое имя пользователя. | Строка
    passportUid | Уникальный идентификатор аккаунта пользователя в организации Яндекс 360 для бизнеса и Яндекс ID. | Число
    cloudUid | Уникальный идентификатор пользователя в Yandex Identity Hub. | Строка
    <!-- endsource: ru/api/_includes/user.md -->

    **Поля объекта** `pendingReplyFrom` {#pending-reply-from}

    <!-- source: ru/api/_includes/user.md -->
    Параметр | Описание | Тип данных
    ----- | ----- | -----
    self | Адрес ресурса API, который содержит информацию о пользователе. | Строка
    id | Идентификатор пользователя. | Строка
    display | Отображаемое имя пользователя. | Строка
    passportUid | Уникальный идентификатор аккаунта пользователя в организации Яндекс 360 для бизнеса и Яндекс ID. | Число
    cloudUid | Уникальный идентификатор пользователя в Yandex Identity Hub. | Строка
    <!-- endsource: ru/api/_includes/user.md -->

    <!-- source: ru/api/_includes/type.md -->
    **Поля объекта** `type` {#type}

    Параметр | Описание | Тип данных
    ----- | ----- | -----
    self | Адрес ресурса API, который содержит информацию о типе задаче. | Строка
    id | Идентификатор типа задачи. | Строка
    key | Ключ типа задачи. | Строка
    display | Отображаемое название типа задачи. | Строка
    <!-- endsource: ru/api/_includes/type.md -->

    <!-- source: ru/api/_includes/priority.md -->
    **Поля объекта** `priority` {#priority}

    Параметр | Описание | Тип данных
    ----- | ----- | -----
    self | Адрес ресурса API, который содержит информацию о приоритете. | Строка
    id | Идентификатор приоритета. | Строка
    key | Ключ приоритета. | Строка
    display | Отображаемое название приоритета. | Строка
    <!-- endsource: ru/api/_includes/priority.md -->

    **Поля объекта** `previousStatusLastAssignee` {#previous-status-last-assignee}

    <!-- source: ru/api/_includes/user.md -->
    Параметр | Описание | Тип данных
    ----- | ----- | -----
    self | Адрес ресурса API, который содержит информацию о пользователе. | Строка
    id | Идентификатор пользователя. | Строка
    display | Отображаемое имя пользователя. | Строка
    passportUid | Уникальный идентификатор аккаунта пользователя в организации Яндекс 360 для бизнеса и Яндекс ID. | Число
    cloudUid | Уникальный идентификатор пользователя в Yandex Identity Hub. | Строка
    <!-- endsource: ru/api/_includes/user.md -->

    **Поля объекта** `followers` {#followers}

    <!-- source: ru/api/_includes/user.md -->
    Параметр | Описание | Тип данных
    ----- | ----- | -----
    self | Адрес ресурса API, который содержит информацию о пользователе. | Строка
    id | Идентификатор пользователя. | Строка
    display | Отображаемое имя пользователя. | Строка
    passportUid | Уникальный идентификатор аккаунта пользователя в организации Яндекс 360 для бизнеса и Яндекс ID. | Число
    cloudUid | Уникальный идентификатор пользователя в Yandex Identity Hub. | Строка
    <!-- endsource: ru/api/_includes/user.md -->

    **Поля объекта** `createdBy` {#created-by}

    <!-- source: ru/api/_includes/user.md -->
    Параметр | Описание | Тип данных
    ----- | ----- | -----
    self | Адрес ресурса API, который содержит информацию о пользователе. | Строка
    id | Идентификатор пользователя. | Строка
    display | Отображаемое имя пользователя. | Строка
    passportUid | Уникальный идентификатор аккаунта пользователя в организации Яндекс 360 для бизнеса и Яндекс ID. | Число
    cloudUid | Уникальный идентификатор пользователя в Yandex Identity Hub. | Строка
    <!-- endsource: ru/api/_includes/user.md -->

    **Поля объекта** `checklistItems` {#checklist-items}

    <!-- source: ru/api/_includes/checklist-items.md -->
    Параметр | Описание | Тип данных
    ----- | ----- | -----
    id | Идентификатор пункта чеклиста. | Строка
    text | Текст пункта чеклиста. | Строка
    textHtml | Текст пункта чеклиста в формате HTML. | Строка
    checked | Признак выполнения пункта чеклиста:<ul><li>`true` — пункт отмечен как выполненный;</li><li>`false` — пункт не отмечен как выполненный.</li></ul> | Логический
    assignee | Исполнитель пункта чеклиста. | Объект
    [deadline](#deadline-checklist) | Крайний срок исполнения пункта чеклиста. | Объект
    checklistItemType | Тип пункта чеклиста. | Строка
    <!-- endsource: ru/api/_includes/checklist-items.md -->

    **Поля объекта** `assignee` **(пункт чеклиста)** {#assignee-checklist}

    <!-- source: ru/api/_includes/checklist-items.md -->
    Параметр | Описание | Тип данных
    ----- | ----- | -----
    id | Идентификатор пользователя. | Число
    display | Отображаемое имя пользователя. | Строка
    passportUid | Уникальный идентификатор аккаунта пользователя на Яндексе. | Число
    login | Логин пользователя. | Строка
    firstName | Имя пользователя. | Строка
    lastName | Фамилия пользователя. | Строка
    email | Адрес пользователя. | Строка
    trackerUid | Уникальный идентификатор аккаунта пользователя в Трекере. | Число
    <!-- endsource: ru/api/_includes/checklist-items.md -->

    **Поля объекта** `deadline` **(пункт чеклиста)** {#deadline-checklist}

    <!-- source: ru/api/_includes/checklist-items.md -->
    Параметр | Описание | Тип данных
    ----- | ----- | -----
    date | Предельный срок в формате `YYYY-MM-DDThh:mm:ss.sss±hhmm`. | Дата
    deadlineType | Тип дедлайна:<ul><li>`date` — дата;</li><li>`quarter` — квартал.</li></ul> | Строка
    isExceeded | Признак наступления дедлайна: <ul><li>`true` — предельный срок наступил;</li><li>`false` — предельный срок не наступил.</li></ul> | Логический
    <!-- endsource: ru/api/_includes/checklist-items.md -->

    **Поля объекта** `queue` {#queue}

    <!-- source: ru/api/_includes/queue.md -->
    Параметр | Описание | Тип данных
    ----- | ----- | -----
    self | Адрес ресурса API, который содержит информацию об очереди. | Строка
    id | Идентификатор очереди. | Строка
    key | Ключ очереди. | Строка
    display | Отображаемое название очереди. | Строка
    <!-- endsource: ru/api/_includes/queue.md -->

    **Поля объекта** `status` {#status}

    <!-- source: ru/api/_includes/status.md -->
    Параметр | Описание | Тип данных
    ----- | ----- | -----
    self | Адрес ресурса API, который содержит информацию о статусе. | Строка
    id | Идентификатор статуса. | Строка
    key | Ключ статуса. | Строка
    display | Отображаемое название статуса. | Строка
    <!-- endsource: ru/api/_includes/status.md -->

    **Поля объекта** `previousStatus` {#previous-status}

    <!-- source: ru/api/_includes/status.md -->
    Параметр | Описание | Тип данных
    ----- | ----- | -----
    self | Адрес ресурса API, который содержит информацию о статусе. | Строка
    id | Идентификатор статуса. | Строка
    key | Ключ статуса. | Строка
    display | Отображаемое название статуса. | Строка
    <!-- endsource: ru/api/_includes/status.md -->

    {% endcut %}

- Запрос выполнен с ошибкой

    Если запрос не был успешно обработан, API возвращает ответ с кодом ошибки:

    <!-- source: ru/api/_includes/answer-error-400.md -->
    400
    :   Один или несколько параметров запроса имеют недопустимое значение.
    <!-- endsource: ru/api/_includes/answer-error-400.md -->

    <!-- source: ru/api/_includes/answer-error-404.md -->
    404
    :   Запрошенный объект не был найден. Возможно, вы указали неверное значение идентификатора или ключа объекта.
    <!-- endsource: ru/api/_includes/answer-error-404.md -->

    <!-- source: ru/api/_includes/answer-error-422.md -->
    422 
    :   Ошибка валидации JSON, запрос отклонен.
    <!-- endsource: ru/api/_includes/answer-error-422.md -->

    <!-- source: ru/api/_includes/answer-error-423.md -->
    423
    :   Редактирование объекта заблокировано. Возможно, превышено допустимое значение параметра `version` — количество обновлений объекта. Максимальное значение версии составляет `10100` для роботов и `11100` для пользователей. 
    <!-- endsource: ru/api/_includes/answer-error-423.md -->

{% endlist %}
