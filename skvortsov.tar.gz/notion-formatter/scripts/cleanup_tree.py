"""Уборка тестового мусора: рекурсивный обход дерева от корневых ключей → перенос в DELETE (снизу вверх).
Usage: python cleanup_tree.py ROOT_KEY [ROOT_KEY...] [--out mapping.json]
"""
import json, sys, time
from api import call

def kids(key):
    out, page = [], 1
    while True:
        sc, d = call("POST", f"/v3/issues/_search?perPage=100&page={page}", {"filter": {"parent": key}})
        if sc != 200:
            raise RuntimeError(f"search {sc}: {str(d)[:200]}")
        out += [(i["key"], i.get("summary")) for i in d]
        if len(d) < 100:
            return out
        page += 1

def collect(key, depth=0, seen=None):
    """возвращает список ключей bottom-up (дети раньше родителей)"""
    if seen is None: seen = set()
    if key in seen: return []
    seen.add(key)
    order = []
    for ck, cs in kids(key):
        order += collect(ck, depth + 1, seen)
    order.append(key)
    return order

def move_to_delete(key):
    for path in (f"/v3/issues/{key}/_move?queue=DELETE&initialStatus=true&notify=false",
                 f"/v2/issues/{key}/_move?queue=DELETE&notify=false"):
        sc, d = call("POST", path)
        if sc in (200, 201):
            return True, path.split("/")[1]
        if sc not in (404, 405, 400):
            return False, f"{sc}: {str(d)[:150]}"
    return False, f"last: {sc} {str(d)[:150]}"

if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    out = None
    if "--out" in sys.argv:
        out = sys.argv[sys.argv.index("--out") + 1]
        args = [a for a in args if a != out]
    mapping = {}
    for root in args:
        order = collect(root)
        print(f"{root}: дерево из {len(order)} задач", flush=True)
        for k in order:
            ok, info = move_to_delete(k)
            mapping[k] = "DELETE" if ok else f"FAIL {info}"
            print(("  ✓ " if ok else "  ✗ ") + k + ("" if ok else f" {info}"), flush=True)
            time.sleep(0.15)
    if out:
        json.dump(mapping, open(out, "w"), ensure_ascii=False, indent=1)
        print("mapping saved:", out)
    fails = [k for k, v in mapping.items() if v != "DELETE"]
    print(f"ИТОГО перенесено {len(mapping) - len(fails)}/{len(mapping)}", "ошибки:" if fails else "", fails)
