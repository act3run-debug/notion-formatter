"""Идемпотентный импорт структуры (structure.json) в Yandex Tracker — TRACKERSUPPORT-1674.

Эпик → задачи (очередь из queue, теги) → подзадачи (очередь из queue) → чеклисты.
Повторный запуск не дублирует: поиск по (родитель + имя); чеклист — по тексту пунктов.
Конфиг: --config <json> {queue_map:{excelQueue:trackerKey}, epic_queue, assignee?, dry_run?, notify?}
Отчёт: --report <json> (маппинг excel→ключи задач, для уборки/проверки).
"""
import argparse, json, sys, time
from api import call

def req(method, path, body=None, params=None, tries=4):
    for i in range(tries):
        sc, d = call(method, path, body, params)
        if sc == 429 or sc >= 500:
            time.sleep(2 * (i + 1)); continue
        return sc, d
    return sc, d

def search_issues(flt, per_page=100):
    out, page = [], 1
    while True:
        sc, d = req("POST", f"/v3/issues/_search?perPage={per_page}&page={page}", {"filter": flt})
        if sc != 200:
            raise RuntimeError(f"search failed {sc}: {str(d)[:300]}")
        out += d
        if len(d) < per_page:
            return out
        page += 1

def children_map(parent_key):
    """имя (lower/strip) → issue среди детей parent_key"""
    issues = search_issues({"parent": parent_key})
    return {(i.get("summary") or "").strip().lower(): i for i in issues}, issues

def ensure_checklist(key, items, cfg, log):
    if not items:
        return []
    sc, existing = req("GET", f"/v3/issues/{key}/checklistItems")
    have = set()
    if sc == 200:
        have = {(it.get("text") or "").strip().lower() for it in existing}
    added = []
    for text in items:
        t = text.strip()
        if t.lower() in have:
            continue
        if cfg.get("dry_run"):
            log(f"    [dry] +пункт чеклиста {key}: {t[:60]!r}"); added.append(t); continue
        sc, d = req("POST", f"/v3/issues/{key}/checklistItems", {"text": t})
        if sc not in (200, 201):
            raise RuntimeError(f"checklist item failed {sc} {key}: {str(d)[:200]}")
        have.add(t.lower()); added.append(t)
        time.sleep(0.1)
    return added

def create_issue(summary, queue_key, type_key, parent=None, tags=None, cfg=None):
    body = {"summary": summary, "queue": queue_key, "type": type_key}
    if parent: body["parent"] = parent
    if tags: body["tags"] = tags
    if cfg.get("assignee"): body["assignee"] = cfg["assignee"]
    if cfg.get("project"): body["project"] = cfg["project"]  # {"primary": shortId} — не используем (решение: проект не указан)
    notify = "false" if cfg.get("notify", False) is False else "true"
    sc, d = req("POST", f"/v3/issues?notify={notify}", body)
    if sc not in (200, 201):
        raise RuntimeError(f"create failed {sc} {summary!r}: {str(d)[:300]}")
    time.sleep(0.15)
    return d

def sync_tags(key, want_tags, have_tags, log):
    missing = [t for t in want_tags if t.lower() not in {x.lower() for x in have_tags}]
    if not missing:
        return False
    sc, d = req("PATCH", f"/v3/issues/{key}", {"tags": (have_tags or []) + missing})
    if sc != 200:
        sc, d = req("PUT", f"/v2/issues/{key}", {"tags": (have_tags or []) + missing})
    log(f"    +теги {key}: {missing} -> {sc}")
    return sc == 200

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--structure", default="structure.json")
    ap.add_argument("--config", required=True)
    ap.add_argument("--report", default=None)
    a = ap.parse_args()
    cfg = json.load(open(a.config))
    st = json.load(open(a.structure))
    qm = cfg["queue_map"]
    epic_q = cfg.get("epic_queue") or qm[st["epic"]["queue"]]
    created, found = [], []
    def log(msg): print(msg, flush=True)

    # --- Эпик ---
    ename = st["epic"]["name"]
    epic = None
    if cfg.get("epic_key"):  # явный целевой эпик (слияние в существующий, напр. STDYMNG-930)
        sc, e = req("GET", f"/v3/issues/{cfg['epic_key']}")
        if sc != 200:
            raise RuntimeError(f"epic_key {cfg['epic_key']} не найден: {sc}")
        epic = e; log(f"= эпик задан конфигом: {epic['key']} ({epic.get('summary')!r})")
        found.append(("epic", ename, epic["key"]))
    elif cfg.get("force_new_epic"):  # создать НОВЫЙ, не сливаясь с одноимёнными чужими
        if cfg.get("dry_run"):
            log(f"= [dry] создать НОВЫЙ эпик {ename!r} в {epic_q}"); epic = {"key": f"DRY-EPIC({ename})"}
        else:
            epic = create_issue(ename, epic_q, "epic", cfg=cfg)
            log(f"= эпик создан (force_new): {epic['key']}"); created.append(("epic", ename, epic["key"]))
    if epic is None:
        cands = search_issues({"queue": epic_q, "type": ["epic"], "summary": ename})
        epic = next((c for c in cands if (c.get("summary") or "").strip() == ename), None)
    if epic:
        if ("epic", ename, epic["key"]) not in found:
            log(f"= эпик найден: {epic['key']}"); found.append(("epic", ename, epic["key"]))
    else:
        if cfg.get("dry_run"):
            log(f"= [dry] создать эпик {ename!r} в {epic_q}"); epic = {"key": f"DRY-EPIC({ename})"}
        else:
            epic = create_issue(ename, epic_q, "epic", cfg=cfg)
            log(f"= эпик создан: {epic['key']}"); created.append(("epic", ename, epic["key"]))
    report = {"epic": {"name": ename, "key": epic["key"]}, "tasks": []}

    echildren, _ = (None, None) if cfg.get("dry_run") else children_map(epic["key"])

    # --- Задачи ---
    for t in st["tasks"]:
        tq = qm[t["queue"]]
        existing = None if cfg.get("dry_run") else echildren.get(t["name"].strip().lower())
        if existing:
            log(f"- задача есть: {existing['key']} {t['name']!r}")
            found.append(("task", t["name"], existing["key"]))
            sync_tags(existing["key"], t.get("tags", []), existing.get("tags") or [], log)
            tkey = existing["key"]
            trep = {"name": t["name"], "key": tkey, "subtasks": []}
        else:
            if cfg.get("dry_run"):
                log(f"- [dry] создать задачу {t['name']!r} в {tq} (теги {t.get('tags')}) под {epic['key']}")
                tkey, trep = f"DRY-TASK({t['name']})", {"name": t["name"], "key": None, "subtasks": []}
            else:
                iss = create_issue(t["name"], tq, "task", parent=epic["key"], tags=t.get("tags") or None, cfg=cfg)
                log(f"- задача создана: {iss['key']} {t['name']!r} q={tq} tags={t.get('tags')}")
                created.append(("task", t["name"], iss["key"]))
                tkey = iss["key"]
                trep = {"name": t["name"], "key": tkey, "subtasks": []}
        # чеклист самой задачи (Unblinding setup)
        added = ensure_checklist(tkey, t.get("checklist", []), cfg, log)
        if added: trep["taskChecklistAdded"] = added

        tchildren, _ = (None, None) if cfg.get("dry_run") else children_map(tkey)
        # --- Подзадачи ---
        for s in t["subtasks"]:
            sq = qm[s["queue"]]
            sex = None if cfg.get("dry_run") else tchildren.get(s["name"].strip().lower())
            if sex:
                log(f"  * подзадача есть: {sex['key']} {s['name']!r}")
                found.append(("subtask", s["name"], sex["key"])); skey = sex["key"]
            else:
                if cfg.get("dry_run"):
                    log(f"  * [dry] создать подзадачу {s['name']!r} в {sq} под {tkey}")
                    skey = f"DRY-SUB({s['name']})"
                else:
                    iss = create_issue(s["name"], sq, "task", parent=tkey, cfg=cfg)
                    log(f"  * подзадача создана: {iss['key']} {s['name']!r} q={sq}")
                    created.append(("subtask", s["name"], iss["key"])); skey = iss["key"]
            added = ensure_checklist(skey, s.get("checklist", []), cfg, log)
            trep["subtasks"].append({"name": s["name"], "key": skey if not str(skey).startswith("DRY") else None,
                                     "checklistAdded": added})
        report["tasks"].append(trep)

    log(f"\nИТОГО: создано {len(created)}, найдено существующих {len(found)}, dry_run={cfg.get('dry_run', False)}")
    report["created"] = created; report["found"] = found
    if a.report and not cfg.get("dry_run"):
        json.dump(report, open(a.report, "w"), ensure_ascii=False, indent=1)
        log("report saved: " + a.report)

if __name__ == "__main__":
    main()
