"""Парсер листа Setup из Project plan 2.0.xlsx → structure.json (TRACKERSUPPORT-1674)."""
import json
import openpyxl
from collections import OrderedDict

XLSX = "project_plan_2.0.xlsx"
OUT = "structure.json"

wb = openpyxl.load_workbook(XLSX)
ws = wb["Setup"]

def color_key(c):
    col = c.font.color
    if col is None:
        return None
    if col.type == "rgb" and isinstance(col.rgb, str):
        return col.rgb
    if col.type == "theme":
        return ("theme", col.theme, round(col.tint or 0, 3))
    return ("theme", col.theme, None)

# Легенда: цвет шрифта A4:A8 → имя очереди (функции)
legend = {color_key(ws.cell(row=r, column=1)): ws.cell(row=r, column=1).value for r in range(4, 9)}

def s(v):
    return str(v).strip() if v is not None else None

epic = None
tasks = OrderedDict()   # (task_id, name) -> task
for r in range(3, ws.max_row + 1):
    B, C, D, E, F, G, H, I, J, K, L = (ws.cell(row=r, column=col).value for col in range(2, 13))
    if not any([B, C, D, E, F, G, H, I, J, K]):
        continue
    if epic is None:
        epic = {"excelId": B, "name": s(C), "queue": s(D)}  # очередь эпика = D первой строки
    tkey = (E, s(F))
    task = tasks.get(tkey)
    if task is None:
        task = {"excelId": E, "name": s(F), "queue": s(D), "tags": [], "checklist": [], "subtasks": OrderedDict()}
        tasks[tkey] = task
    if s(G) and s(G) not in task["tags"]:
        task["tags"].append(s(G))
    if I is not None:
        stkey = (H, s(I))
        sub = task["subtasks"].get(stkey)
        if sub is None:
            sq = legend.get(color_key(ws.cell(row=r, column=9)))
            sub = {"excelId": H, "name": s(I), "queue": sq, "checklist": []}
            task["subtasks"][stkey] = sub
        if K is not None:
            sub["checklist"].append(s(K))
    elif K is not None:
        task["checklist"].append(s(K))  # чеклист напрямую на задаче (напр. Unblinding setup)

struct = {
    "source": {"file": XLSX, "sheet": "Setup"},
    "epic": epic,
    "tasks": [
        {**t, "subtasks": list(t["subtasks"].values())} for t in tasks.values()
    ],
}
# статистика/валидация
n_sub = sum(len(t["subtasks"]) for t in struct["tasks"])
n_cl = sum(len(t["checklist"]) for t in struct["tasks"]) + sum(
    len(st["checklist"]) for t in struct["tasks"] for st in t["subtasks"])
print(f"epic: {epic}")
print(f"tasks: {len(struct['tasks'])}, subtasks: {n_sub}, checklist items: {n_cl}")
for t in struct["tasks"]:
    bad = [st["name"] for st in t["subtasks"] if not st["queue"]]
    if bad:
        print(f"!! подзадачи без очереди (неизвестный цвет): {bad} в задаче {t['name']}")
json.dump(struct, open(OUT, "w"), ensure_ascii=False, indent=1)
print("saved", OUT)
