import json, sys, requests

ORG = "bpfb300ct6ef4t2kr3l1"
TOKEN = "y0__wgBEM-Q3bUIGPqsOiCu_fCDGTC40-KCCCHhEvRf0CXapaUvgQWDYH-0p-L0"
BASE = "https://api.tracker.yandex.net"
H = {"Authorization": f"OAuth {TOKEN}", "Content-Type": "application/json", "X-Cloud-Org-Id": ORG}

def call(method, path, body=None, params=None, base=None, full=False):
    url = path if path.startswith("http") else (base or BASE) + path
    r = requests.request(method, url, headers=H, json=body, params=params, timeout=60)
    ct = r.headers.get("Content-Type", "")
    if "json" in ct:
        data = r.json()
    else:
        data = r.text[:2000]
    return r.status_code, data

if __name__ == "__main__":
    # usage: python api.py METHOD /path ['json body']
    m = sys.argv[1]; p = sys.argv[2]
    b = json.loads(sys.argv[3]) if len(sys.argv) > 3 else None
    sc, d = call(m, p, b)
    print(sc)
    print(json.dumps(d, ensure_ascii=False, indent=1)[:6000])
