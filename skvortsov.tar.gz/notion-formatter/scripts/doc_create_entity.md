---
metadata:
  - name: generator
    content: Diplodoc Platform v5.63.2
  - property: og:type
    content: article
  - property: article:section
    content: Справочник API
  - property: og:title
    content: Создать сущность
  - property: article:tag
    content: Техническая инструкция
alternate:
  - https://yandex.ru/support/tracker/en/api/entities/create-entity.md
  - https://yandex.ru/support/tracker/ru/api/entities/create-entity.md
  - href: https://yandex.ru/support/tracker/ru/api/entities/create-entity.md
    type: text/markdown
    title: Markdown version
  - href: https://yandex.ru/support/tracker/ru/llms.txt?revision=r21584721
    rel: describedby
---
> **Documentation Index:** Fetch the complete configuration index at https://yandex.ru/support/tracker/ru/llms.txt?revision=r21584721


# Создать сущность

Запрос позволяет создать новую сущность — [цель](*goal), [проект](*project) или [портфель проектов](*portfolio).

<div class="request_example yfm-code-floating-container method_post">
    <p>POST</p>
    <pre><code>https://api.tracker.yandex.net/v3/entities/{тип_сущности}</code></pre>
    <button class="yfm-clipboard-button"><svg width="16" height="16" viewBox="0 0 24 24" class="yfm-clipboard-icon" data-animation="15">
    <path fill="currentColor" d="M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z"></path>
    <path stroke="currentColor" fill="transparent" strokewidth="1.5" d="M9.5 13l3 3l5 -5" visibility="hidden">
        <animate id="visibileAnimation-15" attributeName="visibility" from="hidden" to="visible" dur="0.2s" fill="freeze" begin=""></animate>
        <animate id="hideAnimation-15" attributeName="visibility" from="visible" to="hidden" dur="1s" begin="visibileAnimation-15.end+1" fill="freeze"></animate>
    </path>
</svg>
</button>
</div>

<!-- source: ru/api/_assets/style/methods.md -->

<!-- endsource: ru/api/_assets/style/methods.md -->

## Формат запроса {#query}

Перед выполнением запроса [получите доступ к API](https://yandex.ru/support/tracker/ru/api/access.md).

Чтобы создать новую сущность, используйте HTTP-запрос с методом `POST`. В теле запроса укажите параметры в формате JSON.

```json translate=no
POST /v3/entities/{тип_сущности}
Host: api.tracker.yandex.net
Authorization: OAuth API_TOKEN
Content-Type: application/json
X-Org-ID или X-Cloud-Org-ID: ИДЕНТИФИКАТОР_ОРГАНИЗАЦИИ

{
   "fields": {
      "summary": "НАЗВАНИЕ",
      "lead": "username",
      "end": "2025-12-01"
      ...
   }
}
```

<!-- source: ru/api/_includes/headings.md -->
{% cut "Заголовки" %}

* `Host`: адрес узла, предоставляющего API.

* <!-- source: ru/api/_includes/authorization.md -->
  `Authorization`: токен для авторизации в одном из форматов:

    - `OAuth OAUTH_TOKEN` при авторизации по протоколу OAuth 2.0. [Читать подробнее](https://yandex.ru/support/tracker/ru/api/access.md#about_OAuth)

    - `Bearer IAM_TOKEN` при авторизации с помощью IAM-токена — если к Трекеру привязана организация Yandex Identity Hub. [Читать подробнее](https://yandex.ru/support/tracker/ru/api/access.md#iam-token)
  <!-- endsource: ru/api/_includes/authorization.md -->

* <!-- source: ru/api/_includes/content-type-json.md -->
  `Content-Type`: формат тела запроса. Должен иметь значение `application/json`.
  <!-- endsource: ru/api/_includes/content-type-json.md -->


* <!-- source: ru/api/_includes/org-id.md -->
  `X-Org-ID` или `X-Cloud-Org-ID`: идентификатор организации.

  - если к Трекеру привязана организация Яндекс 360 для бизнеса, используйте заголовок `X-Org-ID`,

  - если к Трекеру привязана организация Yandex Identity Hub, используйте заголовок `X-Cloud-Org-ID`.
  <!-- endsource: ru/api/_includes/org-id.md -->

  <!-- source: ru/api/_includes/org-id.md -->
  Чтобы узнать идентификатор организации, перейдите на страницу **Администрирование** → [**Организации**](https://tracker.yandex.ru/admin/orgs) и скопируйте значение поля **идентификатор**.
  <!-- endsource: ru/api/_includes/org-id.md -->


{% endcut %}
<!-- endsource: ru/api/_includes/headings.md -->

{% cut "Ресурс" %}

Параметр | Описание | Тип данных
-------- | -------- | ----------
`тип_сущности` | Тип сущности:<ul><li>project — проект;</li><li>portfolio — портфель;</li><li>goal — цель</li></ul>| Строка

{% endcut %}

{% cut "Параметры запроса" %}

**Дополнительные параметры**

Параметр | Описание | Тип данных
-------- | -------- | ----------
[fields](./about-entities.md#query-params) |  Дополнительные поля сущности, которые будут включены в ответ. | Строка

{% endcut %}

{% cut "Параметры тела запроса" %}

Тело запроса содержит информацию, необходимую для создания новой сущности:

**Обязательные параметры**

Параметр | Описание | Тип данных
-------- | -------- | ----------
fields | Объект с настройками сущности. Подробнее в разделе [Дополнительные параметры сущности](./about-entities.md#query-params) | Объект

**Поля объекта** `fields`

<!-- source: ru/api/_includes/entity-fields.md -->
#|
|| Параметр | Описание | Тип данных ||
|| summary | Название (обязательное поле) | Строка ||
|| teamAccess |
Настройки доступа:
* `true`— доступ только для участников проекта, портфеля или цели.
* `false` — доступ имеют другие пользователи, кроме участников проекта, портфеля или цели.

О настройке прав доступа для пользователей и групп см. в разделе [Изменить расширенные настройки доступа сущности](https://yandex.ru/support/tracker/ru/api/entities/patch-access.md).
| Логический ||
|| description | Описание | Строка ||
|| markupType | Тип отображаемой в тексте разметки. Если вы используете в тексте комментария или описания сущности [разметку YFM](https://yandex.ru/support/tracker/ru/user/syntax-yfm.md), укажите значение `md` | Строка ||
|| author | Автор (идентификатор пользователя) | Строка ||
|| lead | Ответственный (идентификатор пользователя) | Строка ||
|| teamUsers | Участники (массив идентификаторов пользователей) | Массив строк ||
|| clients | Заказчики (массив идентификаторов пользователей) | Массив строк ||
|| followers | Наблюдатели (массив идентификаторов пользователей) | Массив строк ||
|| start | Дата начала в формате `YYYY-MM-DDThh:mm:ss.sss±hhmm` | Дата ||
|| end | Дедлайн в формате `YYYY-MM-DDThh:mm:ss.sss±hhmm` | Дата ||
|| tags | Теги | Массив строк ||
|| [parentEntity](#parent) | Данные о родительских сущностях. Для проекта и портфеля — поле «Входит в портфель» | Объект ||
|| entityStatus |
Статус.

{% cut "Допустимые значения статуса" %}

<!-- source: ru/api/_includes/entity-status.md -->
Для проекта или портфеля:
* `draft` — Новый;
* `draft2` — Черновик;
* `in_progress` — В работе;
* `according_to_plan` — По плану;
* `postponed` — Отложен;
* `at_risk` — Есть риски;
* `blocked` — Заблокирован;
* `launched` — Завершен;
* `cancelled` — Отменен.

Для цели:
* `draft` — Новая;
* `according_to_plan` — По плану;
* `at_risk` — Есть риски;
* `blocked` — Заблокирована;
* `achieved` — Достигнута;
* `partially_achieved` — Частично достигнута;
* `not_achieved` — Не достигнута;
* `exceeded` — Превышена;
* `cancelled` — Отменена.
<!-- endsource: ru/api/_includes/entity-status.md -->

{% endcut %}
| Строка ||
|#
<!-- endsource: ru/api/_includes/entity-fields.md -->

**Поля объекта** `parentEntity` {#parent}

<!-- source: ru/api/_includes/entity-fields.md -->
Параметр | Описание | Тип данных
-------- | -------- | ----------
primary | Идентификатор основного портфеля (для проектов и портфелей) или родительской цели (для целей) | Строка
secondary | Для проектов и портфелей — идентификаторы дополнительных портфелей<br>Для целей параметр `secondary` не поддерживается | Массив строк
<!-- endsource: ru/api/_includes/entity-fields.md -->

<!-- source: ru/api/_includes/entity-fields.md -->
{% note info "" %}

Если в адресе запроса указана версия API `v2`, параметр `parentEntity` может содержать только идентификатор основной родительской сущности.

Например: `"parentEntity": "66e2fa183*****"`

{% endnote %}
<!-- endsource: ru/api/_includes/entity-fields.md -->

**Дополнительные параметры**

Параметр | Описание | Тип данных
-------- | -------- | ----------
links | Массив объектов с настройками связей с другими сущностями. | Массив объектов

**Поля объектов массива** `links`

#|
|| Параметр | Описание | Тип данных ||
|| relationship |
{% include [links](../_includes/entity-links.md) %} |
Строка
||
|| entity | Идентификатор связанной сущности. | Строка ||
|#


{% endcut %}

> Пример: Создать проект
>
> - Используется HTTP-метод POST.
> - Создается проект с названием «Test Project».
> - Проект связан с целью с идентификатором `1234`.
>
> ```json translate=no
> POST /v3/entities/project/ HTTP/1.1
> Host: api.tracker.yandex.net
> Authorization: OAuth API_TOKEN
> Content-Type: application/json
> X-Org-ID: 1234******
>
> {
>     "fields": {
>        "summary":"Test Project"
>     },
>    "links": [
>      {
>        "relationship": "works towards",
>        "entity": 1234
>      }
>    ]
> }
> ```

## Формат ответа {#answer}

{% list tabs %}

- Запрос выполнен успешно

   <!-- source: ru/api/_includes/answer-201.md -->
   В случае успешного выполнения запроса API возвращает ответ с кодом `201 Created`.
   <!-- endsource: ru/api/_includes/answer-201.md -->

   Тело ответа содержит информацию о созданной сущности в формате JSON.
    ```json translate=no
   {
       "self": "https://api.tracker.yandex.net/v3/entities/project/655f3be523db2132********",
       "id": "655f3be523db2132********",
       "version": 1,
       "shortId": 6,
       "entityType": "project",
       "createdBy": {
           "self": "https://api.tracker.yandex.net/v3/users/11********",
           "id": "11********",
           "display": "Имя Фамилия",
           "cloudUid": "ajevuhegoggfk*******",
           "passportUid": 11********
       },
       "createdAt": "2023-11-23T11:47:49.743+0000",
       "updatedAt": "2023-11-23T11:47:49.743+0000"
   }
   ```

   {% cut "Параметры ответа" %}

   <!-- source: ru/api/_includes/entity.md -->
   Параметр | Описание | Тип данных
   -------- | -------- | ----------
   self | Адрес ресурса API, который содержит информацию о сущности | Строка
   id | Идентификатор сущности | Строка
   version | Версия сущности. Каждое изменение параметров увеличивает номер версии. <br>Редактирование сущности будет заблокировано, если версия достигнет предельного значения: для роботов `10100`, для пользователей `11100` | Число
   shortId | Числовой идентификатор сущности | Число
   entityType | Тип сущности | Строка
   createdBy | Блок с информацией о создателе сущности | Объект
   createdAt | Дата создания сущности в формате `YYYY-MM-DDThh:mm:ss.sss±hhmm` | Строка
   updatedAt | Дата последнего обновления сущности в формате `YYYY-MM-DDThh:mm:ss.sss±hhmm` | Строка
   [fields](about-entities.md#query-params) | Блок с дополнительными полями сущности | Объект
   <!-- endsource: ru/api/_includes/entity.md -->

   **Поля объекта** `createdBy`

   <!-- source: ru/api/_includes/user.md -->
   Параметр | Описание | Тип данных
   ----- | ----- | -----
   self | Адрес ресурса API, который содержит информацию о пользователе. | Строка
   id | Идентификатор пользователя. | Строка
   display | Отображаемое имя пользователя. | Строка
   passportUid | Уникальный идентификатор аккаунта пользователя в организации Яндекс 360 для бизнеса и Яндекс ID. | Число
   cloudUid | Уникальный идентификатор пользователя в Yandex Identity Hub. | Строка
   <!-- endsource: ru/api/_includes/user.md -->

   {% endcut %}

- Запрос выполнен с ошибкой

    Если запрос не был успешно обработан, API возвращает ответ с кодом ошибки:

    <!-- source: ru/api/_includes/answer-error-400.md -->
    400
    :   Один или несколько параметров запроса имеют недопустимое значение.
    <!-- endsource: ru/api/_includes/answer-error-400.md -->

    <!-- source: ru/api/_includes/answer-error-401.md -->
    401
    :   Пользователь не авторизован. Проверьте, были ли выполнены действия, описанные в разделе [Доступ к API](https://yandex.ru/support/tracker/ru/api/access.md).
    <!-- endsource: ru/api/_includes/answer-error-401.md -->

    <!-- source: ru/api/_includes/answer-error-403.md -->
    403
    :   У вас не хватает прав на выполнение этого действия. Наличие прав можно перепроверить в интерфейсе Трекера — для выполнения действия при помощи API и через интерфейс требуются одинаковые права.
    <!-- endsource: ru/api/_includes/answer-error-403.md -->

    <!-- source: ru/api/_includes/answer-error-404.md -->
    404
    :   Запрошенный объект не был найден. Возможно, вы указали неверное значение идентификатора или ключа объекта.
    <!-- endsource: ru/api/_includes/answer-error-404.md -->

    <!-- source: ru/api/_includes/answer-error-409.md -->
    409
    :   При редактировании объекта возник конфликт. Возможно, ошибка возникла из-за неправильно указанной версии изменений.
    <!-- endsource: ru/api/_includes/answer-error-409.md -->

{% endlist %}

[*portfolio]: Портфель — это инструмент для объединения проектов и других портфелей по продукту, отделу или другому признаку.

Когда у вас несколько параллельных проектов, портфель позволяет взглянуть на них с высоты: как распределены ресурсы, где сроки подходят к концу.

[*project]: Проект — это набор задач из разных очередей, в которых работают над общим результатом. Это может быть запуск мобильного приложения или редизайн главной страницы сайта.

Проект помогает отслеживать: сколько задач сделано, сколько осталось, укладывается ли команда в сроки.

[*goal]: Цель — это стратегия развития или желаемый итог работы команды. Прогресс цели оценивают в количественных показателях. К цели можно привязать проекты, портфели и задачи, чтобы видеть, какая работа ведется для ее достижения.
{% included (../_includes/entity-links.md) %}
Тип связи. Для проектов и портфелей:
* `depends on` — текущая сущность зависит от связанной
* `is dependent by` — текущая сущность блокирует связанную
* `works towards` — связь проекта с целью

Для цели:
* `parent entity` — родительская цель
* `child entity` — подцель
* `depends on` — текущая цель зависит от связанной
* `is dependent by` — текущая цель блокирует связанную
* `is supported by` — связь с проектом

{% endincluded %}