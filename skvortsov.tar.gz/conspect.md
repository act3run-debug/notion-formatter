# conspect.md — TRACKERSUPPORT-1674

## 1. Задача
TRACKERSUPPORT-1674 (id 6ab3e6622e5f8b5354cd9bc0, статус «На паузе», pendingReplyFrom 903, проект «Общие задачи PMO D&D» id 90, доска 214). Заявитель — Evgenii Skvortsov (uid 8000000000000470, он же lead очередей STDYMNG/CLNNSFTY/ALLNC).
Требование (улучшение): по Excel-файлу «Project plan 2.0.xlsx» (вложение 40417 задачи) создать **проект** со структурой: Эпик → Задача (очередь из D, тег из G) → Подзадача (очередь по цвету шрифта в I) → Чеклист-пункты (K). Чеклисты — только названия (без исполнителей/дедлайнов). Использовать ТОЛЬКО лист «Setup». Обязательна **итеративность**: повторная загрузка в проект, где уже есть эпики/задачи/подзадачи, не должна дублировать.

### Комментарий-уточнение от Скворцова (122597, 2026-10-07):
- Чеклисты: только название пункта; исполнителя/дедлайн заполнят участники позже.
- Пример строк 3–15: эпик "Study Setup" → задача "Central Trial documents" (очередь STUDY MANAGEMENT, тег "Study Team") → подзадача "Clinical Study Protocol (CSP)" (очередь STUDY MANAGEMENT **согласно цветовой легенде в столбце I**) → чеклист 13 пунктов.
- Только лист «Setup», остальные листы (Planning, Conduct, Study closure) игнорировать.

## 2. Текущая конфигурация
- Excel: /home/user/scripts/project_plan_2.0.xlsx (скачан через GET /v3/issues/TRACKERSUPPORT-1674/attachments/40417/... с OAuth; forms.yandex.ru/cloud/files без авторизации отдаёт HTML-логин).
- Лист Setup: заголовок в строке 2: B=Эпик ID, C=Эпик, D=Очередь(задачи), E=Задача ID, F=Задача, G=Тег 1, H=Подзадача ID, I=Подзадача, J=Чеклист ID, K=Чеклист-пункт, L=Owner (пуст). A3:A8 — легенда цветов шрифта. Данные: строки 3–202 (203 строки с данными, из них 6 строк чеклиста без подзадачи — строки 197-202 для задачи "Unblinding setup"? см. находки).
- Структура: 1 эпик (B=2, "Study Setup"); 11 задач; 70 подзадач (после trim-слияния "IP Import "/"IP Import"); чеклисты у ~40 подзадач + 3 пункта напрямую у задачи "Unblinding setup" (H/I пустые, J/K заполнены).
- Очереди (name→key): STUDY MANAGEMENT→STDYMNG(18), CLINICAL and SAFETY→CLNNSFTY(19), ALLIANCE→ALLNC(20), BIOMETRICS→BIMTRCS(21), QUALITY→QLTY(39, в листе не используется). PREREGLOCALPROC(75)="PreReg Local Processes", lead Kirill Andropov.
- Типы задач: epic=6, task=2 (есть во всех очередях). defaultType: STDYMNG/CLNNSFTY/BIMTRCS/QLTY=epic, ALLNC/NEWTASKS=task.
- Тестовая очередь: NEWTASKS (id 17). Удаление = POST /issues/{key}/_move?queue=DELETE&initialStatus=true&notify=false.
- Тестовый исполнитель: az.kirill.andropov (uid 8000000000000904). Тестовые проекты: 2785 «Тест Трекера 1» (6ab52829dc555b391e385f19), 2786 «Тест Трекера 2».

## 3. План
- [x] Прочитать TRACKERSUPPORT-1674 + комментарии + вложение
- [x] Распарсить лист Setup (эпики/задачи/теги/подзадачи/чеклисты/цвета-очереди)
- [x] Найти очереди по именам (STDYMNG и т.д.)
- [ ] Прочитать доку API: создание проекта (v3/projects), создание задач с parent/project/tags, checklistItems
- [ ] Проверить триггеры/автодействия NEWTASKS и 4 целевых очередей (правило из context.md!)
- [ ] Скрипт-парсер Excel → JSON-структура
- [ ] Скрипт-импортёр (идемпотентный: поиск существующих по имени+родителю)
- [ ] ТЕСТ в NEWTASKS: тестовый проект, эпик/задачи/подзадачи/чеклисты/теги, повторный прогон (итеративность), проверка связей
- [ ] Убрать тестовый мусор (в DELETE)
- [ ] Вопросы пользователю: имя/lead целевого проекта; очередь эпика; исполнители; запускать ли в целевых очередях сейчас
- [ ] Боевой прогон (после подтверждения), отчёт, notify-tracker

## 4. Журнал (агент Qwen, 2026-10-10)
- Прочитал context.md + инструкции conspect. Создал conspect.md.
- Установил requests+openpyxl (pip НЕ сохраняется между сессиями — переустановить!). Скрипт-хелпер /home/user/scripts/api.py (call(method,path,body) → (status,json)).
- GET задачи + комментариев: требование и уточнения Скворцова (см. раздел 1).
- Скачал xlsx из вложения 40417 (через Tracker API с OAuth).
- Распарсил Setup: 203 строки данных, 1 эпик, 11 задач, 70 подзадач; цвета шрифта I = очередь подзадачи (theme4+tint0.4=STUDY MANAGEMENT, FFC00000=CLINICAL and SAFETY, theme8-0.25=BIOMETRICS, FF00B050=ALLIANCE, theme5=QUALITY). Все 197 цветных строк распознаны, unknown=0.
- GET /v3/queues/{ключ имени} → 404: в D стоят ИМЕНА очередей, не ключи. Список 127 очередей (поле name, не display!) → маппинг в разделе 2.
- Проверил триггеры/автодействия всех очередей (см. раздел 5). Прочитал доки API (create-issue, create-entity, add-checklist-item).
- Написал parse_setup.py → structure.json: 1 эпик (Study Setup, STDYMNG), 11 задач, 69 подзадач (после trim-слияния "IP Import"), 175 чеклист-пунктов (169 в подзадачах + 6 на задаче "Unblinding setup" строки 200–205).
- Написал import_structure.py (идемпотентный импортёр, dry_run, отчёт). Первый dry-run ЗАВИС: _search без обёртки {"filter":...} игнорирует условия и пагинирует всю организацию → исправил (v3 _search требует {"filter": flt}).
- **НАХОДКА 1:** в NEWTASKS уже есть тест прошлой сессии (2026-10-09, автор Kirill Andropov): эпик NEWTASKS-861 "Study Setup" с 11 задачами из Excel + "NEW Iterative Task" (NEWTASKS-942) — видимо, тест итеративности; и пустой эпик NEWTASKS-680 "Study Setup" (2026-10-06). Будет убрано в DELETE перед моим тестом.
- **НАХОДКА 2 (критично для боевого прогона):** в ЦЕЛЕВЫХ очередях уже есть ДВА реальных эпика "Study Setup": STDYMNG-910 (автор/исп. Natalia Baturina, 2026-06-09, status new, 21 ребёнок) и STDYMNG-930 (автор/исп. Tatiana Belikova, 2026-06-24, status inProgress, 24 ребёнка, вкл. BIMTRCS-1793 'Data Management Setup' 19 детей, BIMTRCS-1794 'Analysis & Reporting Setup' 4 ребёнка). Это РУЧНЫЕ структуры реальных людей, имена похожи на Excel, но НЕ совпадают точно (напр. 'Data Management Plan v1' vs excel 'Data Mangement Plan v1'; пункты чеклистов оформлены подзадачами; 'Regulatory ' с пробелом). Сливание Excel-2.0 в них по имени = трогать чужие задачи и получить мешанину. → ВОПРОС пользователю перед боевым прогоном (см. раздел 6).
- Убрал мусор прошлой сессии: дерево NEWTASKS-861 (83 задачи, вкл. 11 задач Excel + подзадачи + "NEW Iterative Task" 942) + пустой эпик NEWTASKS-680 + 16 «беспризорных» задач NEWTASKS-666..684 (тесты 2026-10-06, родители уже в DELETE) — ВСЕ перенесены в DELETE (100/100, маппинги: cleanup_prev_session.json, cleanup_stray.json). NEWTASKS чиста от структур этой задачи.
- Тест в NEWTASKS — **УСПЕШНО** (config: всё→NEWTASKS, epic_queue NEWTASKS, notify=false, без assignee):
  - Прогон 1 (после 2 падений на баге tkey — исправлен): создано 77 + найдено 4 (эпик NEWTASKS-947, задача 948, подзадачи 949/950 из оборванного прогона) = 81 задача (1 эпик+11 задач+69 подзадач). Чеклисты: 162 добавлено в этом прогоне + 13 (CSP) в оборванном = 175; **дедупликация между прогонами сработала** (в NEWTASKS-949 ровно 13, не 26).
  - Верификация: NEWTASKS-949 CSP чеклист=13 ✓, NEWTASKS-1027 Unblinding чеклист=6 ✓ (на самой задаче), детей у эпика=11 ✓, теги (Study Team/Country Operations/Supporting roles) ✓, типы epic/task ✓, parent ✓. Отчёт: test_report.json.
  - Прогон 2 (идемпотентность): **создано 0, найдено 81, чеклистов добавлено 0** (67 с). Отчёт: test_rerun_report.json.
  - Прогон 3 (итеративность, structure_iter.json = +задача "Site Monitoring (NEW)", +подзадача "CSP Addendum NEW" в существующую задачу, +1 пункт в существующий чеклист CSP): **создано ровно 3** (NEWTASKS-1029/1028/1030), найдено 81, чеклистов +4; CSP стал 14 пунктов, у эпика 12 детей. Отчёт: iter_report.json.
  - Восстановление после обрыва сессии работает (идемпотентный поиск продолжает с места обрыва).
- Уборка теста: (заполню).

## 5. Находки API
- GET /v3/queues возвращает поле `name` (не `display`); в списке `display=None`.
- forms.yandex.ru/cloud/files?path=... без авторизации → HTML (200) — качать вложения через Tracker API `/v3/issues/{key}/attachments/{id}/{filename}` с OAuth-заголовками.
- В списке очередей 127 шт., нужные существуют.
- (проверено ранее в context.md) удаление задач только через _move в DELETE.
- **Триггеры/автодействия (проверено 2026-10-10):**
  - NEWTASKS: T136 «Копирование приоритетов №2» (active) — на Event.comment-create создаёт подзадачу «Тестовая подзадача» → **не комментировать тестовые задачи в NEWTASKS**. T524/525/526 (active) — на clarifyingThePriority (не трогаем). T81/129/138/196/197/280 — неактивны. Автодействие 2 — неактивно.
  - STDYMNG, CLNNSFTY, BIMTRCS: триггеров/автодействий НЕТ.
  - ALLNC: T514 (active) Event.create → Transition в статус «Новый» (безвредно).
- API создания: задача `POST /v3/issues` {summary, queue, type, parent, tags[], project:{primary:shortId}, assignee, unique}; проект `POST /v3/entities/project` {"fields":{summary, lead, description,...}}; пункт чеклиста `POST /v3/issues/{key}/checklistItems` {"text": ...} (по одному); чтение чеклиста `GET /v3/issues/{key}/checklistItems`. Поиск `POST /v3/issues/_search` (summary — точное совпадение; parent — по родителю).
- Доки скачаны локально: scripts/doc_create_entity.md, doc_add_checklist_item.md, doc_llms.txt (индекс всех страниц API).

## 6. Решения и открытые вопросы
Решения:
- **Проект НЕ указываем** — пользователь (2026-10-10): «excel содержит исчерпывающую информацию; если проект не указан — его не нужно указывать». В Excel имени проекта нет (проверил все 4 листа). Задачи создаются без поля project.
- **Исполнитель не назначается** — столбец L (Owner) пуст во всех строках; Скворцов: аллокация позже.
- **Очередь эпика "Study Setup" = STDYMNG** (STUDY MANAGEMENT): D первой строки эпика (строка 3), defaultType очереди — epic, lead — Скворцов. В скрипте параметр конфигурации.
- Только лист Setup (комментарий Скворцова). Листы Planning (эпик 1), Conduct (эпик 3), Study closure — не используем сейчас.
- Очередь подзадачи — из цвета шрифта I (легенда A4:A8), не из D.
- Ключ идемпотентности — (имя + родитель); Excel-ID только для порядка. Trim имён обязателен ("IP Import "/"IP Import" → один).
- Чеклист-пункты без подзадачи (H/I пусто, J/K есть) — на саму задачу.
- Теги из G — как есть (теги в Трекере свободные, создаются автоматически).
Открытые вопросы (задать ПЕРЕД боевым прогоном):
1. **Целевой эпик для боевого импорта**: (A) создать НОВЫЙ эпик "Study Setup" в STDYMNG с чистой структурой Excel 2.0 (будет 3-й одноимённый); (B) слить в STDYMNG-930 (Belikova, inProgress — ближе всего к Excel); (C) слить в STDYMNG-910 (Baturina); (D) спросить Скворцова комментарием в TRACKERSUPPORT-1674. Без ответа боевой прогон НЕ делать (риск задеть задачи реальных людей).

## 7. Тестовые артефакты и уборка
(пока ничего не создано)

## 8. Для следующего агента
- Сессия: Qwen, 2026-10-10. Остановились: Excel распарсен, очереди найдены. ДАЛЬШЕ: (1) pip install requests openpyxl; (2) прочитать доку: llms.txt https://yandex.ru/support/tracker/ru/llms.txt → страницы про создание проектов (v3 /projects), checklist items, создание задач с parent/tags/project; (3) проверить триггеры NEWTASKS + STDYMNG/CLNNSFTY/ALLNC/BIMTRCS (GET /v3/triggers?queue=...) перед созданием задач; (4) написать parse_setup.py → structure.json и import_structure.py (dry-run режим обязателен); (5) тест в NEWTASKS.
- Скрипты: /home/user/scripts/api.py (хелпер), project_plan_2.0.xlsx (Excel).
- Парсер уже написан инлайн в журнальных bash-вызовах — логику цвета/легенды см. раздел 5 и журнал; переписать в parse_setup.py.
- Секреты: OAuth-токен в api.py (из context.md, не временный). IAM не нужен (всё через Tracker REST).
