/**
 * Background Script for Local LLM Translator
 * Handles LLM API calls, settings storage, and message routing
 */

// Use browser API with chrome fallback
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

// Import languages (for Service Worker context)
if (typeof importScripts === 'function') {
    importScripts('languages.js', 'cache.js');
}

// ============================================================================
// Settings & Constants
// ============================================================================

// Bumped whenever the defaults below change in a way that should reach people
// who already have settings saved. loadSettings() then re-applies the defaults
// and keeps only the fields listed in PRESERVED_ACROSS_DEFAULTS.
const SETTINGS_VERSION = 2;

// Machine- and taste-specific values survive a defaults bump; everything else is
// reset, so a new build comes up configured instead of inheriting stale tuning.
const PRESERVED_ACROSS_DEFAULTS = [
    'selectedModel', 'ollamaUrl', 'lmstudioUrl',
    'pinnedLanguages', 'pinnedModels', 'customPrompts',
    'rewriteInstructions', 'autoTranslateNeverLanguages', 'autoTranslateNeverSites'
];

const DEFAULT_SETTINGS = {
    settingsVersion: SETTINGS_VERSION,
    provider: 'lmstudio', // 'lmstudio' = any OpenAI-compatible /v1 endpoint
    ollamaUrl: 'http://localhost:11434',
    lmstudioUrl: 'http://127.0.0.1:8080',
    selectedModel: '',
    targetLanguage: 'ru',
    sourceLanguage: 'auto', // 'auto' = detect from page, or specific code
    maxTokensPerBatch: 2000,   // unused: batch size is set by maxItemsPerBatch
    maxItemsPerBatch: 4,       // blocks per request; rewrite answers are long
    maxConcurrentRequests: 1,  // one local model serves requests serially anyway
    // Per-format prompt overrides: { [format]: { system, user } }. A format with
    // no entry here falls back to its built-in PROMPT_TEMPLATES text. There's no
    // 'auto' entry — auto resolves to a concrete format first, and that format's
    // (possibly overridden) prompt is what's actually used.
    customPrompts: {},
    requestFormat: 'auto', // 'auto' (detect from model), 'default', 'translategemma', 'hunyuan', 'simple', 'custom'
    // 'translate' = faithful translation (original behaviour).
    // 'rewrite'   = the model rewrites each segment in plainer, more readable
    //               language instead of translating it. Splitting one sentence
    //               into several is explicitly allowed; merging segments is not,
    //               because every segment is mapped back onto its own DOM text
    //               node by id (see replaceTextNode in content.js).
    outputMode: 'rewrite',
    // Which rewrite template to use when outputMode is 'rewrite':
    // 'rewrite' (plainer wording), 'rewrite_explain' (for a beginner),
    // 'rewrite_detranslate' (fix text that reads like a machine translation).
    rewriteStyle: 'rewrite_detranslate',
    // Free-form rules appended to the rewrite system prompt verbatim: house style,
    // terminology to keep, sentence-length limits, what never to touch. Empty by
    // default, which leaves the built-in template unchanged.
    rewriteInstructions: '',
    // Rewrite whole blocks (paragraphs, list items, headings) instead of single
    // text nodes. Block mode is what makes paragraph-level rewriting and link
    // preservation possible; node mode is the old per-text-node behaviour.
    rewriteScope: 'block',
    // Keep each page's rewrite so returning to the URL restores it without
    // asking the model again. Independent of cacheMode, which covers the
    // per-string translation cache.
    persistRewrites: true,
    temperature: 0.6,          // rewriting needs more freedom than translating
    useStructuredOutput: true,
    maxOutputRetries: 2,    // Extra attempts when the model returns malformed/missing translations
    plainTextFallback: true, // After JSON retries fail, translate the failed items one-by-one as plain text
    showGlow: false,
    numCtx: 0,          // Ollama context window size (0 = model default)
    // Translation cache: 'persistent' (kept across browser sessions), 'session'
    // (kept until the browser is closed, then wiped), or 'off'. Off by default.
    cacheMode: 'off',
    debug: true,        // verbose logging: injection failures, rejected blocks, batch limits
    floatingButton: false, // Show floating translate button on text selection (requires <all_urls> permission)
    useGlossary: false,  // Off by default; when on, injects matching glossary terms into the prompt for consistent proper-noun translation
    // Translate a page as soon as it loads when it declares a language other
    // than the target one (requires <all_urls> permission). Off by default:
    // every page load costs real inference time on the user's own machine.
    autoTranslatePages: false,
    autoTranslateNeverLanguages: [], // language codes to leave alone
    autoTranslateNeverSites: []      // hostnames to leave alone (subdomains included)
};

let debugEnabled = false;
function debugLog(...args) { if (debugEnabled) console.log(...args); }
function debugWarn(...args) { if (debugEnabled) console.warn(...args); }

const PROMPT_TEMPLATES = {
    default: {
        system: `You are a professional translator. Translate the given texts to {{targetLanguage}}. 
Respond ONLY with a JSON object in this exact format:
{"translations": [{"id": 0, "text": "translated text"}, {"id": 1, "text": "another translation"}]}
Maintain the original meaning, tone, and formatting. Do not add explanations.`,
        user: `Translate the following texts to {{targetLanguage}}:\n{{texts}}`
    },
    translategemma: {
        // TranslateGemma EXACT format - do not modify
        system: '',
        user: `You are a professional {{sourceLang}} ({{sourceCode}}) to {{targetLang}} ({{targetCode}}) translator. Your goal is to accurately convey the meaning and nuances of the original {{sourceLang}} text while adhering to {{targetLang}} grammar, vocabulary, and cultural sensitivities.
Produce only the {{targetLang}} translation, without any additional explanations or commentary. Please translate the following {{sourceLang}} text into {{targetLang}}:


{{texts}}`
    },
    simple: {
        system: `You are a translator. Translate to {{targetLanguage}}. Output JSON only:
{"translations": [{"id": N, "text": "translation"}]}`,
        user: `Translate to {{targetLanguage}}:\n{{texts}}`
    },
    hunyuan: {
        system: '',
        user: `Translate the following segment into {{targetLanguage}}, without additional explanation.\n{{texts}}`
    }
};

// Prompt templates used when outputMode is 'rewrite' instead of 'translate'.
//
// They keep the exact same contract as the translation templates:
//   * input  — one `[id]: text` line per segment (see formatTextsForPrompt)
//   * output — {"translations": [{"id": N, "text": "..."}]}, one entry per input id
// so parseTranslationResponse(), the JSON schema and replaceTextNode() all keep
// working unchanged. The only thing that changes is what the model does with the
// text: it rewrites it instead of translating it.
//
// Hard limits worth knowing before editing these:
//   * every input id must come back exactly once — the id is the only link to a
//     DOM text node, so dropping or adding ids breaks alignment;
//   * a segment may become longer (several sentences), but it cannot be merged
//     with a neighbour: each segment is written back into its own text node.
const REWRITE_PROMPT_TEMPLATES = {
    // Plainer wording, same facts. The workhorse mode.
    rewrite: {
        system: `You are a plain-language editor. You are given a list of text fragments, each on its own line as "[id]: text". Rewrite every fragment in {{targetLanguage}} so that an ordinary reader understands it on the first read.

Rules:
- Return ONLY a JSON object: {"blocks": [{"id": 0, "text": "...", "links": []}, {"id": 1, "text": "...", "links": []}]}
- One entry per input id, ids unchanged, every id present exactly once.
- Rewrite for clarity: short sentences, active voice, everyday words, no bureaucratic or academic phrasing.
- You MAY split one fragment into several sentences, and you MAY make it noticeably longer than the original.
- You may change word order and sentence structure completely.
- Keep every fact, number, name, term, code identifier and link text exactly as accurate as the original. Do not invent facts.
- You may drop filler, hedging and redundancy.
- Do NOT merge fragments with each other: each fragment is rendered into its own place on the page.
- No explanations, no comments, no markdown.`,
        user: `Rewrite the following fragments in plain {{targetLanguage}}:\n{{texts}}`
    },
    // Same idea, but a different editing style is requested, so it gets its own
    // cache entry and its own editable template.
    rewrite_explain: {
        system: `You are an editor who explains difficult text to a reader with no background in the subject. You are given fragments as "[id]: text". Rewrite every fragment in {{targetLanguage}} so a beginner understands it.

Rules:
- Return ONLY a JSON object: {"blocks": [{"id": 0, "text": "...", "links": []}]}
- One entry per input id, ids unchanged, every id present exactly once.
- Explain jargon in plain words the first time it appears; keep the term itself in brackets if it matters.
- Prefer several short sentences over one long one. Analogies are welcome when they are accurate.
- Keep all facts, numbers and names correct. Do not invent anything.
- Do NOT merge fragments: each one is rendered into its own place on the page.
- No explanations of your own work, no markdown.`,
        user: `Explain these fragments in simple {{targetLanguage}}:\n{{texts}}`
    },
    // De-machine-translate: the source is already in the target language but reads
    // like a machine translation. Nothing is translated, the text is naturalised.
    rewrite_detranslate: {
        system: `You are a native {{targetLanguage}} editor. You are given a list of text fragments, each on its own line as "[id]: text". Some fragments carry a numbered list of links.

Your job is twofold, and both parts apply to every fragment:
1. Remove the traces of machine translation: calques, unnatural word order, wrong case, gender or agreement, literal renderings of idioms, dangling clauses, bureaucratic and academic phrasing. The result must read as if a native speaker wrote it from scratch.
2. Make it understandable to a reader with no background in the subject: explain jargon in plain words at first mention, keep the term itself in brackets when it matters, split long sentences into short ones.

Output format:
- Return ONLY a JSON object: {"blocks": [{"id": 0, "text": "...", "links": [{"i": 0, "t": "anchor text"}]}]}
- One entry per input id, ids unchanged, every id present exactly once.

Rules for the text:
- Rephrase freely and split one fragment into several sentences when it helps. The fragment may become longer than the original.
- Keep every fact, number, name, term, code identifier and quotation accurate. Do not invent anything.
- You may drop filler, hedging and redundancy.

Rules for links:
- Return every link from the fragment's inventory exactly once, using its index: {"i": index, "t": "new anchor text"}.
- Never write a URL. The address is taken from the inventory by index, so an invented or mistyped address cannot be used.
- The anchor text you return must appear in "text" exactly as written, because that is where the link is placed.
- Rewrite the anchor text like the rest of the fragment, but keep proper nouns, titles and code identifiers recognizable.
- If a fragment has no inventory, return "links": [].

Do not merge fragments with each other: each one is rendered into its own place on the page. No explanations, no markdown.`,
        user: `Rewrite these fragments in native, plain {{targetLanguage}}:\n{{texts}}`
    }
};

// Cache for models to avoid repeated API calls during translation
let cachedModels = null;
let modelsCacheTime = 0;
const MODEL_CACHE_TTL = 60000; // 60 seconds

let cachedSettings = null;

// ============================================================================
// Settings Management
// ============================================================================

async function loadSettings() {
    try {
        const result = await browserAPI.storage.local.get('settings');
        const stored = result.settings || null;
        if (stored && stored.settingsVersion === SETTINGS_VERSION) {
            cachedSettings = { ...DEFAULT_SETTINGS, ...stored };
        } else {
            // New build with new defaults: start from the defaults and carry over
            // only what is specific to this machine or explicitly user-authored.
            cachedSettings = { ...DEFAULT_SETTINGS };
            if (stored) {
                for (const key of PRESERVED_ACROSS_DEFAULTS) {
                    if (stored[key] !== undefined) cachedSettings[key] = stored[key];
                }
                console.log(`[Background] settings v${stored.settingsVersion || 1} -> v${SETTINGS_VERSION}: `
                    + `defaults re-applied, kept ${PRESERVED_ACROSS_DEFAULTS.filter(k => stored[k] !== undefined).join(', ') || 'nothing'}`);
            }
            cachedSettings.settingsVersion = SETTINGS_VERSION;
            await browserAPI.storage.local.set({ settings: cachedSettings });
        }
        debugEnabled = !!cachedSettings.debug;
        return cachedSettings;
    } catch (e) {
        console.error('Failed to load settings:', e);
        cachedSettings = { ...DEFAULT_SETTINGS };
        return cachedSettings;
    }
}

async function saveSettings(settings) {
    // Merge defaults < cached < new so fields unknown to the caller are preserved
    cachedSettings = { ...DEFAULT_SETTINGS, ...cachedSettings, ...settings };
    debugEnabled = !!cachedSettings.debug;
    await browserAPI.storage.local.set({ settings: cachedSettings });
    return cachedSettings;
}

async function getSettings() {
    if (!cachedSettings) {
        return loadSettings();
    }
    return cachedSettings;
}

// ============================================================================
// Content script auto-injection
//
// Most of the extension works by injecting content.js on demand when the user
// asks for a translation. Two features instead need it present on every page
// before the user does anything: the floating selection button, and
// auto-translate. Registration is therefore keyed off the union of the two --
// turning one off must not pull the script out from under the other.
// ============================================================================

const CONTENT_SCRIPT_ID = 'llm-translator-content';

function needsContentScript(settings) {
    return !!(settings && (settings.floatingButton || settings.autoTranslatePages));
}

async function syncContentScriptRegistration() {
    const settings = await getSettings();
    if (needsContentScript(settings)) {
        try {
            await browserAPI.scripting.registerContentScripts([{
                id: CONTENT_SCRIPT_ID,
                matches: ['http://*/*', 'https://*/*'],
                js: ['content.js'],
                runAt: 'document_idle'
            }]);
        } catch (e) {
            // Already registered — not an error
        }
        return true;
    }

    try {
        await browserAPI.scripting.unregisterContentScripts({ ids: [CONTENT_SCRIPT_ID] });
    } catch (e) {
        // Not registered — not an error
    }
    return false;
}

// ============================================================================
// Glossary
// User-supplied proper-noun dictionary. Only terms that actually appear in the
// batch being translated are injected into the prompt, so the dictionary itself
// can be large (tens of thousands of entries) without bloating requests.
//
// Stored in storage.local under 'glossary' as an array of [source, target]
// pairs. An empty/identical target means "keep as-is" (do not translate).
// Matching is case-sensitive and Latin word-boundary aware (proper nouns); an
// Aho-Corasick automaton is built lazily so a batch is scanned in one pass.
// ============================================================================

const GLOSSARY_KEY = 'glossary';
const GLOSSARY_META_KEY = 'glossaryMeta';  // { name, loadedAt } of the loaded TSV, for the options UI
const GLOSSARY_MAX_HITS = 40;   // cap terms injected per batch to keep prompts small
const GLOSSARY_PREVIEW_MAX = 200; // rows sent to the options page for the preview list

let glossaryEntries = null;     // Array<[source, target]>, lazily loaded
let glossaryAutomaton = null;   // built Aho-Corasick root, or null
let glossaryExactIndex = null;  // Map<source, target> for whole-segment lookups
let glossaryTargetLang = '';    // '#target: xx' TSV directive; '' = apply to any target
let glossarySig = null;         // content hash folded into the cache key (see promptSig)

async function loadGlossary() {
    if (glossaryEntries) return glossaryEntries;
    try {
        const result = await browserAPI.storage.local.get([GLOSSARY_KEY, GLOSSARY_META_KEY]);
        const entries = result[GLOSSARY_KEY];
        glossaryEntries = Array.isArray(entries) ? entries : [];
        glossaryTargetLang = (result[GLOSSARY_META_KEY] && result[GLOSSARY_META_KEY].target) || '';
    } catch (e) {
        console.error('Failed to load glossary:', e);
        glossaryEntries = [];
        glossaryTargetLang = '';
    }
    glossaryAutomaton = null;
    glossaryExactIndex = null;
    glossarySig = null;
    return glossaryEntries;
}

// Reset in-memory glossary so the next translate reloads it. Called after the
// user replaces or clears the dictionary.
function invalidateGlossary() {
    glossaryEntries = null;
    glossaryAutomaton = null;
    glossaryExactIndex = null;
    glossaryTargetLang = '';
    glossarySig = null;
}

// A glossary maps source terms to ONE target language. When the TSV declares it
// (via a `#target: xx` line), only apply the glossary when translating into that
// language — otherwise a Japanese dictionary would inject Japanese into a
// Spanish translation. Undeclared glossaries apply to every target (legacy).
function glossaryAppliesTo(targetLanguage) {
    if (!glossaryTargetLang) return true;
    const base = (targetLanguage || '').split('-')[0].toLowerCase();
    return glossaryTargetLang === base;
}

// Compact token identifying the active glossary for the translation cache key:
// '' when the glossary is off/empty/inapplicable (so keys match the no-glossary
// ones), else a hash of its entries. This keeps cached output honest when the
// user toggles "Use glossary" or switches target language — without it, text
// translated with glossary hints would be served from cache after disabling it.
async function getGlossarySignature(settings, targetLanguage) {
    if (settings.useGlossary === false) return '';
    const entries = await loadGlossary();
    if (!entries.length || !glossaryAppliesTo(targetLanguage)) return '';
    if (glossarySig === null) glossarySig = hashString(JSON.stringify(entries));
    return glossarySig;
}

// Map of source => target for whole-segment lookups. A segment that consists
// entirely of a glossary term (e.g. the nav heading "About") is translated
// deterministically from this map instead of being sent to the model — prompt
// hints only nudge the model, and short context-free labels are exactly where
// small models produce broken output. An empty target means "keep as-is", same
// as the prompt-hint path. Returns null when the glossary is off or empty.
async function getGlossaryExactIndex(settings, targetLanguage) {
    if (settings.useGlossary === false) return null;
    const entries = await loadGlossary();
    if (!entries.length || !glossaryAppliesTo(targetLanguage)) return null;
    if (!glossaryExactIndex) {
        glossaryExactIndex = new Map();
        for (const entry of entries) {
            const src = entry && entry[0];
            if (!src) continue;
            const tgt = entry[1];
            glossaryExactIndex.set(src, (tgt === undefined || tgt === '') ? src : tgt);
        }
    }
    return glossaryExactIndex;
}

function isWordChar(c) {
    return c !== '' && c !== undefined && /[\p{L}\p{N}_]/u.test(c);
}

// Build an Aho-Corasick automaton over the source strings (case-sensitive,
// UTF-16 unit granularity — fine for Latin proper nouns).
function buildGlossaryAutomaton(entries) {
    const root = { next: new Map(), fail: null, out: [] };
    for (let i = 0; i < entries.length; i++) {
        const pat = entries[i] && entries[i][0];
        if (!pat) continue;
        let node = root;
        for (let j = 0; j < pat.length; j++) {
            const ch = pat[j];
            let child = node.next.get(ch);
            if (!child) { child = { next: new Map(), fail: null, out: [] }; node.next.set(ch, child); }
            node = child;
        }
        node.out.push(i);
    }
    const queue = [];
    for (const child of root.next.values()) { child.fail = root; queue.push(child); }
    while (queue.length) {
        const node = queue.shift();
        for (const [ch, child] of node.next) {
            let f = node.fail;
            while (f && !f.next.has(ch)) f = f.fail;
            child.fail = (f && f.next.get(ch)) || root;
            if (child.fail.out.length) child.out = child.out.concat(child.fail.out);
            queue.push(child);
        }
    }
    return root;
}

// Find glossary entries that occur in `text`. Returns an array of entry indices,
// deduped, in first-seen order, capped at GLOSSARY_MAX_HITS. A Latin match is
// rejected when it sits inside a larger word (e.g. "Container" in "Containers").
function scanGlossary(root, entries, text) {
    const seen = new Set();
    const order = [];
    let node = root;
    for (let i = 0; i < text.length && order.length < GLOSSARY_MAX_HITS; i++) {
        const ch = text[i];
        while (node !== root && !node.next.has(ch)) node = node.fail;
        node = node.next.get(ch) || root;
        if (!node.out.length) continue;
        for (const idx of node.out) {
            if (seen.has(idx)) continue;
            const pat = entries[idx][0];
            const end = i + 1;
            const start = end - pat.length;
            const before = start > 0 ? text[start - 1] : '';
            const after = end < text.length ? text[end] : '';
            const cutStart = isWordChar(before) && isWordChar(pat[0]);
            const cutEnd = isWordChar(after) && isWordChar(pat[pat.length - 1]);
            if (cutStart || cutEnd) continue;
            seen.add(idx);
            order.push(idx);
            if (order.length >= GLOSSARY_MAX_HITS) break;
        }
    }
    return order;
}

// Build the glossary instruction block for the terms found in `text`. Returns ''
// when the glossary is empty or nothing matches, so prompts are unchanged.
async function buildGlossaryBlock(settings, text, targetLanguage) {
    if (settings.useGlossary === false) return '';
    const entries = await loadGlossary();
    if (!entries.length || !glossaryAppliesTo(targetLanguage)) return '';
    if (!glossaryAutomaton) glossaryAutomaton = buildGlossaryAutomaton(entries);
    const hits = scanGlossary(glossaryAutomaton, entries, text);
    if (!hits.length) return '';
    const lines = hits.map(idx => {
        const [src, tgt] = entries[idx];
        const target = (tgt === undefined || tgt === '') ? src : tgt;
        return `- "${src}" => "${target}"`;
    });
    return `[Glossary] Use these exact translations for the listed terms. Keep them consistent and do not alter them:\n${lines.join('\n')}`;
}

// ============================================================================
// Provider Detection & Model Listing
// ============================================================================

// Normalize a user-entered server URL into a bare base (scheme://host:port):
// trims whitespace and drops trailing slashes and a trailing /v1. Users of
// OpenAI-compatible servers (llama.cpp, vLLM) habitually paste the base URL as
// ".../v1" because that's what OpenAI clients expect, but we append the full
// /v1/... path ourselves. LM Studio's router tolerates the resulting
// /v1/v1/... and //v1/... paths; llama.cpp and vLLM route strictly and 404,
// which made those servers look unsupported (issue #4).
//
// Also rewrites a bare "localhost" host to 127.0.0.1. Ollama's default bind
// is IPv4-only, but on systems where /etc/hosts lists "::1 localhost",
// Firefox resolves "localhost" via IPv6 first and gets a hard connection
// refusal instead of falling back to IPv4 - CORS logic never even runs.
function normalizeServerUrl(rawUrl) {
    let url = (rawUrl || '').trim().replace(/\/+$/, '').replace(/\/v1$/i, '').replace(/\/+$/, '');
    try {
        const parsed = new URL(url);
        if (parsed.hostname === 'localhost') {
            parsed.hostname = '127.0.0.1';
            url = parsed.toString().replace(/\/+$/, '');
        }
    } catch (_) {
        // Malformed input; leave as-is so the caller's fetch surfaces the real error.
    }
    return url;
}

async function probeProvider(url, originProbeUrl) {
    try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 2000);
        const response = await fetch(url, {
            method: 'GET',
            signal: controller.signal
        });
        clearTimeout(timeout);
        if (response.ok && originProbeUrl) {
            // A GET sent by an extension carries no Origin header, so a server-side
            // origin check (e.g. Ollama without OLLAMA_ORIGINS) lets the probe
            // through even though it will reject the POST translation requests.
            // Send a cheap POST, which always carries an Origin header, and treat
            // a 403 as "running but blocking the extension".
            try {
                const controller3 = new AbortController();
                const timeout3 = setTimeout(() => controller3.abort(), 2000);
                const originResponse = await fetch(originProbeUrl, {
                    method: 'POST',
                    body: '{}',
                    signal: controller3.signal
                });
                clearTimeout(timeout3);
                if (originResponse.status === 403) {
                    return { ok: false, blocked: true };
                }
            } catch (_) {
                // Origin probe failed for another reason; keep the GET verdict.
            }
        }
        return { ok: response.ok, blocked: false };
    } catch (e) {
        // Normal fetch failed — could be server not running, or CORS blocking the response.
        // Try a no-cors fetch: it gives an opaque response (can't read status/body) but
        // will not throw if the server is reachable, only if it is truly unreachable.
        try {
            const controller2 = new AbortController();
            const timeout2 = setTimeout(() => controller2.abort(), 2000);
            await fetch(url, {
                method: 'GET',
                mode: 'no-cors',
                signal: controller2.signal
            });
            clearTimeout(timeout2);
            return { ok: false, blocked: true };
        } catch (_) {
            return { ok: false, blocked: false };
        }
    }
}

async function detectProviders(ollamaUrl, lmstudioUrl, provider = 'auto') {
    ollamaUrl = normalizeServerUrl(ollamaUrl);
    lmstudioUrl = normalizeServerUrl(lmstudioUrl);
    // Probe both providers in parallel, skipping any provider the user has
    // explicitly not selected, so one slow/absent server doesn't delay the other.
    const skipped = { ok: false, blocked: false };
    const [ollama, lmstudio] = await Promise.all([
        (provider === 'ollama' || provider === 'auto') ? probeProvider(`${ollamaUrl}/api/tags`, `${ollamaUrl}/api/show`) : skipped,
        (provider === 'lmstudio' || provider === 'auto') ? probeProvider(`${lmstudioUrl}/v1/models`) : skipped
    ]);

    return {
        ollama: ollama.ok,
        ollama_blocked: ollama.blocked,
        lmstudio: lmstudio.ok,
        lmstudio_blocked: lmstudio.blocked
    };
}

async function listOllamaModels(url) {
    url = normalizeServerUrl(url);
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    try {
        const response = await fetch(`${url}/api/tags`, { signal: controller.signal });
        clearTimeout(timeoutId);
        if (!response.ok) throw new Error('Failed to fetch Ollama models');
        const data = await response.json();
        return (data.models || []).map(m => ({ id: m.name, name: m.name, provider: 'ollama' }));
    } catch (e) {
        clearTimeout(timeoutId);
        if (e.name === 'AbortError') throw new Error('Ollama model listing timed out');
        throw e;
    }
}

async function listLMStudioModels(url) {
    url = normalizeServerUrl(url);
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    try {
        const response = await fetch(`${url}/v1/models`, { signal: controller.signal });
        clearTimeout(timeoutId);
        if (!response.ok) throw new Error('Failed to fetch LMStudio models');
        const data = await response.json();
        return (data.data || []).map(m => ({ id: m.id, name: m.id, provider: 'lmstudio' }));
    } catch (e) {
        clearTimeout(timeoutId);
        if (e.name === 'AbortError') throw new Error('LMStudio model listing timed out');
        throw e;
    }
}

async function listModels(settings, useCache = true) {
    // Return cached models if available and not expired
    if (useCache && cachedModels && (Date.now() - modelsCacheTime < MODEL_CACHE_TTL)) {
        return cachedModels;
    }

    const models = [];
    const provider = settings.provider;

    // Query both providers in parallel; allSettled keeps results positional so
    // LMStudio models still come first, and a failure only propagates when that
    // provider was explicitly selected.
    const [lmstudioResult, ollamaResult] = await Promise.allSettled([
        (provider === 'lmstudio' || provider === 'auto')
            ? listLMStudioModels(settings.lmstudioUrl) : Promise.resolve([]),
        (provider === 'ollama' || provider === 'auto')
            ? listOllamaModels(settings.ollamaUrl) : Promise.resolve([])
    ]);
    if (lmstudioResult.status === 'fulfilled') models.push(...lmstudioResult.value);
    else if (provider === 'lmstudio') throw lmstudioResult.reason;
    if (ollamaResult.status === 'fulfilled') models.push(...ollamaResult.value);
    else if (provider === 'ollama') throw ollamaResult.reason;

    // Update cache
    cachedModels = models;
    modelsCacheTime = Date.now();

    return models;
}

// ============================================================================
// Translation Logic
// ============================================================================

function formatTextsForPrompt(textItems) {
    return textItems.map(item => `[${item.id}]: ${item.text}`).join('\n');
}

function buildPrompt(template, vars) {
    let result = template;
    for (const [key, value] of Object.entries(vars)) {
        result = result.replace(new RegExp(`{{${key}}}`, 'g'), value);
    }
    return result;
}

// A small allowlist of inline HTML tags that occasionally leak from models.
// We only strip these — arbitrary "<...>" is left alone so legitimate text like
// "a < b" or "<3" is never mangled.
const LEAKED_HTML_TAG = /<\/?(?:div|span|p|br|b|i|em|strong|ul|ol|li|a|h[1-6])\b[^>]*>/gi;

// Clean translation text - remove ID prefixes and HTML garbage that LLM might include
function cleanTranslationText(text) {
    if (!text) return text;
    // Remove patterns like "[99]: ", "[99]:", "99: ", "99:" at start of text
    let cleaned = text.replace(/^\[?\d+\]?:\s*/g, '');
    // Remove only known HTML tags that occasionally leak through
    cleaned = cleaned.replace(LEAKED_HTML_TAG, '');
    // Normalize multiple spaces to single space (but preserve leading/trailing)
    cleaned = cleaned.replace(/  +/g, ' ');
    // Don't trim - let content.js handle whitespace preservation from original
    return cleaned;
}

// Heuristic: does this string look like leaked structure (JSON/markup) rather
// than an actual translation? Used to reject garbage so the page keeps its
// original text instead of being broken. Be conservative to avoid false positives.
function isSuspiciousTranslation(text) {
    if (text === null || text === undefined) return true;
    const t = String(text).trim();
    if (!t) return true;
    // Must contain at least one letter — pure punctuation/braces is garbage.
    if (!/\p{L}/u.test(t)) return true;
    // Leaked JSON keys from our own schema.
    if (/["']?(?:translations|id|text)["']?\s*:/.test(t)) return true;
    // Wrapped in a JSON object/array container with a quote or colon inside.
    if (/^[\[{][\s\S]*[\]}]$/.test(t) && /["':]/.test(t)) return true;
    // Markdown code fence.
    if (t.includes('```')) return true;
    return false;
}

// Extract the first balanced {...} object from a string, respecting strings and
// escapes. More reliable than a greedy regex when the model adds prose around it.
function extractJsonObject(text) {
    const start = text.indexOf('{');
    if (start === -1) return null;
    let depth = 0;
    let inString = false;
    let escaped = false;
    for (let i = start; i < text.length; i++) {
        const ch = text[i];
        if (inString) {
            if (escaped) escaped = false;
            else if (ch === '\\') escaped = true;
            else if (ch === '"') inString = false;
        } else if (ch === '"') {
            inString = true;
        } else if (ch === '{') {
            depth++;
        } else if (ch === '}') {
            depth--;
            if (depth === 0) return text.slice(start, i + 1);
        }
    }
    return null; // Unbalanced (e.g. truncated) — let the caller fall back.
}

function parseTranslationResponse(response, originalItems, finishReason) {
    const expectedCount = originalItems.length;
    let translations = [];

    try {
        // Clean up markdown code blocks if present
        let cleanResponse = response
            .replace(/^```json\s*/m, '')
            .replace(/^```\s*/m, '')
            .replace(/\s*```$/m, '')
            .trim();

        // Try to parse as JSON first
        const parsed = JSON.parse(cleanResponse);
        if (parsed.translations && Array.isArray(parsed.translations)) {
            translations = parsed.translations;
        } else if (Array.isArray(parsed)) {
            translations = parsed;
        }
    } catch (e) {
        // Try to extract a balanced JSON object embedded in surrounding prose
        const jsonStr = extractJsonObject(response);
        if (jsonStr) {
            try {
                const parsed = JSON.parse(jsonStr);
                if (parsed.translations && Array.isArray(parsed.translations)) {
                    translations = parsed.translations;
                } else if (Array.isArray(parsed)) {
                    translations = parsed;
                }
            } catch (e2) {
                // Fall through to line-by-line parsing
            }
        }
    }

    // If JSON parsing worked, check if we need to remap IDs
    if (translations.length > 0) {
        // Clean up translations - remove any ID prefixes from the text
        translations = translations.map(t => ({
            ...t,
            text: cleanTranslationText(t.text)
        }));

        // Check if LLM returned sequential IDs (0, 1, 2...) instead of our IDs
        const llmIds = translations.map(t => t.id);
        const ourIds = originalItems.map(t => t.id);
        const llmUsedSequential = llmIds.every((id, i) => id === i);
        const idsMismatch = !llmIds.some(id => ourIds.includes(id));

        if (llmUsedSequential || idsMismatch) {
            // console.log('[Background] LLM used sequential IDs, remapping to original IDs');
            // Map sequential LLM IDs to our original IDs
            translations = translations.map((t, index) => ({
                id: originalItems[index]?.id ?? t.id,
                text: t.text,
                error: t.error
            }));
        }

        return translations;
    }

    // Single item: the entire response is one translation (preserve newlines)
    if (expectedCount === 1) {
        let text = response.trim().replace(/^\[?\d+\]?:\s*/, '');
        return [{ id: originalItems[0].id, text: cleanTranslationText(text) }];
    }

    // Fallback: parse by [id]: markers, grouping continuation lines per segment
    const idMarkerRegex = /^\[?(\d+)\]?:\s*(.*)$/;
    const segments = [];
    let current = null;

    for (const line of response.split('\n')) {
        const match = line.match(idMarkerRegex);
        if (match) {
            if (current) segments.push(current);
            current = { id: parseInt(match[1]), text: match[2] };
        } else if (current) {
            current.text += '\n' + line;
        }
    }
    if (current) segments.push(current);

    // When the server tells us it cut generation off mid-output, the last segment
    // in the response was being written the instant that happened — it may be a
    // half-formed sentence ("Los precios pue"), not a usable translation. Drop it
    // so it's treated as missing and cleanly retried, instead of risking a mangled
    // translation landing on the page. Every earlier segment finished before the
    // cutoff and is unaffected.
    if (finishReason === 'length' && segments.length > 0) {
        const cut = segments.pop();
        debugWarn(`[Background] response was cut off by the output length limit — `
            + `discarding the in-progress last segment (id ${cut.id}) instead of trusting a possibly-truncated translation`);
        if (segments.length === 0) {
            // The one segment we had was the one being cut — nothing usable left.
            // Bail out here rather than falling through to the last-resort parser
            // below, which would re-read the same truncated raw response.
            return [];
        }
    }

    if (segments.length > 0) {
        // Every batch sends the model 0-indexed sequential labels (see requestBatch),
        // so a clean truncation (model stops after item k of N) and a
        // dropped-and-renumbered middle item both produce the same shape: an
        // unbroken run 0..k-1 shorter than expected. finishReason (from the API's
        // finish_reason/done_reason) resolves the ambiguity when it's available:
        // 'length' means the model was cut off mid-output and whatever it emitted
        // up to that point is exactly what it intended — safe to trust. Anything
        // else (usually 'stop', or unknown on servers that don't report it) means
        // the model believed it was done despite the shortfall, which is the more
        // suspicious shape. Either way we trust the prefix and retry only the
        // missing tail — rejecting the whole batch here previously forced every
        // truncated response through the slow per-item fallback, which in practice
        // was most responses. Only reject outright on unambiguous corruption: a
        // label outside our range, or a repeated label.
        const ids = segments.map(s => s.id);
        const ourIds = new Set(originalItems.map(item => item.id));
        const allOurs = ids.every(id => ourIds.has(id));
        const unique = new Set(ids).size === ids.length;
        if (!allOurs || !unique) {
            debugWarn(`[Background] expected ${expectedCount} items, got labels [${ids.join(',')}]`
                + ` - numbering unreliable, rejecting batch`);
            return [];
        }
        if (ids.length < expectedCount) {
            const reason = finishReason === 'length'
                ? 'model hit its output length limit'
                : `model stopped on its own (finish_reason=${finishReason || 'unknown'}) — possible mid-batch skip`;
            debugWarn(`[Background] batch returned ${ids.length}/${expectedCount} items - ${reason}. Trusting the ${ids.length} received, retrying the rest.`);
        }

        for (const seg of segments) {
            const text = seg.text.trim();
            if (!text) continue;
            translations.push({ id: seg.id, text: cleanTranslationText(text) });
        }
        return translations;
    }

    // Last resort: no markers found, one line = one translation
    for (let i = 0; i < Math.min(response.split('\n').filter(l => l.trim()).length, expectedCount); i++) {
        const line = response.split('\n').filter(l => l.trim())[i];
        const originalId = originalItems[i]?.id;
        if (originalId !== undefined) translations.push({ id: originalId, text: cleanTranslationText(line.trim()) });
    }
    return translations;
}

async function autoDetectAndSelectModel() {
    try {
        const settings = await getSettings();
        if (settings.selectedModel) return null; // already configured

        const models = await listModels(settings, false); // force fresh fetch
        if (models.length === 0) return null;

        // Prefer a translation-specialized model if one is loaded, else first available.
        // The request format is derived from the model automatically (requestFormat: 'auto'),
        // so we only need to pick the model and provider here.
        // In rewrite mode a translation-specialised model (TranslateGemma,
        // Hunyuan-MT) is the wrong pick: it is trained on a fixed translation
        // prompt and ignores a rewrite instruction, so take a general model.
        const isRewrite = (await getSettings()).outputMode === 'rewrite';
        const preferred = isRewrite
            ? (models.find(m => detectRequestFormat(m.id) === 'default') || models[0])
            : (models.find(m => detectRequestFormat(m.id) !== 'default') || models[0]);

        await saveSettings({
            selectedModel: preferred.id,
            provider: preferred.provider
        });
        console.log(`[Background] Auto-selected model: ${preferred.id} (${preferred.provider})`);
        return preferred;
    } catch (e) {
        console.warn('[Background] Auto model detection failed:', e.message);
        return null;
    }
}

async function detectModelProvider(modelId, settings) {
    // Use cached models to avoid extra API calls
    const models = await listModels(settings, true);
    const model = models.find(m => m.id === modelId);
    return model ? model.provider : null;
}

// LM Studio's native (non-OpenAI-compatible) REST API exposes per-model load
// state ('not-loaded' | 'loading' | 'loaded'), which the OpenAI-compatible
// /v1/models endpoint doesn't. Used to show "Loading model..." instead of a
// progress bar that looks frozen while LM Studio JIT-loads the model on the
// first request. Returns null if unavailable (older LM Studio, or not LM
// Studio at all) so callers can just skip the check.
async function getLMStudioModelState(url, modelId) {
    const path = modelId.split('/').map(encodeURIComponent).join('/');
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3000);
    try {
        const response = await fetch(`${normalizeServerUrl(url)}/api/v0/models/${path}`, { signal: controller.signal });
        if (!response.ok) return null;
        const data = await response.json();
        return data.state || null;
    } catch (e) {
        return null;
    } finally {
        clearTimeout(timeoutId);
    }
}

// PLAIN_TEXT_FORMATS comes from languages.js (shared with the UIs).

async function callOllama(settings, modelId, systemPrompt, userPrompt, jsonOutput, jsonSchema) {
    const body = {
        model: modelId,
        stream: false
    };

    // Request a schema-constrained JSON object when the caller wants structure.
    // Passing the full schema (not just 'json') makes Ollama enforce the shape,
    // not just valid-JSON-ness.
    if (jsonOutput) {
        // Callers pass the schema their parser expects: translate() wants
        // {translations:[...]}, rewriteBlocks() wants {blocks:[{id,text,links}]}.
        body.format = jsonSchema || TRANSLATION_JSON_SCHEMA;
    }

    body.prompt = systemPrompt ? `${systemPrompt}\n\n${userPrompt}` : userPrompt;
    body.keep_alive = '30m';
    body.options = {};
    if (settings.temperature !== undefined) body.options.temperature = settings.temperature;
    if (settings.numCtx) body.options.num_ctx = settings.numCtx;

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 300000);
    let response;
    try {
        response = await fetch(`${normalizeServerUrl(settings.ollamaUrl)}/api/generate`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
            signal: controller.signal
        });
    } catch (e) {
        clearTimeout(timeoutId);
        if (e.name === 'AbortError') throw new Error('Ollama request timed out after 5 minutes');
        throw e;
    }
    clearTimeout(timeoutId);

    if (!response.ok) {
        if (response.status === 403) {
            throw new Error('Ollama returned 403 Forbidden. The extension is being blocked by Ollama\'s CORS policy. You need to enable CORS in Ollama.');
        }
        const error = await response.text();
        throw new Error(`Ollama error (${response.status}): ${error || '(empty response)'}`);
    }

    const data = await response.json();
    // done_reason tells us WHY generation stopped ('stop' = the model chose to end,
    // 'length' = it hit num_predict/context and was cut off mid-output). Only
    // present on newer Ollama versions; undefined on older ones.
    debugLog(`[Background] callOllama: response length=${data.response?.length || 0} done_reason=${data.done_reason || 'unknown'}`);
    return { content: data.response, finishReason: data.done_reason || null };
}



// JSON schema for the batched translation response. The inner shape is shared:
// Ollama wants the bare schema in `format`, LMStudio/OpenAI want it wrapped.
const TRANSLATION_JSON_SCHEMA = {
    "type": "object",
    "properties": {
        "translations": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "id": { "type": "integer" },
                    "text": { "type": "string" }
                },
                "required": ["id", "text"],
                "additionalProperties": false
            }
        }
    },
    "required": ["translations"],
    "additionalProperties": false
};
async function callLMStudio(settings, modelId, systemPrompt, userPrompt, jsonOutput, jsonSchema) {
    const messages = [];

    if (systemPrompt) {
        messages.push({ role: 'system', content: systemPrompt });
    }
    messages.push({ role: 'user', content: userPrompt });

    const body = {
        model: modelId,
        messages,
        temperature: settings.temperature || 0.3,
        stream: false
    };

    if (jsonOutput) {
        body.response_format = {
            "type": "json_schema",
            "json_schema": {
                "name": "translation_response",
                "strict": true,
                "schema": jsonSchema || TRANSLATION_JSON_SCHEMA
            }
        };
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 300000);
    let response;
    try {
        response = await fetch(`${normalizeServerUrl(settings.lmstudioUrl)}/v1/chat/completions`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
            signal: controller.signal
        });
    } catch (e) {
        clearTimeout(timeoutId);
        if (e.name === 'AbortError') throw new Error('LMStudio request timed out after 5 minutes');
        if (e instanceof TypeError) {
            throw new Error('Failed to connect to LMStudio. The extension is being blocked by LMStudio\'s CORS policy or the server is offline. You need to enable CORS in LMStudio.');
        }
        throw e;
    }
    clearTimeout(timeoutId);

    if (!response.ok) {
        const error = await response.text();
        // Older OpenAI-compatible servers (llama.cpp before mid-2024, older vLLM)
        // reject response_format json_schema with a 400. Retry once without it —
        // the prompt already asks for JSON and the parser tolerates loose output.
        if (jsonOutput && response.status === 400 && /response_format|json_schema|guided/i.test(error)) {
            debugWarn('[Background] Server rejected structured output; retrying without response_format');
            return callLMStudio(settings, modelId, systemPrompt, userPrompt, false, jsonSchema);
        }
        throw new Error(`LMStudio error: ${error}`);
    }

    const data = await response.json();
    let content = data.choices[0]?.message?.content || '';

    // Clean up markdown code blocks if present
    content = content.replace(/^```json\s*/, '').replace(/^```\s*/, '').replace(/\s*```$/, '');

    // finish_reason: 'stop' = the model chose to end on its own, 'length' = it hit
    // max_tokens/context and was cut off mid-output. Tells us definitively whether
    // a short batch was a token-budget truncation instead of having to guess from
    // the label pattern alone.
    const finishReason = data.choices[0]?.finish_reason || null;
    debugLog(`[Background] callLMStudio: finish_reason=${finishReason || 'unknown'}`);
    return { content, finishReason };
}

// Low-level call to whichever provider, returning { content, finishReason }.
async function callProvider(provider, settings, modelId, systemPrompt, userPrompt, jsonOutput, jsonSchema) {
    if (provider === 'ollama') {
        return callOllama(settings, modelId, systemPrompt, userPrompt, jsonOutput, jsonSchema);
    }
    return callLMStudio(settings, modelId, systemPrompt, userPrompt, jsonOutput, jsonSchema);
}

// Translate a single text as plain text (no JSON), used as the last-resort
// fallback when structured output keeps failing. The whole response IS the
// translation — nothing to parse, nothing to break the page.
async function translatePlainItem(provider, settings, modelId, text, vars) {
    const systemPrompt = `You are a professional translator. Translate the user's text into ${vars.targetLang}. Output ONLY the translation, with no quotes, labels, JSON, or commentary.`;
    const userPrompt = text;
    const { content } = await callProvider(provider, settings, modelId, systemPrompt, userPrompt, false);
    return cleanTranslationText((content || '').trim());
}

// Small fast non-cryptographic string hash (cyrb53). Folds the prompt shape
// (templates + sampling params) into a compact token for the cache key without
// bloating it with the full template text.
function hashString(str) {
    let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
    for (let i = 0; i < str.length; i++) {
        const ch = str.charCodeAt(i);
        h1 = Math.imul(h1 ^ ch, 2654435761);
        h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (h2 >>> 0).toString(36) + (h1 >>> 0).toString(36);
}

// Which key customPrompts is indexed by. Rewrite templates live under their own
// keys ('rewrite', 'rewrite_explain', 'rewrite_detranslate') so that editing the
// translation prompt on the options page cannot silently change rewrite output,
// and vice versa.
function promptOverrideKey(outputMode, format, rewriteStyle) {
    return outputMode === 'rewrite' ? rewriteStyle : format;
}

async function translate(textItems, targetLanguage, settings) {
    const modelId = settings.selectedModel;
    if (!modelId) throw new Error('No model selected');

    // Detect provider if auto
    let provider = settings.provider;
    if (provider === 'auto') {
        provider = await detectModelProvider(modelId, settings);
        if (!provider) throw new Error('Could not detect model provider');
    }

    // Resolve the effective request format ('auto' -> derived from the model).
    let format = resolveRequestFormat(settings, modelId);

    // Rewrite mode replaces the task (rewrite instead of translate), so the
    // translation-specific formats no longer apply: TranslateGemma and
    // Hunyuan-MT are trained on a fixed translation prompt shape, return plain
    // text and would ignore a rewrite instruction. Force the structured format.
    const outputMode = settings.outputMode === 'rewrite' ? 'rewrite' : 'translate';
    let rewriteStyle = null;
    if (outputMode === 'rewrite') {
        rewriteStyle = settings.rewriteStyle && REWRITE_PROMPT_TEMPLATES[settings.rewriteStyle]
            ? settings.rewriteStyle
            : 'rewrite';
        format = 'default';
    }

    const isPlainText = PLAIN_TEXT_FORMATS.has(format);
    const template = outputMode === 'rewrite'
        ? REWRITE_PROMPT_TEMPLATES[rewriteStyle]
        : (PROMPT_TEMPLATES[format] || PROMPT_TEMPLATES.default);

    // A per-format override (edited and saved on the options page) wins over the
    // built-in template for that format. This applies whether the format was
    // picked explicitly or reached via 'auto' detection — the override is keyed
    // by the resolved format either way.
    const override = settings.customPrompts && settings.customPrompts[promptOverrideKey(outputMode, format, rewriteStyle)];
    const systemTemplate = (override && override.system) || template.system;
    const userTemplate = (override && override.user) || template.user;

    // Template variables shared across attempts
    const targetLangName = getLanguageName(targetLanguage);
    const sourceLangCode = (settings.sourceLanguage && settings.sourceLanguage !== 'auto')
        ? settings.sourceLanguage
        : 'en';
    const baseVars = {
        targetLanguage: targetLangName,
        sourceLang: getLanguageName(sourceLangCode),
        sourceCode: sourceLangCode.toUpperCase(),
        targetLang: targetLangName,
        targetCode: targetLanguage.toUpperCase()
    };

    // Whether to request schema-constrained JSON for this (structured) format.
    const wantJson = !!settings.useStructuredOutput && !isPlainText;

    // Run one batched request for the given subset of items, returning a Map of
    // id -> good translation text (suspicious/empty results are dropped).
    const requestBatch = async (items) => {
        // Map items to 0-indexed sequential IDs for the prompt to avoid confusing the LLM
        const mappedItems = items.map((item, index) => ({ id: index, text: item.text, originalId: item.id }));
        
        const vars = { ...baseVars, texts: formatTextsForPrompt(mappedItems) };
        let userPrompt = buildPrompt(userTemplate, vars);
        const systemPrompt = buildPrompt(systemTemplate, vars);

        // Prepend matching glossary terms so the model keeps proper nouns
        // consistent. Empty when the glossary is off/unmatched (prompt unchanged).
        // Skipped for plain-text formats (TranslateGemma, Hunyuan-MT): those
        // models expect a fixed prompt shape and would treat an extra instruction
        // block as text to translate. Whole-segment mappings still apply to them.
        if (!isPlainText) {
            const glossaryBlock = await buildGlossaryBlock(settings, mappedItems.map(m => m.text).join('\n'), targetLanguage);
            if (glossaryBlock) userPrompt = `${glossaryBlock}\n\n${userPrompt}`;
        }
        const { content: raw, finishReason } = await callProvider(provider, settings, modelId, systemPrompt, userPrompt, wantJson);
        debugLog(`[Background] Raw LLM response (first 300 chars):`, (raw || '').substring(0, 300));

        // Parse using the mapped items so it expects 0, 1, 2...
        const parsed = parseTranslationResponse(raw, mappedItems, finishReason);
        const good = new Map();
        for (const t of parsed) {
            if (t && t.text && !t.error && !isSuspiciousTranslation(t.text)) {
                // Find the original item to get its real ID
                const originalItem = mappedItems.find(m => m.id === t.id);
                if (originalItem) {
                    good.set(originalItem.originalId, t.text);
                }
            }
        }
        return good;
    };

    // Translate one item on its own, using the format's own template with a single
    // unmarked segment — the shape these models were trained on. There is no batch
    // structure to parse, so the result cannot land on the wrong item.
    const requestOne = async (text) => {
        const vars = { ...baseVars, texts: text };
        const { content } = await callProvider(provider, settings, modelId,
            buildPrompt(systemTemplate, vars), buildPrompt(userTemplate, vars), false);
        return cleanTranslationText((content || '').trim());
    };

    const results = new Map();          // originalId -> final translated text

    // ---- Cache + de-duplication --------------------------------------------
    // Group items by a key capturing everything that determines the model output
    // (model, languages, prompt shape/params) plus the source text, so each unique
    // string is translated once and identical strings reuse the result across
    // batches, pages, and sessions. promptSig folds in the resolved prompt
    // templates + structured-output mode + temperature so changing any of them
    // doesn't serve stale output. When the cache is off/unavailable we key by raw
    // text, which still de-dups within the request. cacheKey/cache* come from cache.js.
    const cacheEnabled = settings.cacheMode !== 'off'
        && typeof cacheGetMany === 'function' && typeof cacheKey === 'function';
    const promptSig = hashString([
        format, wantJson ? 'json' : 'plain', String(settings.temperature),
        systemTemplate, userTemplate,
        await getGlossarySignature(settings, targetLanguage)
    ].join('\u0000'));
    const keyFor = cacheEnabled
        ? (text) => cacheKey(modelId, sourceLangCode, targetLanguage, promptSig, text)
        : (text) => text;

    // key -> { key, item: representative, ids: [every originalId sharing this text] }
    const groups = new Map();
    for (const item of textItems) {
        const k = keyFor(item.text);
        const g = groups.get(k);
        if (g) g.ids.push(item.id);
        else groups.set(k, { key: k, item, ids: [item.id] });
    }

    // Whole-segment glossary matches resolve deterministically, before the cache
    // and the model — the user's explicit mapping beats both a cached LLM answer
    // and a fresh one. Not written to the cache (the lookup is cheaper than it).
    let glossaryExactCount = 0;
    const exactIndex = await getGlossaryExactIndex(settings, targetLanguage);
    if (exactIndex) {
        for (const g of groups.values()) {
            const direct = exactIndex.get(g.item.text.trim());
            if (direct !== undefined) {
                results.set(g.item.id, direct);
                glossaryExactCount++;
            }
        }
        if (glossaryExactCount) {
            debugLog(`[Background] glossary: ${glossaryExactCount} whole-segment match(es) resolved without the model`);
        }
    }
    const unresolvedGroups = glossaryExactCount
        ? [...groups.values()].filter(g => !results.has(g.item.id))
        : [...groups.values()];

    // Serve cache hits up front; only unresolved groups go to the model.
    let cacheHitCount = 0;      // unique source strings served from cache
    let fromCacheItems = 0;     // text elements served from cache (incl. duplicates)
    let missGroups;
    if (cacheEnabled) {
        try {
            const found = await cacheGetMany(unresolvedGroups.map(g => g.key));
            missGroups = [];
            for (const g of unresolvedGroups) {
                const cached = found.get(g.key);
                if (cached !== undefined) {
                    results.set(g.item.id, cached);
                    cacheHitCount++;
                    fromCacheItems += g.ids.length;
                } else {
                    missGroups.push(g);
                }
            }
        } catch (e) {
            debugWarn('[Background] cache read failed, translating all:', e && e.message);
            missGroups = unresolvedGroups;
        }
    } else {
        missGroups = unresolvedGroups;
    }
    debugLog(`[Background] cache: ${cacheHitCount} hit / ${missGroups.length} miss (${groups.size} unique of ${textItems.length} total)`);

    let pending = missGroups.map(g => g.item);   // representative item per unresolved group

    // Attempt the batched request, retrying only the items that came back
    // missing or malformed. maxOutputRetries extra attempts after the first.
    const maxRetries = Number.isInteger(settings.maxOutputRetries) ? settings.maxOutputRetries : 2;
    debugLog(`[Background] translate: provider=${provider} model=${modelId} format=${format} items=${textItems.length} json=${wantJson}`);
    for (let attempt = 0; attempt <= maxRetries && pending.length > 0; attempt++) {
        let good;
        try {
            good = await requestBatch(pending);
        } catch (e) {
            if (attempt === maxRetries) throw e; // bubble transport errors on last try
            debugWarn(`[Background] batch attempt ${attempt + 1} threw:`, e.message);
            continue;
        }
        for (const item of pending) {
            const text = good.get(item.id);
            if (text !== undefined) results.set(item.id, text);
        }
        pending = pending.filter(item => !results.has(item.id));
        if (pending.length) {
            debugWarn(`[Background] ${pending.length} item(s) malformed/missing after attempt ${attempt + 1}`);
        }
        // Nothing usable at all from a multi-item batch means the response could not
        // be aligned. Re-sending identical input to a near-deterministic model just
        // reproduces the same failure, so skip the remaining retries and let the
        // per-item fallback below resolve it.
        if (good.size === 0 && pending.length > 1) {
            debugWarn(`[Background] batch unusable - skipping remaining retries`);
            break;
        }
    }

    // Per-item fallback: translate the still-failing items one at a time, with no
    // batch structure to parse. Plain-text formats need this too — they carry the
    // same [id]: markers in a batched prompt, and a dropped segment shifts the rest.
    if (pending.length > 0 && settings.plainTextFallback !== false) {
        debugWarn(`[Background] Falling back to per-item translation for ${pending.length} item(s)`);
        for (const item of pending) {
            try {
                const text = isPlainText
                    ? await requestOne(item.text)
                    : await translatePlainItem(provider, settings, modelId, item.text, baseVars);
                if (text && !isSuspiciousTranslation(text)) results.set(item.id, text);
            } catch (e) {
                debugWarn(`[Background] per-item fallback failed for id ${item.id}:`, e.message);
            }
        }
    }

    // Persist freshly produced translations. Awaited so an MV3 service worker
    // isn't torn down before the IndexedDB write commits.
    if (cacheEnabled) {
        const entries = [];
        for (const g of missGroups) {
            if (results.has(g.item.id)) entries.push([g.key, results.get(g.item.id)]);
        }
        if (entries.length) {
            try { await cacheSetMany(entries); }
            catch (e) { debugWarn('[Background] cache write failed:', e && e.message); }
        }
    }

    // Fan each group's translation out to every member sharing its source text.
    for (const g of groups.values()) {
        if (!results.has(g.item.id)) continue;
        const text = results.get(g.item.id);
        for (const id of g.ids) results.set(id, text);
    }

    // Build the final array in original order. Items that never succeeded are
    // returned with an error so the content script keeps their original text.
    const translations = textItems.map(item => results.has(item.id)
        ? { id: item.id, text: results.get(item.id) }
        : { id: item.id, error: 'translation failed' });
    return { translations, fromCache: fromCacheItems, total: textItems.length, cacheActive: cacheEnabled };
}

// ============================================================================
// Block rewrite mode
//
// Rewrite works on whole blocks (a paragraph, a list item, a heading) instead of
// individual text nodes, so the model sees enough context to restructure the
// text. Two things follow from that and shape everything below.
//
// 1. Links. Inline markup is dropped when a block is rewritten, but links must
//    survive. So each block is sent as plain text plus a numbered inventory of
//    its links, and the model answers with the new text plus a list of
//    {i, t} pairs: which inventory entry to place, and what its anchor text is
//    now. The model never writes an href — it points at one by index, so a
//    hallucinated or mangled URL cannot reach the page.
//
// 2. Validation. Every answer is checked before it is allowed near the DOM, and
//    a failed block is re-sent with the specific reason appended. Blocks that
//    never pass keep their original HTML, so the worst outcome is an untouched
//    paragraph, not a broken one.
// ============================================================================

// A rewrite must move at least this many characters to count as an attempt.
// Catches the model echoing the source back; deliberately low, because a real
// rewrite of an already-plain sentence can legitimately be small.
const MIN_REWRITE_EDITS = 3;

const REWRITE_JSON_SCHEMA = {
    "type": "object",
    "properties": {
        "blocks": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "id": { "type": "integer" },
                    "text": { "type": "string" },
                    "links": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "i": { "type": "integer" },
                                "t": { "type": "string" }
                            },
                            "required": ["i", "t"],
                            "additionalProperties": false
                        }
                    }
                },
                "required": ["id", "text", "links"],
                "additionalProperties": false
            }
        }
    },
    "required": ["blocks"],
    "additionalProperties": false
};

// Edit distance, capped: we only ever compare it against MIN_REWRITE_EDITS, so
// bailing out once the cap is exceeded keeps long blocks O(n) instead of O(n*m).
function editDistance(a, b, cap) {
    a = String(a || ''); b = String(b || '');
    if (a === b) return 0;
    const limit = cap === undefined ? Infinity : cap;
    if (Math.abs(a.length - b.length) >= limit) return limit;
    let prev = new Array(b.length + 1);
    let curr = new Array(b.length + 1);
    for (let j = 0; j <= b.length; j++) prev[j] = j;
    for (let i = 1; i <= a.length; i++) {
        curr[0] = i;
        let rowMin = curr[0];
        const ai = a.charCodeAt(i - 1);
        for (let j = 1; j <= b.length; j++) {
            const cost = ai === b.charCodeAt(j - 1) ? 0 : 1;
            let v = prev[j] + 1;
            const del = curr[j - 1] + 1; if (del < v) v = del;
            const sub = prev[j - 1] + cost; if (sub < v) v = sub;
            curr[j] = v;
            if (v < rowMin) rowMin = v;
        }
        if (rowMin >= limit) return limit;
        const swap = prev; prev = curr; curr = swap;
    }
    return prev[b.length];
}

// Is this answer usable? Returns null when it is, or a human-readable reason
// that goes straight back to the model on the next attempt.
function validateRewriteBlock(sourceText, inventory, block) {
    if (!block || typeof block !== 'object') return 'answer is not an object';
    const text = typeof block.text === 'string' ? block.text : '';
    if (!text.trim()) return 'text is empty';
    if (!/\p{L}/u.test(text)) return 'text contains no letters';

    const links = Array.isArray(block.links) ? block.links : [];
    const expected = inventory.length;

    if (expected === 0 && links.length > 0) {
        return 'you returned links but this fragment has none';
    }

    for (const l of links) {
        if (!l || !Number.isInteger(l.i)) return 'a link is missing its inventory index "i"';
        if (l.i < 0 || l.i >= expected) {
            return `link index ${l.i} does not exist, valid range is 0..${expected - 1}`;
        }
        if (typeof l.t !== 'string' || !l.t.trim()) {
            return `link [${l.i}] has empty anchor text`;
        }
    }

    // Every link from the inventory exactly once: nothing dropped, nothing added.
    const counts = new Array(expected).fill(0);
    for (const l of links) counts[l.i]++;
    const missing = [], dupes = [];
    for (let i = 0; i < expected; i++) {
        if (counts[i] === 0) missing.push(i);
        else if (counts[i] > 1) dupes.push(i);
    }
    if (missing.length) {
        return `link(s) [${missing.join(', ')}] from the inventory are missing from your answer`;
    }
    if (dupes.length) {
        return `link(s) [${dupes.join(', ')}] are used more than once`;
    }
    if (links.length !== expected) {
        return `you returned ${links.length} links but the inventory has ${expected}`;
    }

    // The anchor text must occur in the returned text, or there is nowhere to
    // insert the <a> element.
    for (const l of links) {
        if (!text.includes(l.t)) {
            return `link text "${l.t}" does not occur in your text, so it cannot be linked`;
        }
    }

    const d = editDistance(String(sourceText || ''), text, MIN_REWRITE_EDITS);
    if (d < MIN_REWRITE_EDITS) {
        return `you returned the fragment almost unchanged (${d} character edits, at least ${MIN_REWRITE_EDITS} required)`;
    }

    return null;
}

function formatInventoryForPrompt(inventory) {
    if (!inventory || inventory.length === 0) return '';
    return '\nLinks in this fragment (return each one exactly once, as {"i": index, "t": new anchor text}):\n'
        + inventory.map((l, i) => `[${i}] "${l.text}"`).join('\n');
}

// System prompt = the style template plus the user's own instructions, which are
// appended verbatim so they can override wording, add domain rules, etc.
function buildRewriteSystemPrompt(template, targetLangName, extraInstructions) {
    const base = buildPrompt(template.system, { targetLanguage: targetLangName });
    const extra = String(extraInstructions || '').trim();
    if (!extra) return base;
    return `${base}\n\nAdditional rules from the user, follow them as well:\n${extra}`;
}

function buildRewriteUserPrompt(template, targetLangName, items, retryNotes) {
    const parts = items.map(item => {
        const note = retryNotes && retryNotes.get(item.id);
        const head = note
            ? `[${item.id}]: ${item.text}\nYour previous answer for [${item.id}] was rejected: ${note}. Fix exactly that.`
            : `[${item.id}]: ${item.text}`;
        return head + formatInventoryForPrompt(item.links);
    });
    return buildPrompt(template.user, { targetLanguage: targetLangName, texts: parts.join('\n\n') });
}

// Pull the per-block answers out of a response, tolerating the same kinds of
// mess parseTranslationResponse tolerates (code fences, prose around the JSON).
function extractRewriteBlocks(raw) {
    if (!raw) return [];
    let clean = String(raw)
        .replace(/^```json\s*/m, '')
        .replace(/^```\s*/m, '')
        .replace(/\s*```$/m, '')
        .trim();
    let parsed = null;
    try {
        parsed = JSON.parse(clean);
    } catch (e) {
        const jsonStr = extractJsonObject(clean);
        if (jsonStr) { try { parsed = JSON.parse(jsonStr); } catch (e2) { parsed = null; } }
    }
    if (!parsed) return [];
    const arr = Array.isArray(parsed.blocks) ? parsed.blocks : (Array.isArray(parsed) ? parsed : []);
    return arr.map(b => ({
        id: Number(b && b.id),
        text: String((b && b.text) || ''),
        links: Array.isArray(b && b.links)
            ? b.links.map(l => ({ i: Number(l && l.i), t: String((l && l.t) || '') }))
            : []
    })).filter(b => Number.isFinite(b.id));
}

// Rewrite a batch of blocks. Mirrors translate()'s shape so content.js can treat
// both the same way, but runs its own request/validate/retry loop.
async function rewriteBlocks(items, targetLanguage, settings) {
    const modelId = settings.selectedModel;
    if (!modelId) throw new Error('No model selected');

    let provider = settings.provider;
    if (provider === 'auto') {
        provider = await detectModelProvider(modelId, settings);
        if (!provider) throw new Error('Could not detect model provider');
    }

    const style = REWRITE_PROMPT_TEMPLATES[settings.rewriteStyle] ? settings.rewriteStyle : 'rewrite';
    const override = settings.customPrompts && settings.customPrompts[style];
    const builtin = REWRITE_PROMPT_TEMPLATES[style];
    const template = {
        system: (override && override.system) || builtin.system,
        user: (override && override.user) || builtin.user
    };
    const targetLangName = getLanguageName(targetLanguage);
    const systemPrompt = buildRewriteSystemPrompt(template, targetLangName, settings.rewriteInstructions);

    // Rewrite answers are always structured JSON: the link contract needs it.
    const wantJson = true;

    // Cache key folds in everything that shapes the answer, so changing style or
    // instructions never serves a stale rewrite. Values are JSON, unlike the
    // string values translate() stores — the two never share a key because the
    // prompt signature differs.
    const cacheEnabled = settings.cacheMode !== 'off'
        && typeof cacheGetMany === 'function' && typeof cacheKey === 'function';
    const promptSig = hashString([
        'rewrite', style, String(settings.temperature),
        systemPrompt, template.user, String(settings.maxTokensPerBatch || '')
    ].join('\u0000'));
    const keyFor = cacheEnabled
        ? (item) => cacheKey(modelId, 'rewrite', targetLanguage, promptSig,
            item.text + '\u0001' + JSON.stringify((item.links || []).map(l => l.href)))
        : (item) => item.text + '\u0001' + JSON.stringify((item.links || []).map(l => l.href));

    const results = new Map();   // id -> { text, links }
    let fromCache = 0;

    // seq = позиция группы в исходном списке; именно её видит модель в промпте.
    const groups = new Map();
    items.forEach((item, seq) => {
        const k = keyFor(item);
        const g = groups.get(k);
        if (g) g.ids.push(item.id);
        else groups.set(k, { key: k, item, ids: [item.id], seq });
    });

    if (cacheEnabled) {
        const keys = [...groups.values()].map(g => g.key);
        let hits = new Map();
        try { hits = await cacheGetMany(keys); } catch (e) { hits = new Map(); }
        for (const g of groups.values()) {
            const raw = hits.get(g.key);
            if (!raw) continue;
            let value = null;
            try { value = typeof raw === 'string' ? JSON.parse(raw) : raw; } catch (e) { value = null; }
            if (value && typeof value.text === 'string') {
                for (const id of g.ids) results.set(id, value);
                fromCache++;
            }
        }
    }

    const maxRetries = Number.isInteger(settings.maxOutputRetries) ? settings.maxOutputRetries : 2;
    const retryNotes = new Map();   // id -> reason from the previous attempt
    let pending = [...groups.values()].filter(g => !results.has(g.item.id));

    debugLog(`[Rewrite] model=${modelId} style=${style} blocks=${items.length} cached=${fromCache} pending=${pending.length}`);

    for (let attempt = 0; attempt <= maxRetries && pending.length > 0; attempt++) {
        // The prompt is numbered 0..N-1 for this request only, exactly like the
        // translation path does: a model that renumbers from zero is normal, and
        // a short run of 0..k-1 is then indistinguishable from our own ids. So we
        // send seq ids and map the answer back to the caller's ids below.
        const requestItems = pending.map((g, seq) => ({ ...g.item, id: seq }));
        const userPrompt = buildRewriteUserPrompt(template, targetLangName, requestItems, retryNotes);
        debugLog(`[Rewrite] attempt ${attempt + 1}: ${requestItems.length} block(s), seq ids ${requestItems.map(r => r.id).join(',')}`);

        let raw = null, finishReason = null;
        try {
            const res = await callProvider(provider, settings, modelId, systemPrompt, userPrompt, wantJson, REWRITE_JSON_SCHEMA);
            raw = res && res.content;
            finishReason = res && res.finishReason;
        } catch (e) {
            if (attempt === maxRetries) throw e;
            debugWarn(`[Rewrite] attempt ${attempt + 1} threw:`, e.message);
            continue;
        }

        debugLog(`[Rewrite] raw response (first 300):`, String(raw || '').slice(0, 300));
        const blocks = extractRewriteBlocks(raw);

        // A response we cannot align at all is not worth retrying verbatim: the
        // per-block retry below gives the model a cleaner, smaller task.
        if (blocks.length === 0 && requestItems.length > 1) {
            debugWarn(`[Rewrite] attempt ${attempt + 1}: unparsable answer for ${requestItems.length} blocks`
                + (finishReason === 'length' ? ' (hit the output length limit — lower maxItemsPerBatch)' : ''));
            retryNotes.clear();
            for (const g of pending) {
                retryNotes.set(g.seq, finishReason === 'length'
                    ? 'the previous batch was cut off by the output length limit'
                    : 'the previous answer could not be parsed as the requested JSON');
            }
            continue;
        }

        const byId = new Map();
        for (const b of blocks) if (!byId.has(b.id)) byId.set(b.id, b);

        // Trust the returned ids only when they are actually ours; otherwise the
        // model renumbered from zero and position is the only reliable link.
        const seqIds = requestItems.map(r => r.id);
        const returnedIds = blocks.map(b => b.id);
        const idsAreOurs = returnedIds.length > 0 && returnedIds.every(id => seqIds.includes(id));

        const stillPending = [];
        for (let pos = 0; pos < pending.length; pos++) {
            const g = pending[pos];
            const b = idsAreOurs ? byId.get(g.seq) : blocks[pos];
            const inventory = g.item.links || [];
            if (!b) {
                retryNotes.set(g.seq, 'you did not return this fragment at all');
                stillPending.push(g);
                continue;
            }
            const reason = validateRewriteBlock(g.item.text, inventory, b);
            if (reason) {
                debugWarn(`[Rewrite] block ${g.item.id} rejected: ${reason}`);
                retryNotes.set(g.seq, reason);
                stillPending.push(g);
                continue;
            }
            // Re-resolve every href from the inventory by index — the model only
            // ever supplied indexes, so a URL can neither be invented nor mangled.
            const links = b.links.map(l => {
                const src = inventory[l.i] || {};
                return { href: src.href, text: l.t, attrs: src.attrs || {} };
            });
            const value = { text: b.text, links };
            for (const id of g.ids) results.set(id, value);
            retryNotes.delete(g.seq);
        }

        pending = stillPending;
        debugLog(`[Rewrite] after attempt ${attempt + 1}: ${pending.length} block(s) still pending`);
    }

    // Blocks that never passed validation are returned with an error so
    // content.js leaves their original HTML in place.
    for (const g of pending) {
        const reason = retryNotes.get(g.seq) || 'rewrite failed validation';
        debugWarn(`[Rewrite] giving up on block ${g.item.id}: ${reason}`);
    }

    if (cacheEnabled) {
        const entries = [];
        for (const g of groups.values()) {
            const v = results.get(g.item.id);
            if (v) entries.push([g.key, JSON.stringify(v)]);
        }
        if (entries.length) {
            try { await cacheSetMany(entries); }
            catch (e) { debugWarn('[Rewrite] cache write failed:', e && e.message); }
        }
    }

    const blocksOut = items.map(item => {
        const v = results.get(item.id);
        return v ? { id: item.id, text: v.text, links: v.links }
                 : { id: item.id, error: 'rewrite failed validation' };
    });
    return { blocks: blocksOut, fromCache, total: items.length, cacheActive: cacheEnabled };
}

// ============================================================================
// Message Handler
// ============================================================================

browserAPI.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // console.log('[Background] Received message:', message.type);

    (async () => {
        try {
            const settings = await getSettings();

            switch (message.type) {
                case 'GET_SETTINGS':
                    sendResponse({ settings });
                    break;

                case 'SAVE_SETTINGS':
                    const saved = await saveSettings(message.settings);
                    sendResponse({ settings: saved });
                    break;

                case 'DETECT_PROVIDERS':
                    const providers = await detectProviders(
                        settings.ollamaUrl,
                        settings.lmstudioUrl,
                        settings.provider
                    );
                    sendResponse(providers);
                    break;

                case 'LIST_MODELS':
                    // Pass forceRefresh to bypass cache when user clicks refresh
                    const models = await listModels(settings, !message.forceRefresh);
                    sendResponse({ models });
                    break;

                case 'SYNC_CONTENT_SCRIPT': {
                    // Register or unregister based on the *current* settings, so
                    // callers only have to save their setting and ask for a sync.
                    const registered = await syncContentScriptRegistration();
                    sendResponse({ ok: true, registered });
                    break;
                }

                case 'ADD_AUTO_TRANSLATE_NEVER_SITE': {
                    // Sent from the on-page widget's "Ignore site" button.
                    const host = typeof message.hostname === 'string' ? message.hostname.trim().toLowerCase() : '';
                    if (!host) {
                        sendResponse({ ok: false });
                        break;
                    }
                    const current = await getSettings();
                    const sites = Array.isArray(current.autoTranslateNeverSites)
                        ? [...current.autoTranslateNeverSites]
                        : [];
                    if (!sites.includes(host)) sites.push(host);
                    await saveSettings({ autoTranslateNeverSites: sites });
                    sendResponse({ ok: true, sites });
                    break;
                }

                case 'REMOVE_AUTO_TRANSLATE_NEVER_SITE': {
                    // Sent from the popup's "Un-ignore it" link.
                    const host = typeof message.hostname === 'string' ? message.hostname.trim().toLowerCase() : '';
                    if (!host) {
                        sendResponse({ ok: false });
                        break;
                    }
                    const current = await getSettings();
                    const sites = (Array.isArray(current.autoTranslateNeverSites) ? current.autoTranslateNeverSites : [])
                        .filter(s => s !== host);
                    await saveSettings({ autoTranslateNeverSites: sites });
                    sendResponse({ ok: true, sites });
                    break;
                }

                case 'GET_MODEL_STATE': {
                    if (!settings.selectedModel) { sendResponse({ state: null }); break; }
                    const provider = await detectModelProvider(settings.selectedModel, settings);
                    if (provider !== 'lmstudio') { sendResponse({ state: null }); break; }
                    const state = await getLMStudioModelState(settings.lmstudioUrl, settings.selectedModel);
                    sendResponse({ state });
                    break;
                }

                case 'TRANSLATE':
                    // Pass sourceLanguage for TranslateGemma support
                    let settingsWithSource = {
                        ...settings,
                        sourceLanguage: message.sourceLanguage || settings.sourceLanguage || 'en'
                    };

                    // WARNING LOG: Check if source language is missing or 'auto'
                    if (!settingsWithSource.sourceLanguage || settingsWithSource.sourceLanguage === 'auto') {
                        console.warn('[Background] WARNING: Source language is "auto" or missing. Some models (like TranslateGemma) require a specific source language code to function correctly.');
                    }

                    // Auto-detect model if none selected (e.g. fresh install, providers not ready at install time)
                    if (!settingsWithSource.selectedModel) {
                        await autoDetectAndSelectModel();
                        const refreshed = await getSettings();
                        settingsWithSource = {
                            ...settingsWithSource,
                            selectedModel: refreshed.selectedModel,
                            provider: refreshed.provider,
                            requestFormat: refreshed.requestFormat
                        };
                    }

                    const result = await translate(
                        message.texts,
                        message.targetLanguage,
                        settingsWithSource
                    );
                    sendResponse({
                        translations: result.translations,
                        fromCache: result.fromCache,
                        total: result.total,
                        cacheActive: result.cacheActive
                    });
                    break;

                case 'REWRITE_BLOCKS': {
                    let rwSettings = { ...settings };
                    if (!rwSettings.selectedModel) {
                        await autoDetectAndSelectModel();
                        const refreshed = await getSettings();
                        rwSettings = {
                            ...rwSettings,
                            selectedModel: refreshed.selectedModel,
                            provider: refreshed.provider
                        };
                    }
                    const rwResult = await rewriteBlocks(
                        message.blocks || [],
                        message.targetLanguage,
                        rwSettings
                    );
                    sendResponse(rwResult);
                    break;
                }

                case 'GET_PAGE_CACHE': {
                    try {
                        const raw = await pageGet(message.url || '');
                        sendResponse({ data: raw || null });
                    } catch (e) {
                        sendResponse({ data: null, error: e && e.message });
                    }
                    break;
                }

                case 'SAVE_PAGE_CACHE': {
                    try {
                        await pageSet(message.url || '', message.data);
                        sendResponse({ ok: true });
                    } catch (e) {
                        sendResponse({ ok: false, error: e && e.message });
                    }
                    break;
                }

                case 'CLEAR_PAGE_CACHE': {
                    try {
                        const ok = await pageDelete(message.url || '');
                        sendResponse({ ok: !!ok });
                    } catch (e) {
                        sendResponse({ ok: false, error: e && e.message });
                    }
                    break;
                }

                case 'CLEAR_CACHE':
                    try {
                        await cacheClear();
                        await pageClear();
                        sendResponse({ ok: true });
                    } catch (e) {
                        sendResponse({ ok: false, error: e && e.message });
                    }
                    break;

                case 'CACHE_COUNT':
                    try {
                        sendResponse({ count: await cacheCount() });
                    } catch (e) {
                        sendResponse({ count: 0, error: e && e.message });
                    }
                    break;

                case 'CACHE_BACKEND':
                    try {
                        sendResponse({ persistent: await cachePersistentAvailable() });
                    } catch (e) {
                        sendResponse({ persistent: false, error: e && e.message });
                    }
                    break;

                case 'SAVE_GLOSSARY': {
                    // entries: Array<[source, target]> already parsed by the options page.
                    const entries = Array.isArray(message.entries) ? message.entries : [];
                    const meta = {
                        name: typeof message.name === 'string' ? message.name : '',
                        // Target language declared by a '#target: xx' line in the
                        // TSV; '' means the glossary applies to any target language.
                        target: typeof message.target === 'string' ? message.target.split('-')[0].toLowerCase() : '',
                        loadedAt: Date.now()
                    };
                    await browserAPI.storage.local.set({ [GLOSSARY_KEY]: entries, [GLOSSARY_META_KEY]: meta });
                    invalidateGlossary();
                    // Glossary changes the output for the same source text — drop stale cache.
                    if (typeof cacheClear === 'function') await cacheClear();
                    sendResponse({ ok: true, count: entries.length });
                    break;
                }

                case 'GET_GLOSSARY_INFO': {
                    const entries = await loadGlossary();
                    let meta = null;
                    try {
                        const result = await browserAPI.storage.local.get(GLOSSARY_META_KEY);
                        meta = result[GLOSSARY_META_KEY] || null;
                    } catch (e) { /* meta is cosmetic — count/preview still work */ }
                    sendResponse({
                        count: entries.length,
                        name: meta && meta.name || '',
                        target: meta && meta.target || '',
                        loadedAt: meta && meta.loadedAt || null,
                        // First rows only: enough to eyeball the dictionary without
                        // shipping tens of thousands of pairs to the options page.
                        preview: entries.slice(0, GLOSSARY_PREVIEW_MAX)
                    });
                    break;
                }

                case 'GET_GLOSSARY_ENTRIES': {
                    // Full dictionary, for the inline editor. GET_GLOSSARY_INFO's
                    // preview is truncated and must never be used as the editor's
                    // working copy — saving it back would drop every term past
                    // GLOSSARY_PREVIEW_MAX.
                    const entries = await loadGlossary();
                    let meta = null;
                    try {
                        const result = await browserAPI.storage.local.get(GLOSSARY_META_KEY);
                        meta = result[GLOSSARY_META_KEY] || null;
                    } catch (e) { /* meta is cosmetic */ }
                    sendResponse({
                        entries,
                        name: meta && meta.name || '',
                        target: meta && meta.target || ''
                    });
                    break;
                }

                case 'CLEAR_GLOSSARY':
                    await browserAPI.storage.local.remove([GLOSSARY_KEY, GLOSSARY_META_KEY]);
                    invalidateGlossary();
                    if (typeof cacheClear === 'function') await cacheClear();
                    sendResponse({ ok: true });
                    break;

                default:
                    sendResponse({ error: 'Unknown message type' });
            }
        } catch (e) {
            console.error('[Background] Error:', e);
            sendResponse({ error: e.message });
        }
    })();

    return true; // Keep the message channel open for async response
});

// On browser startup, wipe the translation cache if the user chose the
// 'session' mode (keep until the browser closes). onStartup fires when the
// profile launches but not on extension reload/update, so within-session
// worker restarts don't lose the cache — only a real browser restart does.
browserAPI.runtime.onStartup.addListener(async () => {
    try {
        const settings = await getSettings();
        if (settings.cacheMode === 'session' && typeof cacheClear === 'function') {
            await cacheClear();
        }
    } catch (e) {
        // Best-effort; a failed clear just leaves the previous session's cache.
    }
});

// ============================================================================
// Context Menu
// ============================================================================

browserAPI.runtime.onInstalled.addListener(async () => {
    browserAPI.contextMenus.create({
        id: "translate-page",
        title: "Translate Page",
        contexts: ["page"]
    }, () => { if (browserAPI.runtime.lastError) {} });

    browserAPI.contextMenus.create({
        id: "translate-selection",
        title: "Translate Selection",
        contexts: ["selection"]
    }, () => { if (browserAPI.runtime.lastError) {} });

    // Auto-detect and select a model on fresh install (when none is configured yet)
    await autoDetectAndSelectModel();

    // Re-register content script auto-injection if a feature still needs it.
    // registerContentScripts() registrations are cleared on extension update/reinstall.
    await syncContentScriptRegistration();
});

browserAPI.contextMenus.onClicked.addListener(async (info, tab) => {
    if (info.menuItemId === "translate-page") {
        if (!tab || !tab.id) return;

        try {
            const settings = await getSettings();

            // Resolve source language - if 'auto', try to detect it programmatically
            let sourceLang = settings.sourceLanguage;
            if (!sourceLang || sourceLang === 'auto') {
                try {
                    const result = await browserAPI.scripting.executeScript({
                        target: { tabId: tab.id },
                        func: () => {
                            const htmlLang = document.documentElement.lang || document.querySelector('html')?.getAttribute('lang');
                            if (htmlLang) return htmlLang.split('-')[0].toLowerCase();
                            const metaLang = document.querySelector('meta[http-equiv="content-language"]')?.getAttribute('content');
                            if (metaLang) return metaLang.split('-')[0].toLowerCase();
                            return null;
                        }
                    });
                    if (result && result[0] && result[0].result) {
                        sourceLang = result[0].result;
                        console.log(`[Background] Detected page language for context menu: ${sourceLang}`);
                    }
                } catch (detectErr) {
                    console.log('[Background] Could not detect language from background:', detectErr);
                }
            }

            // Helper to send message
            const sendTranslationMessage = async () => {
                await browserAPI.tabs.sendMessage(tab.id, {
                    type: 'START_TRANSLATION',
                    targetLanguage: settings.targetLanguage,
                    sourceLanguage: sourceLang || 'auto', // Use detected or fall back to auto
                    showGlow: settings.showGlow,
                    maxConcurrentRequests: settings.maxConcurrentRequests || 4,
                    maxItemsPerBatch: settings.maxItemsPerBatch || 8,
                    outputMode: settings.outputMode,
                    rewriteScope: settings.rewriteScope
                });
            };

            try {
                await sendTranslationMessage();
            } catch (e) {
                console.log('[Background] Initial translation connection failed, attempting injection:', e);

                // If message failed, content script might not be loaded. Inject it.
                await browserAPI.scripting.executeScript({
                    target: { tabId: tab.id },
                    files: ['content.js']
                });

                // Wait briefly for script to initialize
                await new Promise(resolve => setTimeout(resolve, 200));

                // Retry message
                await sendTranslationMessage();
            }

        } catch (e) {
            console.error('[Background] Context menu translation failed:', e);
        }
    } else if (info.menuItemId === "translate-selection") {
        if (!tab || !tab.id) return;

        try {
            const settings = await getSettings();

            let sourceLang = settings.sourceLanguage;
            if (!sourceLang || sourceLang === 'auto') {
                try {
                    const result = await browserAPI.scripting.executeScript({
                        target: { tabId: tab.id },
                        func: () => {
                            const htmlLang = document.documentElement.lang || document.querySelector('html')?.getAttribute('lang');
                            if (htmlLang) return htmlLang.split('-')[0].toLowerCase();
                            const metaLang = document.querySelector('meta[http-equiv="content-language"]')?.getAttribute('content');
                            if (metaLang) return metaLang.split('-')[0].toLowerCase();
                            return null;
                        }
                    });
                    if (result?.[0]?.result) sourceLang = result[0].result;
                } catch (detectErr) { /* ignore */ }
            }

            const sendSelectionMessage = async () => {
                await browserAPI.tabs.sendMessage(tab.id, {
                    type: 'TRANSLATE_SELECTION',
                    targetLanguage: settings.targetLanguage,
                    sourceLanguage: sourceLang || 'auto',
                    showGlow: settings.showGlow,
                    maxConcurrentRequests: settings.maxConcurrentRequests || 4
                });
            };

            try {
                await sendSelectionMessage();
            } catch (e) {
                await browserAPI.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
                await new Promise(resolve => setTimeout(resolve, 200));
                await sendSelectionMessage();
            }

        } catch (e) {
            console.error('[Background] Context menu selection translation failed:', e);
        }
    }
});

// Initialize settings on startup
loadSettings().then(() => {
    console.log('[Background] Local LLM Translator background script loaded');
});
