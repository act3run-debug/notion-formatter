#!/bin/sh
# Прогон всех тестов. Любой провал даёт ненулевой код возврата.
cd "$(dirname "$0")" || exit 1
status=0
for f in contracts.test.js background.test.js dom.test.js; do
    node "$f" || status=1
done
exit $status
