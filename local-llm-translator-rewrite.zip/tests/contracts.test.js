// Контрактные тесты: проверяют связи между файлами расширения.
// Именно здесь ломается «самая база» — сообщения без обработчика, настройка без
// поля в интерфейсе, id без элемента в HTML, глобальная функция без экспорта.
const { group, test, summary, ok, eq, includes, notIncludes } = require('./helper');
const { ROOT, read, loadBackground, loadContent, el } = require('./loader');
const fs = require('fs');
const path = require('path');

const contentSrc = read('content.js');
const backgroundSrc = read('background.js');
const popupSrc = read('popup/popup.js');
const optionsSrc = read('options/options.js');
const translatorSrc = read('translator/translator.js');

function messageTypesSent(src) {
    return new Set([...src.matchAll(/type:\s*'([A-Z_]+)'/g)].map(m => m[1]));
}
function messageTypesHandled(src) {
    return new Set([...src.matchAll(/case\s+'([A-Z_]+)'/g)].map(m => m[1]));
}

// ---------------------------------------------------------------- 1. Слушатель
group('content.js: приём сообщений');

test('слушатель runtime.onMessage зарегистрирован ровно один', () => {
    const { browser } = loadContent({ page: el('body') });
    eq(browser.__listeners.runtime.length, 1, 'количество слушателей');
});

// Регрессия: async-слушатель в Firefox возвращает Promise, канал остаётся
// открытым, и sendResponse не доходит до отправителя — PING зависает.
test('слушатель НЕ асинхронный (регрессия «Could not connect to page»)', () => {
    const { browser } = loadContent({ page: el('body') });
    const fn = browser.__listeners.runtime[0];
    eq(fn.constructor.name, 'Function', 'constructor.name');
    notIncludes(contentSrc, 'onMessage.addListener(async', 'async-слушатель в исходнике');
});

test('await не встречается внутри обработчика сообщений', () => {
    const start = contentSrc.indexOf('browserAPI.runtime.onMessage.addListener((message, sender, sendResponse)');
    ok(start > 0, 'не найден заголовок обработчика');
    // грубо, но достаточно: от заголовка до закрывающей "});" того же уровня
    const body = contentSrc.slice(start, contentSrc.indexOf('\n});', start));
    // 8 пробелов = уровень веток switch. Всё, что глубже, лежит внутри async-IIFE.
    const awaits = [...body.matchAll(/^ {8}await /gm)];
    eq(awaits.length, 0, 'await на уровне ветки switch (должен быть внутри async-IIFE)');
});

test('PING отвечает синхронно, до возврата из слушателя', () => {
    const { browser } = loadContent({ page: el('body') });
    const listener = browser.__listeners.runtime[0];
    let response;
    const ret = listener({ type: 'PING' }, {}, (r) => { response = r; });
    ok(response, 'sendResponse не вызван синхронно');
    eq(response.pong, true, 'pong');
    ok(ret === true || ret === undefined,
        `слушатель вернул ${typeof ret}: допустимы только true (как в оригинале) или undefined, не Promise`);
});

// ------------------------------------------------------------ 2. Сообщения
group('Сообщения между частями расширения');

const bgHandles = messageTypesHandled(backgroundSrc);
const contentHandles = messageTypesHandled(contentSrc);

// Сообщения, которые отправляются намеренно «в никуда»: уведомление о завершении,
// его никто не слушает (в оригинальном расширении так же).
const FIRE_AND_FORGET = new Set(['TRANSLATION_COMPLETE']);

// transport имеет значение: tabs.sendMessage идёт в content.js, runtime.sendMessage — в background.
function runtimeMessages(src) {
    return new Set([...src.matchAll(/runtime\.sendMessage\(\{\s*type:\s*'([A-Z_]+)'/g)].map(m => m[1]));
}
function tabMessages(src) {
    return new Set([...src.matchAll(/tabs\.sendMessage\([^,]+,\s*\{\s*type:\s*'([A-Z_]+)'/g)].map(m => m[1]));
}

test('все runtime-сообщения попапа имеют обработчик в background', () => {
    const sent = runtimeMessages(popupSrc);
    ok(sent.size > 0, 'не найдено ни одного runtime-сообщения из попапа');
    for (const type of sent) {
        if (FIRE_AND_FORGET.has(type)) continue;
        ok(bgHandles.has(type), `background.js не обрабатывает ${type}`);
    }
});

test('все tabs-сообщения попапа имеют обработчик в content.js', () => {
    const sent = tabMessages(popupSrc);
    ok(sent.size > 0, 'не найдено ни одного tabs-сообщения из попапа');
    for (const type of sent) {
        if (FIRE_AND_FORGET.has(type)) continue;
        ok(contentHandles.has(type), `content.js не обрабатывает ${type}`);
    }
});

test('все runtime-сообщения content.js имеют обработчик в background', () => {
    const sent = [...runtimeMessages(contentSrc)];
    ok(sent.length > 0, 'не найдено ни одного исходящего сообщения');
    for (const type of sent) {
        if (FIRE_AND_FORGET.has(type)) continue;
        ok(bgHandles.has(type), `background.js не обрабатывает ${type}`);
    }
});

test('сообщения background.js в content.js имеют обработчик', () => {
    const sent = [...backgroundSrc.matchAll(/tabs\.sendMessage\([^,]+,\s*\{\s*type:\s*'([A-Z_]+)'/g)].map(m => m[1]);
    for (const type of sent) ok(contentHandles.has(type), `content.js не обрабатывает ${type}`);
});

test('обработчики REWRITE_BLOCKS и кэша страницы на месте', () => {
    for (const t of ['REWRITE_BLOCKS', 'GET_PAGE_CACHE', 'SAVE_PAGE_CACHE', 'CLEAR_PAGE_CACHE']) {
        ok(bgHandles.has(t), `background.js: нет case '${t}'`);
    }
    ok(contentHandles.has('CLEAR_PAGE_CACHE'), 'content.js: нет case CLEAR_PAGE_CACHE');
});

test('popup передаёт режим переписи в START_TRANSLATION', () => {
    const i = popupSrc.indexOf("type: 'START_TRANSLATION'");
    const call = popupSrc.slice(i, i + 500);
    includes(call, 'outputMode:', 'outputMode');
    includes(call, 'rewriteScope:', 'rewriteScope');
    includes(call, 'maxItemsPerBatch:', 'maxItemsPerBatch');
});

test('content.js читает то, что передаёт popup', () => {
    includes(contentSrc, 'message.outputMode', 'outputMode');
    includes(contentSrc, 'message.rewriteScope', 'rewriteScope');
    includes(contentSrc, 'message.maxItemsPerBatch', 'maxItemsPerBatch');
});

// ------------------------------------------------------------ 3. Настройки
group('Настройки');

function defaultsObject(src) {
    const i = src.indexOf('const DEFAULT_SETTINGS = {');
    ok(i >= 0, 'DEFAULT_SETTINGS не найден');
    const open = src.indexOf('{', i);
    let depth = 0, close = -1;
    for (let k = open; k < src.length; k++) {
        if (src[k] === '{') depth++;
        else if (src[k] === '}') { depth--; if (depth === 0) { close = k; break; } }
    }
    ok(close > open, 'не удалось найти конец DEFAULT_SETTINGS');
    const body = src.slice(open, close + 1);

    return new Set([...body.matchAll(/^\s{4}([A-Za-z_$][\w$]*)\s*:/gm)].map(m => m[1]));
}

const bgDefaults = defaultsObject(backgroundSrc);
const popupDefaults = defaultsObject(popupSrc);
const optionsDefaults = defaultsObject(optionsSrc);

test('popup знает все ключи настроек из background', () => {
    const missing = [...bgDefaults].filter(k => !popupDefaults.has(k));
    eq(missing.join(', '), '', 'в popup.js DEFAULT_SETTINGS отсутствуют');
});

test('options знает все ключи настроек из background', () => {
    const missing = [...bgDefaults].filter(k => !optionsDefaults.has(k));
    eq(missing.join(', '), '', 'в options.js DEFAULT_SETTINGS отсутствуют');
});

test('режим переписи включён по умолчанию', () => {
    const bg = loadBackground();
    eq(bg.DEFAULT_SETTINGS.outputMode, 'rewrite', 'outputMode');
    eq(bg.DEFAULT_SETTINGS.rewriteScope, 'block', 'rewriteScope');
    eq(bg.DEFAULT_SETTINGS.rewriteStyle, 'rewrite_detranslate', 'rewriteStyle');
    ok(bg.DEFAULT_SETTINGS.settingsVersion >= 2, 'settingsVersion должен расти при смене дефолтов');
});

test('все настройки, которые читает rewrite, объявлены в дефолтах', () => {
    for (const key of ['outputMode', 'rewriteStyle', 'rewriteScope', 'rewriteInstructions',
        'persistRewrites', 'maxItemsPerBatch', 'maxOutputRetries', 'cacheMode', 'temperature']) {
        ok(bgDefaults.has(key), `в DEFAULT_SETTINGS нет ${key}`);
    }
});

test('настройки переписи сохраняются из интерфейса', () => {
    for (const key of ['outputMode', 'rewriteStyle', 'rewriteScope', 'rewriteInstructions', 'persistRewrites']) {
        includes(optionsSrc, key + ':', `options.js не сохраняет ${key}`);
    }
});

// ------------------------------------------------------------ 4. HTML/JS
group('Элементы интерфейса');

function idsInHtml(rel) {
    let h = read(rel);
    h = h.replace(/<script[\s\S]*?<\/script>/g, '');
    return new Set([...h.matchAll(/id="([^"]+)"/g)].map(m => m[1]));
}
function idsInJs(rel) {
    return new Set([...read(rel).matchAll(/getElementById\('([^']+)'\)/g)].map(m => m[1]));
}

// Элементы, которые создаются кодом во время работы, а не лежат в разметке.
const CREATED_AT_RUNTIME = new Set(['setup-banner']);

for (const [js, html] of [['popup/popup.js', 'popup/popup.html'],
                          ['options/options.js', 'options/options.html'],
                          ['translator/translator.js', 'translator/translator.html']]) {
    test(`${js}: каждый getElementById имеет элемент в ${path.basename(html)}`, () => {
        const have = idsInHtml(html);
        const missing = [...idsInJs(js)].filter(id => !have.has(id) && !CREATED_AT_RUNTIME.has(id));
        eq(missing.join(', '), '', 'нет элемента с id');
    });
}

test('поля режима переписи существуют в options.html', () => {
    const have = idsInHtml('options/options.html');
    for (const id of ['outputModeSelect', 'rewriteStyleSelect', 'rewriteScopeSelect',
        'rewriteInstructions', 'persistRewrites', 'maxOutputRetries']) {
        ok(have.has(id), `в options.html нет #${id}`);
    }
});

test('переключатель режима и сброс кэша существуют в popup.html', () => {
    const have = idsInHtml('popup/popup.html');
    for (const id of ['outputModeSelect', 'clearPageBtn']) ok(have.has(id), `в popup.html нет #${id}`);
});

// ------------------------------------------------------------ 5. manifest
group('manifest.json');

const manifest = JSON.parse(read('manifest.json'));

test('все объявленные файлы существуют', () => {
    const files = [
        ...manifest.background.scripts,
        manifest.action.default_popup,
        manifest.options_ui.page,
        ...(manifest.web_accessible_resources || []).flatMap(r => r.resources)
    ];
    for (const f of files) {
        const rel = f.replace(/^\//, '');
        ok(fs.existsSync(path.join(ROOT, rel)), `нет файла ${rel}`);
    }
});

test('доступ к обычным сайтам разрешён постоянно', () => {
    includes(manifest.host_permissions, '<all_urls>', 'host_permissions');
    eq((manifest.optional_host_permissions || []).length, 0,
        'optional_host_permissions должен быть пуст: иначе право отзывается при выключении тумблеров');
});

test('доступ к локальному эндпоинту модели разрешён', () => {
    ok(manifest.host_permissions.some(p => p.includes('127.0.0.1')), '127.0.0.1');
    ok(manifest.host_permissions.some(p => p.includes('localhost')), 'localhost');
});

test('нужные разрешения объявлены', () => {
    for (const p of ['storage', 'scripting', 'activeTab']) includes(manifest.permissions, p, p);
});

// ------------------------------------------------------------ 6. Глобальные функции
group('Общие функции между файлами');

test('background находит всё, что объявляют languages.js и cache.js', () => {
    const bg = loadBackground();
    for (const fn of ['PLAIN_TEXT_FORMATS', 'resolveRequestFormat', 'detectRequestFormat', 'getLanguageName',
        'cacheKey', 'cacheGetMany', 'cacheSetMany', 'cacheClear', 'pageGet', 'pageSet', 'pageDelete', 'pageClear', 'pageKey']) {
        ok(bg[fn] !== undefined, `не экспортировано из languages.js/cache.js: ${fn}`);
    }
});

test('в content.js нет вызовов неопределённых общих функций', () => {
    // функции, которые content.js ожидает от background-контекста или объявляет сам
    const used = new Set([...contentSrc.matchAll(/\b(cacheKey|cacheGetMany|cacheSetMany|pageGet|pageSet|pageDelete|pageKey|resolveRequestFormat|PLAIN_TEXT_FORMATS|getLanguageName)\s*\(/g)].map(m => m[1]));
    for (const fn of used) ok(contentSrc.includes(`function ${fn}`), `content.js вызывает ${fn}, но не объявляет и не получает его`);
});

// ------------------------------------------------------------ 7. Промпты и схемы
group('Шаблоны промптов и схемы ответа');

function templateVars(tpl) {
    return new Set([...`${tpl.system}\n${tpl.user}`.matchAll(/\{\{(\w+)\}\}/g)].map(m => m[1]));
}

test('все переменные шаблонов перевода подставляются', () => {
    const bg = loadBackground();
    const supplied = ['targetLanguage', 'sourceLang', 'sourceCode', 'targetLang', 'targetCode', 'texts'];
    for (const [name, tpl] of Object.entries(bg.PROMPT_TEMPLATES)) {
        for (const v of templateVars(tpl)) includes(supplied, v, `PROMPT_TEMPLATES.${name}: не подставляется {{${v}}}`);
    }
});

test('все переменные шаблонов переписи подставляются', () => {
    const bg = loadBackground();
    for (const [name, tpl] of Object.entries(bg.REWRITE_PROMPT_TEMPLATES)) {
        for (const v of templateVars(tpl)) {
            ok(v === 'targetLanguage' || v === 'texts', `REWRITE_PROMPT_TEMPLATES.${name}: неизвестная {{${v}}}`);
        }
    }
});

test('шаблоны переписи требуют правильный формат ответа', () => {
    const bg = loadBackground();
    for (const [name, tpl] of Object.entries(bg.REWRITE_PROMPT_TEMPLATES)) {
        includes(tpl.system, '"blocks"', `${name}: не упомянут ключ blocks`);
        includes(tpl.system, '"links"', `${name}: не упомянут links`);
        includes(tpl.system, 'exactly once', `${name}: нет требования вернуть каждую ссылку один раз`);
    }
});

test('стили переписи совпадают в background.js и options.js', () => {
    const bg = loadBackground();
    const optStyles = new Set([...optionsSrc.matchAll(/^\s{4}(rewrite\w*): \{/gm)].map(m => m[1]));
    for (const name of Object.keys(bg.REWRITE_PROMPT_TEMPLATES)) {
        ok(optStyles.has(name), `в options.js нет стиля ${name}`);
    }
});

test('схемы JSON описывают обязательные поля', () => {
    const bg = loadBackground();
    const item = bg.REWRITE_JSON_SCHEMA.properties.blocks.items;
    eq(item.required.join(','), 'id,text,links', 'required у блока');
    eq(item.properties.links.items.required.join(','), 'i,t', 'required у ссылки');
    eq(bg.TRANSLATION_JSON_SCHEMA.properties.translations.items.required.join(','), 'id,text', 'required у перевода');
});

test('ключ переопределения промпта разделяет режимы', () => {
    const bg = loadBackground();
    eq(bg.promptOverrideKey('translate', 'translategemma', null), 'translategemma', 'translate');
    eq(bg.promptOverrideKey('rewrite', 'default', 'rewrite_explain'), 'rewrite_explain', 'rewrite');
});

summary();
