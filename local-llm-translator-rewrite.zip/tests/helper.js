// Minimal test helper: no dependencies, no test framework.
// Every test file calls test()/assert* and finishes with summary().
let passed = 0;
let failed = 0;
const failures = [];
const pending = [];
let currentGroup = '';

function group(name) {
    currentGroup = name;
    console.log(`\n=== ${name} ===`);
}

function test(name, fn) {
    const group_ = currentGroup;
    let r;
    try {
        r = fn();
    } catch (e) {
        failed++; failures.push(`${group_} / ${name}: ${e && e.message}`);
        console.log(`  FAIL ${name}\n         ${e && e.message}`);
        return Promise.resolve();
    }
    if (r && typeof r.then === 'function') {
        const p = r.then(
            () => { passed++; console.log(`  ok   ${name}`); },
            (e) => { failed++; failures.push(`${group_} / ${name}: ${e && e.message}`); console.log(`  FAIL ${name}\n         ${e && e.message}`); }
        );
        pending.push(p);
        return p;
    }
    passed++;
    console.log(`  ok   ${name}`);
    return Promise.resolve();
}

function fail(msg) { throw new Error(msg); }
function ok(cond, msg) { if (!cond) fail(msg || 'expected truthy'); }
function eq(actual, expected, msg) {
    if (actual !== expected) fail(`${msg || 'not equal'}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
}
function deepEq(actual, expected, msg) {
    const a = JSON.stringify(actual), b = JSON.stringify(expected);
    if (a !== b) fail(`${msg || 'not deep-equal'}: expected ${b}, got ${a}`);
}
function includes(haystack, needle, msg) {
    if (!haystack || haystack.indexOf(needle) < 0) fail(`${msg || 'missing'}: ${JSON.stringify(needle)}`);
}
function notIncludes(haystack, needle, msg) {
    if (haystack && haystack.indexOf(needle) >= 0) fail(`${msg || 'unexpectedly present'}: ${JSON.stringify(needle)}`);
}

function summary() {
    return Promise.all(pending).then(print);
}

function print() {
    console.log(`\n${'-'.repeat(60)}`);
    console.log(`_passed: ${passed}, failed: ${failed}`);
    if (failures.length) {
        console.log('\nПровалы:');
        failures.forEach(f => console.log('  • ' + f));
    }
    console.log(`${'-'.repeat(60)}`);
    process.exitCode = failed ? 1 : 0;
    return failed === 0;
}

module.exports = { group, test, summary, fail, ok, eq, deepEq, includes, notIncludes };
