// Loads the extension's scripts into a VM sandbox with stubs, so tests can call
// real code instead of a copy of it.
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { el, makeDocument, makeWindow, createBrowserStub } = require('./dom_stub');

const ROOT = path.resolve(__dirname, '..');

function read(rel) { return fs.readFileSync(path.join(ROOT, rel), 'utf8'); }

// Generic proxy-based API mock for scripts that only need "something callable".
function looseApi(tag) {
    const f = async () => ({});
    f.addListener = () => {}; f.removeListener = () => {}; f.hasListener = () => false;
    f.getValue = () => ''; f.setValue = () => {}; f.init = () => {}; f.onChange = null;
    return new Proxy(f, {
        get(t, k) {
            if (k === Symbol.toPrimitive || k === 'toString') return () => tag;
            if (k === 'then') return undefined;
            if (k in t) return t[k];
            return looseApi(`${tag}.${String(k)}`);
        }
    });
}

/**
 * Load languages.js + cache.js + background.js. Returns the sandbox, where every
 * top-level const/function of those files is reachable as a property.
 * `fetchImpl` replaces network access, so provider calls can be driven end to end.
 */
function loadBackground({ fetchImpl, storage } = {}) {
    // Хранилище — настоящий объект, а не прокси: тесты настроек читают и пишут его.
    const realStore = storage || {};
    const realStorage = {
        onChanged: { addListener() {}, removeListener() {}, hasListener: () => false },
        local: {
            get: async (k) => (typeof k === 'string' ? { [k]: realStore[k] } : { ...realStore }),
            set: async (obj) => { Object.assign(realStore, obj); },
            remove: async (k) => { delete realStore[k]; },
            clear: async () => { for (const k of Object.keys(realStore)) delete realStore[k]; }
        }
    };
    const sandbox = {
        console,
        window: { document: { addEventListener() {} } },
        setTimeout, clearTimeout, setInterval, clearInterval,
        fetch: fetchImpl || (() => { throw new Error('fetch not stubbed'); }),
        AbortController, AbortSignal,
        browser: looseApi('browser'),
        chrome: looseApi('chrome'),
        crypto: { subtle: {}, randomUUID: () => 'uuid' },
        TextEncoder, TextDecoder, URL, navigator: {},
        location: { href: 'moz-extension://test/background.js' },
        indexedDB: undefined
    };
    sandbox.globalThis = sandbox;
    sandbox.self = sandbox;      // cache.js exports onto `self`
    sandbox.browser.storage = realStorage;
    sandbox.browserAPI = sandbox.browser;
    sandbox.__store = realStore;
    vm.createContext(sandbox);
    // Top-level const/let of a VM script do not become sandbox properties, so the
    // bundle ends with an explicit export of everything tests need to reach.
    const src = ['languages.js', 'cache.js', 'background.js'].map(read).join('\n;\n') + `
;Object.assign(globalThis, {
    DEFAULT_SETTINGS, SETTINGS_VERSION, PRESERVED_ACROSS_DEFAULTS,
    PROMPT_TEMPLATES, REWRITE_PROMPT_TEMPLATES, REWRITE_JSON_SCHEMA, TRANSLATION_JSON_SCHEMA,
    MIN_REWRITE_EDITS,
    editDistance, validateRewriteBlock, extractRewriteBlocks, formatInventoryForPrompt,
    buildRewriteSystemPrompt, buildRewriteUserPrompt, promptOverrideKey,
    buildPrompt, formatTextsForPrompt, cleanTranslationText, isSuspiciousTranslation,
    // cacheGetMany / cacheSetMany намеренно НЕ экспортируются: они и так видны как
    // свойства глобального объекта (cache.js кладёт их в self), а тесты их подменяют.
    parseTranslationResponse, normalizeServerUrl, hashString, rewriteBlocks, translate,
    loadSettings, saveSettings, getSettings,
    PLAIN_TEXT_FORMATS, resolveRequestFormat, detectRequestFormat, getLanguageName,
    cacheKey, pageKey
});`;
    vm.runInContext(src, sandbox, { filename: 'background-bundle.js' });
    return sandbox;
}

/**
 * Load content.js against a stubbed page. Returns { sandbox, document, browser }.
 * Runtime message listeners registered by content.js land in browser.__listeners.
 */
function loadContent({ page, handlers } = {}) {
    const document = makeDocument(page);
    const window = makeWindow(document);
    const browser = createBrowserStub(handlers);
    const sandbox = {
        console,
        document,
        window,
        location: window.location,
        browser,
        chrome: browser,
        navigator: { userAgent: 'test' },
        NodeFilter: window.NodeFilter,
        MutationObserver: window.MutationObserver,
        requestAnimationFrame: window.requestAnimationFrame,
        setTimeout, clearTimeout, setInterval, clearInterval,
        fetch: () => { throw new Error('fetch not stubbed in content tests'); },
        URL, TextEncoder, TextDecoder,
        getComputedStyle: window.getComputedStyle,
        alert() {}
    };
    sandbox.globalThis = sandbox;
    sandbox.self = sandbox;
    sandbox.browserAPI = browser;
    vm.createContext(sandbox);
    vm.runInContext(read('content.js'), sandbox, { filename: 'content.js' });
    return { sandbox, document, browser, window };
}

module.exports = { ROOT, read, loadBackground, loadContent, looseApi, el, makeDocument, makeWindow, createBrowserStub };
