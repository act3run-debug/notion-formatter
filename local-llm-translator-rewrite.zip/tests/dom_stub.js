// Minimal DOM and WebExtension API stubs — enough to load content.js and drive
// the block-rewrite code paths. Deliberately small: the goal is to catch wiring
// mistakes, not to reimplement a browser.

class ClassList {
    constructor() { this.s = new Set(); }
    static from(str) { const c = new ClassList(); String(str || '').split(/\s+/).filter(Boolean).forEach(x => c.s.add(x)); return c; }
    add(...c) { c.forEach(x => this.s.add(x)); }
    remove(...c) { c.forEach(x => this.s.delete(x)); }
    contains(c) { return this.s.has(c); }
    toggle(c, force) {
        const want = force === undefined ? !this.s.has(c) : !!force;
        if (want) this.s.add(c); else this.s.delete(c);
        return want;
    }
    item(i) { return [...this.s][i] || null; }
    toString() { return this.value; }
    get value() { return [...this.s].join(' '); }
}

class Node {
    constructor() { this.childNodes = []; this.parentNode = null; this.nodeType = 1; }
    get parentElement() { let n = this.parentNode; while (n && n.nodeType !== 1) n = n.parentNode; return n; }
    get textContent() {
        if (this.nodeType === 3) return this.data;
        return this.childNodes.map(c => c.textContent).join('');
    }
    set textContent(v) {
        if (this.nodeType === 3) { this.data = String(v); return; }
        this.childNodes.forEach(c => { c.parentNode = null; });
        this.childNodes = [];
        if (v !== '') this.appendChild(new Text(String(v)));
    }
    appendChild(n) {
        if (n instanceof Fragment) {
            const kids = [...n.childNodes]; n.childNodes = [];
            kids.forEach(k => this.appendChild(k));
            return n;
        }
        if (n.parentNode) n.parentNode.removeChild(n);
        n.parentNode = this; this.childNodes.push(n); return n;
    }
    removeChild(n) {
        const i = this.childNodes.indexOf(n);
        if (i >= 0) this.childNodes.splice(i, 1);
        n.parentNode = null; return n;
    }
    remove() { if (this.parentNode) this.parentNode.removeChild(this); }
    cloneNode() {
        const c = this.nodeType === 3 ? new Text(this.data) : new El(this.tagName);
        if (this.attrs) c.attrs = { ...this.attrs };
        this.childNodes.forEach(k => c.appendChild(k.cloneNode()));
        return c;
    }
    // Selector support: comma-separated parts, each a combination of
    // tag / .class / [attr] / [attr="v"] — which is all the extension uses.
    _matchesPart(part) {
        if (this.nodeType !== 1) return false;
        const m = part.match(/^([a-zA-Z]*)((?:[.#][\w-]+|\[[^\]]+\])*)$/);
        if (!m) return false;
        if (m[1] && m[1].toUpperCase() !== this.tagName) return false;
        const rest = m[2] || '';
        for (const cls of rest.matchAll(/\.([\w-]+)/g)) {
            if (!this.classList.contains(cls[1])) return false;
        }
        for (const a of rest.matchAll(/\[([^\]=]+)(?:=["']?([^\]"']*)["']?)?\]/g)) {
            const v = this.getAttribute(a[1]);
            if (v === null) return false;
            if (a[2] !== undefined && v !== a[2]) return false;
        }
        return true;
    }
    matches(sel) {
        if (!sel || this.nodeType !== 1) return false;
        return sel.split(',').map(s => s.trim()).filter(Boolean).some(p => this._matchesPart(p));
    }
    closest(sel) {
        let n = this;
        while (n && n.nodeType === 1) { if (n.matches(sel)) return n; n = n.parentElement; }
        return null;
    }
    querySelectorAll(sel) {
        const out = [];
        (function walk(n) {
            n.childNodes.forEach(c => { if (c.nodeType === 1) { if (c.matches(sel)) out.push(c); walk(c); } });
        })(this);
        return out;
    }
    querySelector(sel) { const r = this.querySelectorAll(sel); return r.length ? r[0] : null; }
}

class Text extends Node { constructor(d) { super(); this.nodeType = 3; this.data = String(d); } }
class Fragment extends Node { constructor() { super(); this.nodeType = 11; } }

let elCounter = 0;

class El extends Node {
    constructor(tag) {
        super();
        this.tagName = String(tag).toUpperCase();
        this.attrs = {};
        this.dataset = {};
        this.style = new Proxy({}, { get: (t, k) => (k === 'setProperty' ? () => {} : (t[k] !== undefined ? t[k] : '')), set: (t, k, v) => { t[k] = v; return true; }, has: () => true, deleteProperty: (t, k) => { delete t[k]; return true; } });
        this.classList = new ClassList();
        this._id = 'e' + (++elCounter);
    }
    get href() { return this.attrs.href; }
    set href(v) { this.attrs.href = v; }
    setAttribute(k, v) {
        this.attrs[k] = String(v);
        if (k === 'class') this.classList = ClassList.from(String(v));
    }
    get className() { return this.attrs.class || ''; }
    set className(v) { this.setAttribute('class', v); }
    get hidden() { return 'hidden' in this.attrs; }
    set hidden(v) { if (v) this.attrs.hidden = ''; else delete this.attrs.hidden; }
    // innerHTML setter: tiny markup parser, enough for the progress widget's
    // template (nested tags, attributes, text, self-closing and void elements).
    set innerHTML(html) {
        this.childNodes.forEach(c => { c.parentNode = null; });
        this.childNodes = [];
        const VOID = new Set(['br', 'img', 'input', 'hr', 'meta', 'link', 'source', 'area', 'base', 'col', 'embed', 'param', 'track', 'wbr']);
        const stack = [this];
        const re = /<(\/?)([a-zA-Z][\w-]*)((?:\s+[\w:-]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+))?)*)\s*(\/?)>|([^<]+)/g;
        let m;
        while ((m = re.exec(String(html)))) {
            const top = stack[stack.length - 1];
            if (m[5] !== undefined) {
                const txt = m[5].replace(/\s+/g, ' ');
                if (txt.trim()) top.appendChild(new Text(txt));
                continue;
            }
            const closing = m[1] === '/';
            const tag = m[2];
            const attrText = m[3] || '';
            const selfClose = m[4] === '/';
            if (closing) { if (stack.length > 1) stack.pop(); continue; }
            const e = new El(tag);
            for (const a of attrText.matchAll(/([\w:-]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g)) {
                if (!a[1]) continue;
                e.setAttribute(a[1], a[2] !== undefined ? a[2] : (a[3] !== undefined ? a[3] : (a[4] !== undefined ? a[4] : '')));
            }
            top.appendChild(e);
            if (!selfClose && !VOID.has(tag.toLowerCase())) stack.push(e);
        }
    }
    getAttribute(k) { return k in this.attrs ? this.attrs[k] : null; }
    removeAttribute(k) { delete this.attrs[k]; }
    hasAttribute(k) { return k in this.attrs; }
    getBoundingClientRect() { return { top: 0, bottom: 10, left: 0, right: 10, width: 10, height: 10 }; }
    get isContentEditable() { return false; }
    get id() { return this.attrs.id || ''; }
    set id(v) { this.attrs.id = v; }
    addEventListener() {}
    removeEventListener() {}
    appendChild(n) { return super.appendChild(n); }
    serialize() {
        const a = Object.entries(this.attrs)
            .map(([k, v]) => (v === '' ? ` ${k}` : ` ${k}="${v}"`)).join('');
        const inner = this.childNodes.map(c => (c.nodeType === 3 ? c.data : c.serialize())).join('');
        return `<${this.tagName.toLowerCase()}${a}>${inner}</${this.tagName.toLowerCase()}>`;
    }
    get outerHTML() { return this.serialize(); }
    get innerHTML() { return this.childNodes.map(c => (c.nodeType === 3 ? c.data : c.serialize())).join(''); }
}

// Tag soup helper: el('p', {class:'x'}, 'text', el('a',{href:'/y'},'link'))
function el(tag, attrs, ...kids) {
    const e = new El(tag);
    for (const k in (attrs || {})) e.setAttribute(k, attrs[k]);
    kids.flat(Infinity).forEach(k => e.appendChild(typeof k === 'string' ? new Text(k) : k));
    return e;
}

function makeDocument(bodyEl) {
    const documentElement = el('html');
    const head = el('head');
    const body = bodyEl || el('body');
    documentElement.appendChild(head);
    documentElement.appendChild(body);
    return {
        documentElement,
        head,
        body,
        createElement: t => new El(t),
        createTextNode: d => new Text(d),
        createDocumentFragment: () => new Fragment(),
        getElementById: id => documentElement.querySelector(`[id="${id}"]`),
        querySelector: sel => documentElement.querySelector(sel),
        querySelectorAll: sel => documentElement.querySelectorAll(sel),
        addEventListener() {}, removeEventListener() {},
        createTreeWalker(root, whatToShow, filter) {
            const queue = [];
            (function walk(n) {
                n.childNodes.forEach(c => {
                    if (c.nodeType === 3) { if (!filter || filter.acceptNode(c) === 1) queue.push(c); }
                    else walk(c);
                });
            })(root);
            let i = 0;
            return { nextNode: () => (i < queue.length ? queue[i++] : null) };
        }
    };
}

// WebExtension API stub. `handlers` maps a runtime message type to a function
// returning the response; anything unhandled resolves to {}.
function createBrowserStub(handlers = {}) {
    const sent = [];
    const listeners = { runtime: [], tabsUpdated: [] };
    const store = {};
    const api = {
        __sent: sent,
        __listeners: listeners,
        runtime: {
            id: 'test-extension',
            lastError: null,
            getURL: p => 'moz-extension://test' + p,
            sendMessage: async (msg) => {
                sent.push(msg);
                const h = handlers[msg && msg.type];
                return h ? h(msg) : {};
            },
            onMessage: {
                addListener: (fn) => listeners.runtime.push(fn),
                removeListener() {}, hasListener: () => false
            },
            onStartup: { addListener() {} },
            onInstalled: { addListener() {} }
        },
        storage: {
            onChanged: { addListener() {}, removeListener() {}, hasListener: () => false },
            local: {
                get: async (k) => (typeof k === 'string' ? { [k]: store[k] } : { ...store }),
                set: async (obj) => { Object.assign(store, obj); },
                remove: async (k) => { delete store[k]; },
                clear: async () => { for (const k of Object.keys(store)) delete store[k]; }
            }
        },
        tabs: {
            query: async () => [{ id: 1, url: 'https://example.test/page', active: true }],
            sendMessage: async () => ({}),
            create: async () => ({ id: 2 }),
            onUpdated: { addListener() {} },
            onRemoved: { addListener() {} },
            executeScript: async () => [{ result: null }]
        },
        scripting: { executeScript: async () => [{ result: null }] },
        contextMenus: { create() {}, removeAll: async () => {}, onClicked: { addListener() {} } },
        action: { setBadgeText() {}, setBadgeBackgroundColor() {}, setTitle() {}, onClicked: { addListener() {} } },
        permissions: { request: async () => true, remove: async () => true, contains: async () => true },
        alarms: { create() {}, clear: async () => {}, onAlarm: { addListener() {} } },
        notifications: { create() {} },
        i18n: { getMessage: m => m }
    };
    return api;
}

function makeWindow(document) {
    return {
        document,
        innerHeight: 900, innerWidth: 1400,
        getComputedStyle: () => ({ display: 'block', visibility: 'visible' }),
        getSelection: () => ({ isCollapsed: true, rangeCount: 0, toString: () => '' }),
        addEventListener() {}, removeEventListener() {},
        requestAnimationFrame: (fn) => { fn(); return 1; },
        matchMedia: () => ({ matches: false, addListener() {}, removeListener() {} }),
        location: { origin: 'https://example.test', pathname: '/page', href: 'https://example.test/page' },
        MutationObserver: class { constructor(cb) { this.cb = cb; } observe() {} disconnect() {} },
        NodeFilter: { SHOW_TEXT: 4, SHOW_ELEMENT: 1, FILTER_ACCEPT: 1, FILTER_REJECT: 2, FILTER_SKIP: 3 }
    };
}

module.exports = { Node, Text, El, Fragment, ClassList, el, makeDocument, makeWindow, createBrowserStub };
