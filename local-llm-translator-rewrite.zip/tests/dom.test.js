// Функциональные тесты content.js.
//
// Режим переписи включается только сообщением START_TRANSLATION — точно так же,
// как это делает попап. Напрямую переменные content.js не переключить: они
// объявлены через let/const и живут в лексической области скрипта. Тесты поэтому
// проверяют настоящий путь «сообщение → работа → ответ», а не внутренности.
const { group, test, summary, ok, eq, includes } = require('./helper');
const { loadContent, el } = require('./loader');

function makePage(firstParagraph = 'Кэш — это место, где данные хранятся временно.') {
    return el('body', {},
        el('header', {}, el('nav', {}, el('ul', {},
            el('li', {}, el('a', { href: '/home' }, 'Главная')),
            el('li', {}, el('a', { href: '/docs' }, 'Документация'))))),
        el('main', {},
            el('article', {},
                el('header', {}, el('h1', {}, 'Как устроен кэш')),
                el('p', {}, firstParagraph, ' Повторный запрос выполняется быстрее. ',
                    el('a', { href: 'https://x/docs', target: '_blank' }, 'документация'), ' описывает детали.'),
                el('p', {}, 'Коротко.'),
                el('pre', {}, el('code', {}, 'const x = 1;')),
                el('div', {},
                    el('p', {}, 'Первый вложенный абзац с текстом.'),
                    el('p', {}, 'Второй вложенный абзац с текстом.')))),
        el('aside', {}, el('p', {}, 'Боковая колонка с похожими статьями.')),
        el('footer', {}, el('p', {}, '© 2026 Все права защищены.'))
    );
}

// Хранилище кэша страниц и ответы на сообщения расширения.
function makeCtx(page, { rewriteAnswer } = {}) {
    const store = { pages: new Map() };
    // Ответ в том виде, в каком его отдаёт background.js: текст переписан, а
    // ссылки уже развёрнуты из описи в { href, text, attrs } — content.js не
    // знает про индексы, он вставляет готовые ссылки.
    const resolve = (b, links) => links.map(l => {
        const src = b.links[l.i] || {};
        return { href: src.href, text: l.t, attrs: src.attrs || {} };
    });
    const answer = rewriteAnswer || ((blocks) => blocks.map(b => {
        const model = { id: b.id, text: '', links: b.links.map((l, i) => ({ i, t: l.text })) };
        const anchors = b.links.map(l => l.text).join(' и ');
        model.text = `Переписано проще: ${b.text.slice(0, 24)} Подробности — ${anchors || 'без ссылок'}.`;
        return { id: model.id, text: model.text, links: resolve(b, model.links) };
    }));
    const handlers = {
        GET_SETTINGS: () => ({ settings: { debug: false, persistRewrites: true, cacheMode: 'off', maxOutputRetries: 2 } }),
        GET_PAGE_CACHE: (m) => ({ data: store.pages.get(m.url) || null }),
        SAVE_PAGE_CACHE: (m) => { store.pages.set(m.url, m.data); return { ok: true }; },
        CLEAR_PAGE_CACHE: (m) => ({ ok: store.pages.delete(m.url) }),
        REWRITE_BLOCKS: (m) => ({ blocks: answer(m.blocks), total: m.blocks.length }),
        TRANSLATE: (m) => ({ translations: m.texts.map(t => ({ id: t.id, text: 'перевод: ' + t.text.slice(0, 12) })), total: m.texts.length })
    };
    const ctx = loadContent({ page, handlers });
    ctx.store = store;
    ctx.send = (msg) => new Promise((resolve) => {
        let answered = false;
        ctx.browser.__listeners.runtime[0](msg, {}, (r) => { answered = true; resolve(r); });
        // синхронные ветки отвечают сразу; асинхронные — позже
        setTimeout(() => { if (!answered) resolve(undefined); }, 60);
    });
    return ctx;
}

async function waitFor(fn, ms = 4000) {
    const start = Date.now();
    while (Date.now() - start < ms) {
        if (fn()) return true;
        await new Promise(r => setTimeout(r, 20));
    }
    return false;
}

const byTag = (node, tag) => node.querySelectorAll(tag);
const textsOf = items => items.map(i => i.text);
const has = (items, frag) => textsOf(items).some(t => t.includes(frag));

// ---------------------------------------------------------------- отбор блоков
group('extractBlocks: отбор блоков');

test('берутся абзацы, заголовок статьи и вложенные блоки', () => {
    const { sandbox, document } = makeCtx(makePage());
    const items = sandbox.extractBlocks(document.body);
    ok(has(items, 'Как устроен кэш'), 'заголовок статьи (header внутри article)');
    ok(has(items, 'Кэш — это место'), 'абзац со ссылкой');
    ok(has(items, 'Коротко.'), 'короткое предложение — проза, а не интерфейс');
    ok(has(items, 'Первый вложенный'), 'вложенный абзац 1');
    ok(has(items, 'Второй вложенный'), 'вложенный абзац 2');
});

test('контейнер со вложенными блоками не берётся', () => {
    const { sandbox, document } = makeCtx(makePage());
    const items = sandbox.extractBlocks(document.body);
    ok(!textsOf(items).some(t => t.includes('Первый вложенный') && t.includes('Второй вложенный')),
        'найден блок, содержащий оба вложенных абзаца');
});

test('навигация, футер, сайдбар и код не берутся', () => {
    const { sandbox, document } = makeCtx(makePage());
    const items = sandbox.extractBlocks(document.body);
    ok(!has(items, 'Главная'), 'пункт меню «Главная»');
    ok(!textsOf(items).some(t => t.trim() === 'Документация'), 'пункт меню «Документация»');
    ok(!has(items, 'Все права защищены'), 'футер');
    ok(!has(items, 'Боковая колонка'), 'aside');
    ok(!has(items, 'const x = 1'), 'код');
});

test('опись ссылок блока заполняется вместе с атрибутами', () => {
    const { sandbox, document } = makeCtx(makePage());
    const items = sandbox.extractBlocks(document.body);
    const item = items.find(i => i.text.includes('Кэш — это место'));
    eq(item.links.length, 1, 'ссылок в описи');
    eq(item.links[0].href, 'https://x/docs', 'href');
    eq(item.links[0].text, 'документация', 'текст ссылки');
    eq(item.links[0].attrs.target, '_blank', 'target перенесён');
});

test('блок целиком из ссылок — элемент управления', () => {
    const { sandbox } = makeCtx(el('body'));
    ok(sandbox.isInteractiveBlock(el('li', {}, el('a', { href: '/x' }, 'Пункт меню'))), 'li>a');
    ok(sandbox.isInteractiveBlock(el('div', {}, el('a', { href: '/x' }, 'Читать далее'))), 'div>a');
    ok(!sandbox.isInteractiveBlock(el('p', {}, 'Текст ', el('a', { href: '/x' }, 'ссылка'), ' и хвост.')), 'абзац со ссылкой');
});

// isInsideRewriteChrome проверяет предков элемента, поэтому вызывать её надо
// на блоке внутри проверяемой обёртки — так её и использует extractBlocks.
test('header сайта — навигация, header статьи — контент', () => {
    const { sandbox } = makeCtx(makePage());
    const siteHeaderInner = el('body', {}, el('header', {}, el('p', {}, 'Шапка сайта'))).childNodes[0].childNodes[0];
    const articleHeaderInner = el('body', {}, el('article', {}, el('header', {}, el('p', {}, 'Заголовок'))))
        .childNodes[0].childNodes[0].childNodes[0];
    eq(sandbox.isInsideRewriteChrome(siteHeaderInner), true, 'абзац внутри header сайта');
    eq(sandbox.isInsideRewriteChrome(articleHeaderInner), false, 'абзац внутри header статьи');
    eq(sandbox.isInsideRewriteChrome(el('body', {}, el('nav', {}, el('p', {}, 'x'))).childNodes[0].childNodes[0]), true, 'абзац внутри nav');
});

// ------------------------------------------------- полный цикл через сообщения
group('Полный цикл: START_TRANSLATION → перепись');

test('режим rewrite: страница переписывается блоками', async () => {
    const ctx = makeCtx(makePage());
    await ctx.send({ type: 'START_TRANSLATION', targetLanguage: 'ru', outputMode: 'rewrite', rewriteScope: 'block', maxItemsPerBatch: 4, maxConcurrentRequests: 1 });
    const done = await waitFor(() => ctx.sandbox.window.__lltState.showingTranslations);
    ok(done, 'перепись не завершилась');
    eq(ctx.sandbox.window.__lltState.rewriteBlockMode, true, 'режим блоков включён сообщением');
    ok(ctx.browser.__sent.some(m => m.type === 'REWRITE_BLOCKS'), 'отправлялся REWRITE_BLOCKS');
    ok(!ctx.browser.__sent.some(m => m.type === 'TRANSLATE'), 'TRANSLATE не отправлялся');

    const article = byTag(ctx.document.body, 'article')[0];
    const paragraphs = byTag(article, 'p');
    includes(paragraphs[0].textContent, 'Переписано проще:', 'абзац переписан');
    includes(paragraphs[0].innerHTML, '<a href="https://x/docs" target="_blank">документация</a>', 'ссылка и её атрибуты на месте');
    ok(byTag(ctx.document.body, 'pre')[0].textContent.includes('const x = 1'), 'код не тронут');
    ok(byTag(ctx.document.body, 'footer')[0].textContent.includes('Все права защищены'), 'футер не тронут');
});

test('режим translate идёт прежним путём через TRANSLATE', async () => {
    const ctx = makeCtx(makePage());
    await ctx.send({ type: 'START_TRANSLATION', targetLanguage: 'en', outputMode: 'translate' });
    const done = await waitFor(() => ctx.sandbox.window.__lltState.showingTranslations);
    ok(done, 'перевод не завершился');
    eq(ctx.sandbox.window.__lltState.rewriteBlockMode, false, 'режим блоков выключен');
    ok(ctx.browser.__sent.some(m => m.type === 'TRANSLATE'), 'отправлялся TRANSLATE');
    ok(!ctx.browser.__sent.some(m => m.type === 'REWRITE_BLOCKS'), 'REWRITE_BLOCKS не отправлялся');
});

test('rewriteScope=node переключает на текстовые узлы', async () => {
    const ctx = makeCtx(makePage());
    await ctx.send({ type: 'START_TRANSLATION', targetLanguage: 'ru', outputMode: 'rewrite', rewriteScope: 'node' });
    await waitFor(() => ctx.sandbox.window.__lltState.showingTranslations);
    eq(ctx.sandbox.window.__lltState.rewriteBlockMode, false, 'узловой режим');
    ok(ctx.browser.__sent.some(m => m.type === 'TRANSLATE'), 'работает через TRANSLATE');
});

test('кэш страницы сохраняется после переписи', async () => {
    const ctx = makeCtx(makePage());
    await ctx.send({ type: 'START_TRANSLATION', targetLanguage: 'ru', outputMode: 'rewrite', rewriteScope: 'block' });
    await waitFor(() => ctx.store.pages.size > 0);
    eq(ctx.store.pages.size, 1, 'запись для страницы');
    const data = JSON.parse([...ctx.store.pages.values()][0]);
    ok(data.blocks.length > 0, 'в записи есть блоки');
    ok(data.blocks.every(b => b.result && b.result.text), 'у каждого блока есть результат');
});

test('возврат на страницу восстанавливает перепись без модели', async () => {
    const first = makeCtx(makePage());
    await first.send({ type: 'START_TRANSLATION', targetLanguage: 'ru', outputMode: 'rewrite', rewriteScope: 'block' });
    await waitFor(() => first.store.pages.size > 0);

    // «перезагрузка»: новая страница, то же хранилище
    const second = makeCtx(makePage());
    second.store.pages = first.store.pages;
    const sentBefore = second.browser.__sent.filter(m => m.type === 'REWRITE_BLOCKS').length;
    await second.send({ type: 'START_TRANSLATION', targetLanguage: 'ru', outputMode: 'rewrite', rewriteScope: 'block' });
    await waitFor(() => second.sandbox.window.__lltState.showingTranslations);

    const article = byTag(second.document.body, 'article')[0];
    includes(byTag(article, 'p')[0].textContent, 'Переписано проще:', 'текст восстановлен из кэша');
    eq(second.browser.__sent.filter(m => m.type === 'REWRITE_BLOCKS').length, sentBefore,
        'модель не запрашивалась');
});

// ---------------------------------------------------------------- оригинал/кэш
group('Original и сброс кэша страницы');

test('TOGGLE_TRANSLATION показывает оригинал и возвращает перепись', async () => {
    const ctx = makeCtx(makePage());
    await ctx.send({ type: 'START_TRANSLATION', targetLanguage: 'ru', outputMode: 'rewrite', rewriteScope: 'block' });
    await waitFor(() => ctx.sandbox.window.__lltState.showingTranslations);

    const p = byTag(byTag(ctx.document.body, 'article')[0], 'p')[0];
    const rewritten = p.textContent;
    includes(rewritten, 'Переписано проще:');

    const r1 = await ctx.send({ type: 'TOGGLE_TRANSLATION' });
    eq(r1.showing, 'original', 'ответ на первое переключение');
    ok(!p.textContent.includes('Переписано проще:'), 'показан оригинал');
    includes(p.textContent, 'Кэш — это место', 'исходный текст');
    eq(ctx.store.pages.size, 1, 'кэш страницы не очищен');

    const r2 = await ctx.send({ type: 'TOGGLE_TRANSLATION' });
    eq(r2.showing, 'translated', 'ответ на второе переключение');
    includes(p.textContent, 'Переписано проще:', 'перепись возвращена');
});

test('CLEAR_PAGE_CACHE возвращает оригинал и удаляет запись', async () => {
    const ctx = makeCtx(makePage());
    await ctx.send({ type: 'START_TRANSLATION', targetLanguage: 'ru', outputMode: 'rewrite', rewriteScope: 'block' });
    await waitFor(() => ctx.store.pages.size > 0);

    const p = byTag(byTag(ctx.document.body, 'article')[0], 'p')[0];
    const res = await ctx.send({ type: 'CLEAR_PAGE_CACHE' });
    await waitFor(() => res === undefined ? false : true);
    ok(!p.textContent.includes('Переписано проще:'), 'на странице оригинал');
    eq(ctx.store.pages.size, 0, 'запись удалена');
    eq(ctx.sandbox.window.__lltState.hasCache, false, 'флаг кэша сброшен');
});

// ---------------------------------------------------------------- ответы модели
group('Применение ответов модели');

test('блок с error остаётся нетронутым', async () => {
    const ctx = makeCtx(makePage(), {
        rewriteAnswer: (blocks) => blocks.map((b, i) => i === 0
            ? { id: b.id, error: 'rewrite failed validation' }
            : { id: b.id, text: 'Переписано: ' + b.text.slice(0, 10) + ' ' + b.links.map(l => l.text).join(' '), links: b.links.map((l, k) => ({ href: l.href, text: l.text, attrs: l.attrs || {} })) })
    });
    await ctx.send({ type: 'START_TRANSLATION', targetLanguage: 'ru', outputMode: 'rewrite', rewriteScope: 'block', maxItemsPerBatch: 2 });
    await waitFor(() => ctx.sandbox.window.__lltState.showingTranslations || ctx.sandbox.window.__lltState.blockCount > 0);
    await new Promise(r => setTimeout(r, 200));
    const blocks = ctx.sandbox.window.__lltState.blocks();
    ok(blocks.some(b => !b.done), 'хотя бы один блок не применён');
    ok(blocks.some(b => b.done), 'остальные применены');
});

test('блок, в ответе которого нет текста ссылки, не применяется', async () => {
    // Так ведёт себя валидатор в background.js: anchor text обязан встречаться в
    // тексте, иначе <a> некуда вставить. Здесь проверяем защиту на стороне DOM:
    // ответ без вхождения anchor text не должен породить битую ссылку.
    const ctx = makeCtx(makePage(), {
        rewriteAnswer: (blocks) => blocks.map(b => ({
            id: b.id,
            text: 'Текст переписан, но anchor text из описи в нём не встречается.',
            links: b.links.map((l) => ({ href: l.href, text: l.text, attrs: l.attrs || {} }))
        }))
    });
    await ctx.send({ type: 'START_TRANSLATION', targetLanguage: 'ru', outputMode: 'rewrite', rewriteScope: 'block', maxItemsPerBatch: 2 });
    await waitFor(() => ctx.sandbox.window.__lltState.blockCount > 0);
    await new Promise(r => setTimeout(r, 150));
    const article = byTag(ctx.document.body, 'article')[0];
    const withLink = byTag(article, 'p')[0];
    ok(!withLink.innerHTML.includes('<a href'), 'ссылка не вставлена туда, где её текста нет');
});

test('батч режется по maxItemsPerBatch из сообщения', async () => {
    const ctx = makeCtx(makePage());
    await ctx.send({ type: 'START_TRANSLATION', targetLanguage: 'ru', outputMode: 'rewrite', rewriteScope: 'block', maxItemsPerBatch: 2 });
    await waitFor(() => ctx.sandbox.window.__lltState.showingTranslations);
    const sizes = ctx.browser.__sent.filter(m => m.type === 'REWRITE_BLOCKS').map(m => m.blocks.length);
    ok(sizes.length > 1, 'батчей больше одного');
    ok(sizes.every(n => n <= 2), `все батчи не больше 2, фактически: ${sizes.join(',')}`);
});

summary();
