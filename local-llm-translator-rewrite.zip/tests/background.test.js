// Функциональные тесты background.js: валидация ответа модели, повторы,
// разбор JSON, ключи кэша, миграция настроек, нормализация URL.
const { group, test, summary, ok, eq, deepEq, includes, notIncludes } = require('./helper');
const { loadBackground } = require('./loader');

const bg = loadBackground();

// ---------------------------------------------------------------- editDistance
group('editDistance');

test('одинаковые строки дают 0', () => eq(bg.editDistance('abc', 'abc', 3), 0));
test('одна замена даёт 1', () => eq(bg.editDistance('abc', 'abd', 3), 1));
test('вставка и удаление считаются', () => eq(bg.editDistance('abc', 'abcd', 3), 1));
test('cap ограничивает счёт сверху', () => eq(bg.editDistance('абв', 'совершенно другой текст', 3), 3));
test('пустая и непустая строка', () => eq(bg.editDistance('', 'abc', 3), 3));

// ---------------------------------------------------------------- validate
group('validateRewriteBlock');

const INV = [
    { href: 'https://x/docs', text: 'документация', attrs: {} },
    { href: 'https://x/api', text: 'API', attrs: { target: '_blank' } }
];
const SRC = 'Система применяет ленивую загрузку (см. документация) и API.';

test('годная перепись с двумя ссылками принимается', () => {
    eq(bg.validateRewriteBlock(SRC, INV, {
        text: 'Данные подгружаются только когда нужны. Подробности — в документация, методы описаны в API.',
        links: [{ i: 0, t: 'документация' }, { i: 1, t: 'API' }]
    }), null);
});

test('одно предложение может стать несколькими', () => {
    eq(bg.validateRewriteBlock(SRC, INV, {
        text: 'Система не грузит всё сразу. Она берёт данные по мере надобности. Это описано в документация и в API.',
        links: [{ i: 1, t: 'API' }, { i: 0, t: 'документация' }]
    }), null, 'порядок ссылок не обязан совпадать');
});

test('потерянная ссылка отклоняется', () => {
    includes(bg.validateRewriteBlock(SRC, INV, {
        text: 'Данные подгружаются по мере надобности, см. документация.',
        links: [{ i: 0, t: 'документация' }]
    }), 'missing');
});

test('ссылка дважды отклоняется', () => {
    includes(bg.validateRewriteBlock(SRC, INV, {
        text: 'См. документация и ещё раз документация, плюс API.',
        links: [{ i: 0, t: 'документация' }, { i: 0, t: 'документация' }, { i: 1, t: 'API' }]
    }), 'more than once');
});

test('выдуманный индекс отклоняется', () => {
    includes(bg.validateRewriteBlock(SRC, INV, {
        text: 'См. документация и API.', links: [{ i: 7, t: 'документация' }, { i: 1, t: 'API' }]
    }), 'does not exist');
});

test('текст ссылки обязан встречаться в ответе', () => {
    includes(bg.validateRewriteBlock(SRC, INV, {
        text: 'Данные подгружаются лениво. См. docs и API.',
        links: [{ i: 0, t: 'документация' }, { i: 1, t: 'API' }]
    }), 'does not occur');
});

test('почти дословный возврат отклоняется', () => {
    includes(bg.validateRewriteBlock(SRC, INV, {
        text: SRC.slice(0, -1) + '!', links: [{ i: 0, t: 'документация' }, { i: 1, t: 'API' }]
    }), 'almost unchanged');
});

test('пустой текст отклоняется', () => {
    includes(bg.validateRewriteBlock(SRC, INV, { text: '   ', links: [] }), 'empty');
});

test('блок без описи не может вернуть ссылку', () => {
    includes(bg.validateRewriteBlock('Обычный текст.', [], {
        text: 'Обычный текст, переписанный другими словами.', links: [{ i: 0, t: 'x' }]
    }), 'has none');
});

test('сильное сокращение текста проходит (шпаргалка)', () => {
    eq(bg.validateRewriteBlock('Очень длинное исходное предложение с множеством деталей и пояснений.', [], {
        text: 'Коротко.', links: []
    }), null);
});

// ---------------------------------------------------------------- парсинг
group('extractRewriteBlocks');

const GOOD = '{"blocks":[{"id":0,"text":"Переписано.","links":[{"i":0,"t":"документация"}]}]}';
test('чистый JSON', () => eq(bg.extractRewriteBlocks(GOOD).length, 1));
test('JSON внутри code fence', () => eq(bg.extractRewriteBlocks('```json\n' + GOOD + '\n```').length, 1));
test('JSON внутри постороннего текста', () => eq(bg.extractRewriteBlocks('Вот результат:\n' + GOOD + '\nГотово.').length, 1));
test('мусор даёт пустой список', () => eq(bg.extractRewriteBlocks('не json').length, 0));
test('пустой ответ даёт пустой список', () => eq(bg.extractRewriteBlocks('').length, 0));
test('id приводится к числу', () => {
    const r = bg.extractRewriteBlocks('{"blocks":[{"id":"3","text":"x","links":[]}]}');
    eq(r[0].id, 3);
});

// ---------------------------------------------------------------- промпты
group('Промпты переписи');

test('{{targetLanguage}} подставляется', () => {
    const sys = bg.buildRewriteSystemPrompt(bg.REWRITE_PROMPT_TEMPLATES.rewrite, 'Russian', '');
    includes(sys, 'in Russian');
    notIncludes(sys, '{{targetLanguage}}');
});

test('свои правила дописываются в системный промпт', () => {
    const sys = bg.buildRewriteSystemPrompt(bg.REWRITE_PROMPT_TEMPLATES.rewrite, 'Russian', 'Пиши в инфостиле.');
    includes(sys, 'Пиши в инфостиле.');
    includes(sys, 'Additional rules from the user');
});

test('без своих правил хвоста нет', () => {
    notIncludes(bg.buildRewriteSystemPrompt(bg.REWRITE_PROMPT_TEMPLATES.rewrite, 'Russian', '   '),
        'Additional rules');
});

test('опись ссылок печатается в user-промпт', () => {
    const up = bg.buildRewriteUserPrompt(bg.REWRITE_PROMPT_TEMPLATES.rewrite, 'Russian',
        [{ id: 4, text: SRC, links: INV }], new Map());
    includes(up, '[4]: ' + SRC);
    includes(up, '[0] "документация"');
    includes(up, '[1] "API"');
});

test('при повторе в промпт попадает причина отказа', () => {
    const up = bg.buildRewriteUserPrompt(bg.REWRITE_PROMPT_TEMPLATES.rewrite, 'Russian',
        [{ id: 4, text: SRC, links: INV }],
        new Map([[4, 'link(s) [1] from the inventory are missing from your answer']]));
    includes(up, 'was rejected');
    includes(up, 'missing from your answer');
});

test('блок без ссылок не получает описи', () => {
    const up = bg.buildRewriteUserPrompt(bg.REWRITE_PROMPT_TEMPLATES.rewrite, 'Russian',
        [{ id: 1, text: 'Просто текст.', links: [] }], new Map());
    notIncludes(up, 'Links in this fragment');
});

// ---------------------------------------------------------------- URL
group('normalizeServerUrl');

for (const [input, expected] of [
    ['http://127.0.0.1:8080', 'http://127.0.0.1:8080'],
    ['http://127.0.0.1:8080/', 'http://127.0.0.1:8080'],
    ['http://127.0.0.1:8080/v1', 'http://127.0.0.1:8080'],
    ['http://localhost:8080', 'http://127.0.0.1:8080'],
    ['http://localhost:1234/v1/', 'http://127.0.0.1:1234']
]) {
    test(`${input} → ${expected}`, () => eq(bg.normalizeServerUrl(input), expected));
}

// ---------------------------------------------------------------- кэш-ключ
group('Ключ кэша');

test('разные тексты дают разные ключи', () => {
    ok(bg.cacheKey('m', 'a', 'b', 'sig', 'текст 1') !== bg.cacheKey('m', 'a', 'b', 'sig', 'текст 2'));
});

test('разные сигнатуры промпта дают разные ключи', () => {
    ok(bg.cacheKey('m', 'a', 'b', 'sig1', 'text') !== bg.cacheKey('m', 'a', 'b', 'sig2', 'text'));
});

test('hashString различает вход и стабилен', () => {
    eq(bg.hashString('abc'), bg.hashString('abc'));
    ok(bg.hashString('abc') !== bg.hashString('abd'));
});

test('pageKey отбрасывает query и hash', () => {
    eq(bg.pageKey('https://x.test/a/b?c=1#frag'), 'https://x.test/a/b');
    eq(bg.pageKey('https://x.test/a/b'), 'https://x.test/a/b');
});

// ---------------------------------------------------------------- настройки
group('Миграция настроек');

test('старые настройки сбрасываются к новым дефолтам, своё сохраняется', async () => {
    const store = {
        settings: {
            settingsVersion: 1, selectedModel: 'qwen-9b', lmstudioUrl: 'http://127.0.0.1:9999',
            rewriteInstructions: 'Пиши коротко.', customPrompts: { rewrite: { system: 's', user: 'u' } },
            outputMode: 'translate', temperature: 0.1, maxItemsPerBatch: 20, debug: false
        }
    };
    const box = loadBackground({ storage: store });

    const s = await box.loadSettings();
    eq(s.settingsVersion, box.SETTINGS_VERSION, 'версия поднята');
    eq(s.selectedModel, 'qwen-9b', 'модель сохранена');
    eq(s.lmstudioUrl, 'http://127.0.0.1:9999', 'URL сохранён');
    eq(s.rewriteInstructions, 'Пиши коротко.', 'свои правила сохранены');
    eq(s.customPrompts.rewrite.system, 's', 'правки промпта сохранены');
    eq(s.outputMode, 'rewrite', 'режим сброшен в дефолт');
    eq(s.temperature, 0.6, 'температура сброшена в дефолт');
    eq(s.maxItemsPerBatch, 4, 'батч сброшен в дефолт');
    eq(store.settings.settingsVersion, box.SETTINGS_VERSION, 'новая версия записана в хранилище');
});

test('настройки текущей версии не перетираются', async () => {
    const box = loadBackground();
    box.__store.settings = { settingsVersion: box.SETTINGS_VERSION, outputMode: 'translate', temperature: 0.2, selectedModel: 'm' };
    const s = await box.loadSettings();
    eq(s.outputMode, 'translate', 'пользовательский режим уцелел');
    eq(s.temperature, 0.2, 'пользовательская температура уцелела');
});

// ---------------------------------------------------------------- полный цикл
group('rewriteBlocks: запрос → валидация → повтор');

function lmStudioFetch(responses) {
    const calls = [];
    return {
        calls,
        impl: async (url, opts) => {
            calls.push({ url, body: JSON.parse(opts.body) });
            const content = responses[Math.min(calls.length - 1, responses.length - 1)];
            return {
                ok: true, status: 200,
                json: async () => ({ choices: [{ message: { content }, finish_reason: 'stop' }] }),
                text: async () => content
            };
        }
    };
}

const baseSettings = {
    selectedModel: 'test-model', provider: 'lmstudio', lmstudioUrl: 'http://127.0.0.1:8080',
    targetLanguage: 'ru', rewriteStyle: 'rewrite', rewriteInstructions: '', customPrompts: {},
    temperature: 0.6, maxOutputRetries: 2, cacheMode: 'off', debug: false
};

test('годный ответ первого раза принимается, href берётся из описи', async () => {
    const f = lmStudioFetch([JSON.stringify({
        blocks: [{ id: 0, text: 'Данные подгружаются по мере надобности. См. документация и API.', links: [{ i: 0, t: 'документация' }, { i: 1, t: 'API' }] }]
    })]);
    const box = loadBackground({ fetchImpl: f.impl });
    const res = await box.rewriteBlocks([{ id: 11, text: SRC, links: INV }], 'ru', baseSettings);
    eq(f.calls.length, 1, 'запросов к модели');
    eq(res.blocks.length, 1);
    eq(res.blocks[0].id, 11, 'id вернулся исходный, а не внутренний');
    eq(res.blocks[0].links.length, 2);
    eq(res.blocks[0].links[0].href, 'https://x/docs', 'href из описи');
    eq(res.blocks[0].links[1].href, 'https://x/api', 'href из описи');
    eq(res.blocks[0].links[1].attrs.target, '_blank', 'атрибуты оригинала перенесены');
});

test('контракт с content.js: ссылки возвращаются развёрнутыми, а не индексами', async () => {
    // content.js не знает про индексы описи — он вставляет готовые ссылки.
    // Если background вернёт {i,t} вместо {href,text,attrs}, <a> на странице
    // появится без адреса.
    const f = lmStudioFetch([JSON.stringify({
        blocks: [{ id: 0, text: 'Данные подгружаются по мере надобности. См. документация и API.', links: [{ i: 0, t: 'документация' }, { i: 1, t: 'API' }] }]
    })]);
    const box = loadBackground({ fetchImpl: f.impl });
    const res = await box.rewriteBlocks([{ id: 1, text: SRC, links: INV }], 'ru', baseSettings);
    for (const link of res.blocks[0].links) {
        ok(typeof link.href === 'string' && link.href.startsWith('http'), `href: ${JSON.stringify(link)}`);
        ok(typeof link.text === 'string' && link.text.length > 0, `text: ${JSON.stringify(link)}`);
        ok(link.attrs && typeof link.attrs === 'object', `attrs: ${JSON.stringify(link)}`);
        ok(link.i === undefined && link.t === undefined, 'в ответе не должно оставаться полей модели i/t');
    }
});

test('бракованный ответ уходит на повтор с указанием причины', async () => {
    const f = lmStudioFetch([
        JSON.stringify({ blocks: [{ id: 0, text: 'Данные подгружаются по мере надобности. См. документация.', links: [{ i: 0, t: 'документация' }] }] }),
        JSON.stringify({ blocks: [{ id: 0, text: 'Данные подгружаются по мере надобности. См. документация и API.', links: [{ i: 0, t: 'документация' }, { i: 1, t: 'API' }] }] })
    ]);
    const box = loadBackground({ fetchImpl: f.impl });
    const res = await box.rewriteBlocks([{ id: 5, text: SRC, links: INV }], 'ru', baseSettings);
    eq(f.calls.length, 2, 'запросов к модели');
    includes(f.calls[1].body.messages[1].content, 'missing from your answer', 'причина отказа во втором промпте');
    eq(res.blocks[0].links.length, 2, 'после повтора обе ссылки');
});

test('нераспарсенный ответ батча не роняет весь прогон', async () => {
    const f = lmStudioFetch([
        'модель ответила прозой без json',
        JSON.stringify({ blocks: [{ id: 0, text: 'Переписанный текст достаточной длины.', links: [] }] })
    ]);
    const box = loadBackground({ fetchImpl: f.impl });
    const res = await box.rewriteBlocks([{ id: 1, text: 'Исходный текст блока.', links: [] }], 'ru', baseSettings);
    eq(f.calls.length, 2);
    ok(res.blocks[0].text, 'блок в итоге переписан');
});

test('блок, не прошедший валидацию, возвращается с error и без текста', async () => {
    const bad = JSON.stringify({ blocks: [{ id: 0, text: 'Ответ, где ссылка потеряна.', links: [] }] });
    const f = lmStudioFetch([bad, bad, bad, bad]);
    const box = loadBackground({ fetchImpl: f.impl });
    const res = await box.rewriteBlocks([{ id: 1, text: SRC, links: INV }], 'ru', baseSettings);
    eq(f.calls.length, 3, 'первая попытка + maxOutputRetries');
    eq(res.blocks[0].error, 'rewrite failed validation');
    ok(!res.blocks[0].text, 'текст не подставлен');
});

test('в structured output уходит схема переписи, а не перевода', async () => {
    const f = lmStudioFetch([JSON.stringify({ blocks: [{ id: 0, text: 'Переписано достаточно сильно.', links: [] }] })]);
    const box = loadBackground({ fetchImpl: f.impl });
    await box.rewriteBlocks([{ id: 1, text: 'Исходный текст блока.', links: [] }], 'ru', baseSettings);
    const fmt = f.calls[0].body.response_format.json_schema;
    ok(fmt.schema.properties.blocks, 'в запросе схема blocks');
    ok(!fmt.schema.properties.translations, 'схемы translations быть не должно');
});

test('свои правила попадают в системный промпт запроса', async () => {
    const f = lmStudioFetch([JSON.stringify({ blocks: [{ id: 0, text: 'Переписано достаточно сильно.', links: [] }] })]);
    const box = loadBackground({ fetchImpl: f.impl });
    await box.rewriteBlocks([{ id: 1, text: 'Исходный текст блока.', links: [] }], 'ru',
        { ...baseSettings, rewriteInstructions: 'Не использовать слово «данный».' });
    includes(f.calls[0].body.messages[0].content, 'Не использовать слово «данный».');
});

test('кэш переписи: повторный вызов не идёт в модель', async () => {
    const store = new Map();
    const f = lmStudioFetch([JSON.stringify({ blocks: [{ id: 0, text: 'Переписано и сохранено в кэш.', links: [] }] })]);
    const box = loadBackground({ fetchImpl: f.impl });
    box.cacheGetMany = async (keys) => new Map(keys.filter(k => store.has(k)).map(k => [k, store.get(k)]));
    box.cacheSetMany = async (entries) => { entries.forEach(([k, v]) => store.set(k, v)); };
    const settings = { ...baseSettings, cacheMode: 'persistent' };
    const item = { id: 1, text: 'Исходный текст блока.', links: [] };

    const first = await box.rewriteBlocks([item], 'ru', settings);
    eq(f.calls.length, 1, 'первый вызов идёт в модель');
    eq(first.fromCache, 0);
    eq(store.size, 1, 'результат записан в кэш');

    const second = await box.rewriteBlocks([{ ...item, id: 2 }], 'ru', settings);
    eq(f.calls.length, 1, 'второй вызов модель не трогает');
    eq(second.fromCache, 1);
    eq(second.blocks[0].text, 'Переписано и сохранено в кэш.');
});

test('смена своих правил делает кэш недействительным', async () => {
    const store = new Map();
    const f = lmStudioFetch([JSON.stringify({ blocks: [{ id: 0, text: 'Переписано достаточно сильно.', links: [] }] })]);
    const box = loadBackground({ fetchImpl: f.impl });
    box.cacheGetMany = async (keys) => new Map(keys.filter(k => store.has(k)).map(k => [k, store.get(k)]));
    box.cacheSetMany = async (entries) => { entries.forEach(([k, v]) => store.set(k, v)); };
    const item = { id: 1, text: 'Исходный текст блока.', links: [] };

    await box.rewriteBlocks([item], 'ru', { ...baseSettings, cacheMode: 'persistent', rewriteInstructions: 'Правило А.' });
    eq(f.calls.length, 1);
    await box.rewriteBlocks([{ ...item, id: 2 }], 'ru', { ...baseSettings, cacheMode: 'persistent', rewriteInstructions: 'Правило Б.' });
    eq(f.calls.length, 2, 'с другими правилами кэш не переиспользуется');
});

summary();
